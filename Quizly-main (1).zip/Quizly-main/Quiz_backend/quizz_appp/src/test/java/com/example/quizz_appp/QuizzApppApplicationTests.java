package com.example.quizz_appp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class QuizzApppApplicationTests {

	@Test
	void contextLoads() {
	}

}
