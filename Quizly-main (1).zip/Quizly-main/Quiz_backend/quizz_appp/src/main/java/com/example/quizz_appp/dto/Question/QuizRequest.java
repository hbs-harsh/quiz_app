package com.example.quizz_appp.dto.Question;


public class QuizRequest {
    private String category;
    private String difficulty;
    private String country;
    private int limit;

    public QuizRequest(String category, String difficulty, String country, int limit) {
    this.category=category;
    this.difficulty=difficulty;
    this.country=country;
    this.limit=limit;

    }

    // Getters
    public String getCategory() { return category; }
    public String getDifficulty() { return difficulty; }
    public String getCountry() { return country; }
    public int getLimit() { return limit; }

    // Setters
    public void setCategory(String category) { this.category = category; }
    public void setDifficulty(String difficulty) { this.difficulty = difficulty; }
    public void setCountry(String country) { this.country = country; }
    public void setLimit(int limit) { this.limit = limit; }
}