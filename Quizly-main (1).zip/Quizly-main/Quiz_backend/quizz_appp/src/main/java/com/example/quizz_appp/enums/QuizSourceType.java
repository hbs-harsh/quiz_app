package com.example.quizz_appp.enums;


public enum QuizSourceType {
    /** Quiz from a selected subject/topic */
    TOPIC,
    /** Quiz from uploaded PDF/Word (coming soon) */
    DOCUMENT,
    /** Custom prompt */
    CUSTOM_PROMPT
}
