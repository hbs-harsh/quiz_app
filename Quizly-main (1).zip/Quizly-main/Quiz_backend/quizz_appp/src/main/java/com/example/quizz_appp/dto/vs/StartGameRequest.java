package com.example.quizz_appp.dto.vs;

public class StartGameRequest {
    private Long roomId;
    private String roomCode;

    public StartGameRequest() {}

    public StartGameRequest(Long roomId, String roomCode) {
        this.roomId = roomId;
        this.roomCode = roomCode;
    }

    public Long getRoomId() {
        return roomId;
    }

    public void setRoomId(Long roomId) {
        this.roomId = roomId;
    }

    public String getRoomCode() {
        return roomCode;
    }

    public void setRoomCode(String roomCode) {
        this.roomCode = roomCode;
    }
}
