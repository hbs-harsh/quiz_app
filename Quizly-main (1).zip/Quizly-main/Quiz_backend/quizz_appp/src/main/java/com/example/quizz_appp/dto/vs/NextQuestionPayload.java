package com.example.quizz_appp.dto.vs;

import java.util.List;

public class NextQuestionPayload {

    private int questionIndex;
    private String question;
    private List<String> options;
    /** Per-question timer in seconds; same for both players (synced). */
    private int timerSeconds;

    public NextQuestionPayload(int questionIndex, String question, List<String> options) {
        this(questionIndex, question, options, 30);
    }

    public NextQuestionPayload(int questionIndex, String question, List<String> options, int timerSeconds) {
        this.questionIndex = questionIndex;
        this.question = question;
        this.options = options;
        this.timerSeconds = timerSeconds;
    }

    public int getQuestionIndex() {
        return questionIndex;
    }

    public void setQuestionIndex(int questionIndex) {
        this.questionIndex = questionIndex;
    }

    public String getQuestion() {
        return question;
    }

    public void setQuestion(String question) {
        this.question = question;
    }

    public List<String> getOptions() {
        return options;
    }

    public void setOptions(List<String> options) {
        this.options = options;
    }

    public int getTimerSeconds() {
        return timerSeconds;
    }

    public void setTimerSeconds(int timerSeconds) {
        this.timerSeconds = timerSeconds;
    }
}
