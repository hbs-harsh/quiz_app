package com.example.quizz_appp.entity;

import jakarta.persistence.*;

@Entity
@Table(name = "room_players",
        uniqueConstraints = @UniqueConstraint(columnNames = {"room_id", "userId"}))
public class RoomPlayer {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "room_id")
    private Room room;

    private String userId;

    private int score = 0;

    private boolean connected = true;

    // Getters
    public Long getId() {
        return id;
    }

    public Room getRoom() {
        return room;
    }

    public String getUserId() {
        return userId;
    }

    public int getScore() {
        return score;
    }

    public boolean isConnected() {
        return connected;
    }

    // Setters
    public void setId(Long id) {
        this.id = id;
    }

    public void setRoom(Room room) {
        this.room = room;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public void setScore(int score) {
        this.score = score;
    }

    public void setConnected(boolean connected) {
        this.connected = connected;
    }
}