package com.example.quizz_appp.dto.vs;

import com.example.quizz_appp.enums.RoomStatus;

public class RoomResponse {

    private Long roomId;
    private String roomCode;
    private RoomStatus status;
    /** The userId assigned by the server (may differ from request if same user joins twice). */
    private String assignedUserId;

    public RoomResponse(Long roomId, String roomCode, RoomStatus status) {
        this(roomId, roomCode, status, null);
    }

    public RoomResponse(Long roomId, String roomCode, RoomStatus status, String assignedUserId) {
        this.roomId = roomId;
        this.roomCode = roomCode;
        this.status = status;
        this.assignedUserId = assignedUserId;
    }

    public RoomResponse() {
    }

    public Long getRoomId() {
        return roomId;
    }

    public String getRoomCode() {
        return roomCode;
    }

    public RoomStatus getStatus() {
        return status;
    }

    public String getAssignedUserId() {
        return assignedUserId;
    }
}
