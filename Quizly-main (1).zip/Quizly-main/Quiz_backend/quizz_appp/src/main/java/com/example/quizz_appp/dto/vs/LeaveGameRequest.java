package com.example.quizz_appp.dto.vs;

public class LeaveGameRequest {
    private Long roomId;
    private String roomCode;
    private String userId;

    public LeaveGameRequest() {}

    public LeaveGameRequest(Long roomId, String roomCode, String userId) {
        this.roomId = roomId;
        this.roomCode = roomCode;
        this.userId = userId;
    }

    public Long getRoomId() {
        return roomId;
    }

    public void setRoomId(Long roomId) {
        this.roomId = roomId;
    }

    public String getRoomCode() {
        return roomCode;
    }

    public void setRoomCode(String roomCode) {
        this.roomCode = roomCode;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }
}
