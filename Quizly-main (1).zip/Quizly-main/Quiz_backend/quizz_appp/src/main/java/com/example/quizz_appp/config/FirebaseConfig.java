package com.example.quizz_appp.config;

import com.google.auth.oauth2.GoogleCredentials;
import com.google.firebase.FirebaseApp;
import com.google.firebase.FirebaseOptions;
import jakarta.annotation.PostConstruct;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;

@Configuration
public class FirebaseConfig {

    private static final Logger log = LoggerFactory.getLogger(FirebaseConfig.class);

    /**
     * Path to Firebase service account JSON. Can be:
     * - classpath:filename.json (from src/main/resources)
     * - Absolute or relative file path
     * Leave empty to skip Firebase init (e.g. for tests or when using mock auth).
     */
    @Value("${D:\\Quizly-main\\Quiz_backend\\quizz_appp\\firebase-service-account.json}")
    private String serviceAccountPath;

    @PostConstruct
    public void init() throws IOException {
        if (serviceAccountPath == null || serviceAccountPath.isBlank()) {
            log.warn("Firebase service account path not set (firebase.service-account-path). Auth filter will reject all requests until Firebase is configured.");
            return;
        }

        InputStream stream;
        if (serviceAccountPath.startsWith("classpath:")) {
            String resource = serviceAccountPath.substring("classpath:".length()).trim();
            stream = getClass().getClassLoader().getResourceAsStream(resource);
            if (stream == null) {
                throw new IllegalStateException("Firebase credentials not found on classpath: " + resource);
            }
        } else {
            stream = new FileInputStream(serviceAccountPath.trim());
        }

        try (InputStream s = stream) {
            FirebaseOptions options = FirebaseOptions.builder()
                    .setCredentials(GoogleCredentials.fromStream(s))
                    .build();

            if (FirebaseApp.getApps().isEmpty()) {
                FirebaseApp.initializeApp(options);
                log.info("Firebase initialized successfully");
            }
        }
    }
}

