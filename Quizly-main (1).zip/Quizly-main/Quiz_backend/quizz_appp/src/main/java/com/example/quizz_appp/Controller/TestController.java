package com.example.quizz_appp.Controller;

import com.example.quizz_appp.dto.UpdateProfileRequest;
import com.example.quizz_appp.entity.User;
import com.example.quizz_appp.repository.UserRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@RestController
public class TestController {

    private final UserRepository userRepository;

    public TestController(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    @GetMapping("/me")
    public ResponseEntity<Map<String, String>> me(Authentication authentication) {
        User user = (User) authentication.getPrincipal();

        Map<String, String> response = new HashMap<>();
        response.put("email", user.getEmail());
        response.put("firebaseUid", user.getFirebaseUid());
        response.put("displayName", user.getDisplayName() != null ? user.getDisplayName() : "");

        return ResponseEntity.ok(response);
    }

    @PatchMapping("/me")
    public ResponseEntity<Map<String, String>> updateProfile(
            Authentication authentication,
            @RequestBody UpdateProfileRequest request) {
        User user = (User) authentication.getPrincipal();

        String displayName = request.getDisplayName();
        if (displayName != null) {
            displayName = displayName.trim();
        }
        if (displayName == null || displayName.isEmpty()) {
            return ResponseEntity.badRequest()
                    .body(Map.of("error", "Validation failed", "message", "Display name is required"));
        }
        if (displayName.length() > 50) {
            return ResponseEntity.badRequest()
                    .body(Map.of("error", "Validation failed", "message", "Display name must be at most 50 characters"));
        }

        User entity = userRepository.findByFirebaseUid(user.getFirebaseUid())
                .orElseThrow(() -> new RuntimeException("User not found"));
        entity.setDisplayName(displayName);
        userRepository.save(entity);

        Map<String, String> response = new HashMap<>();
        response.put("email", entity.getEmail());
        response.put("firebaseUid", entity.getFirebaseUid());
        response.put("displayName", entity.getDisplayName());

        return ResponseEntity.ok(response);
    }
}
