package com.example.quizz_appp.service;

import com.example.quizz_appp.dto.QuizSubmitRequest;
import com.example.quizz_appp.entity.QuizzAttempt;
import com.example.quizz_appp.entity.User;
import com.example.quizz_appp.repository.QuizzAttemptRepository;
import jakarta.transaction.Transactional;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class QuizAttemptService {

    private final QuizzAttemptRepository quizAttemptRepository;
    private final QuizzService quizService;
    private final PointsService pointsService;

    public QuizAttemptService(QuizzAttemptRepository quizAttemptRepository,
                              QuizzService quizService,
                              PointsService pointsService) {
        this.quizAttemptRepository = quizAttemptRepository;
        this.quizService = quizService;
        this.pointsService = pointsService;
    }

    @Transactional
    public int submitQuiz(User user, QuizSubmitRequest request) {

        // 1️⃣ evaluate score using DTOs
        int score = quizService.evaluateQuiz(request.getQuestions());

        // 2️⃣ save quiz attempt
        QuizzAttempt attempt = new QuizzAttempt();
        attempt.setUser(user);
        attempt.setScore(score);
        attempt.setCategory(request.getCategory());

        quizAttemptRepository.save(attempt);

        // 3️⃣ update points
        pointsService.addPoints(user.getId(), score);

        return score;
    }
}
