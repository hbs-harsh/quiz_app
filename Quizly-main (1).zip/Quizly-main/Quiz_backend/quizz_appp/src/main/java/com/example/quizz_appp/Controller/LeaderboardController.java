package com.example.quizz_appp.Controller;

import com.example.quizz_appp.dto.LeaderboardEntryDTO;
import com.example.quizz_appp.dto.LeaderboardResponse;
import com.example.quizz_appp.entity.User;
import com.example.quizz_appp.repository.UserRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/leaderboard")
public class LeaderboardController {

    private static final Logger log = LoggerFactory.getLogger(LeaderboardController.class);

    private final UserRepository userRepository;

    public LeaderboardController(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    /**
     * Get leaderboard with top 200 players by wins.
     * Current user's rank uses authenticated user when userId is not provided.
     */
    @GetMapping
    public ResponseEntity<LeaderboardResponse> getLeaderboard(
            Authentication authentication,
            @RequestParam(required = false) String userId
    ) {
        if (userId == null || userId.isBlank()) {
            if (authentication != null && authentication.getPrincipal() instanceof User) {
                userId = ((User) authentication.getPrincipal()).getFirebaseUid();
            }
        }
        log.info("Fetching leaderboard, userId: {}", userId);

        // Get top 200 users by wins
        List<User> topUsers = userRepository.findTop200ByActiveTrueOrderByTotalWinsDescPointsDesc();

        List<LeaderboardEntryDTO> topPlayers = new ArrayList<>();
        int rank = 1;
        for (User user : topUsers) {
            String displayName = user.getDisplayName();
            if (displayName == null || displayName.isEmpty()) {
                displayName = "Player";
            }
            String publicUserId = user.getPublicUserId() != null ? user.getPublicUserId() : "—";
            topPlayers.add(new LeaderboardEntryDTO(
                    rank++,
                    displayName,
                    publicUserId,
                    user.getTotalWins(),
                    user.getPoints()
            ));
        }

        LeaderboardEntryDTO currentUserEntry = null;
        int currentUserRank = 0;

        // Get current user's rank if userId provided
        if (userId != null && !userId.isEmpty()) {
            Optional<User> currentUserOpt = userRepository.findByFirebaseUid(userId);
            if (currentUserOpt.isPresent()) {
                User currentUser = currentUserOpt.get();
                currentUserRank = userRepository.getUserRankByWins(
                        currentUser.getTotalWins(),
                        currentUser.getPoints()
                );
                
                String displayName = currentUser.getDisplayName();
                if (displayName == null || displayName.isEmpty()) {
                    displayName = "Player";
                }
                String publicUserId = currentUser.getPublicUserId() != null ? currentUser.getPublicUserId() : "—";
                currentUserEntry = new LeaderboardEntryDTO(
                        currentUserRank,
                        displayName,
                        publicUserId,
                        currentUser.getTotalWins(),
                        currentUser.getPoints()
                );
            }
        }

        LeaderboardResponse response = new LeaderboardResponse(topPlayers, currentUserEntry, currentUserRank);
        log.info("Returning {} leaderboard entries, current user rank: {}", topPlayers.size(), currentUserRank);
        
        return ResponseEntity.ok(response);
    }
}
