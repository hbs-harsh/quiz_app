package com.example.quizz_appp.dto.vs;

import java.util.Map;

public class GameCompletedPayload {

    private Map<String, Integer> finalScores;
    private String winnerId;
    private boolean isDraw;
    /** True when game ended because the other player left */
    private boolean opponentLeft;
    /** Map of userId (as in finalScores) to display name for multiplayer UI */
    private Map<String, String> playerDisplayNames;

    public GameCompletedPayload(Map<String, Integer> finalScores, String winnerId, boolean isDraw) {
        this.finalScores = finalScores;
        this.winnerId = winnerId;
        this.isDraw = isDraw;
        this.opponentLeft = false;
    }

    public GameCompletedPayload(Map<String, Integer> finalScores, String winnerId, boolean isDraw, boolean opponentLeft) {
        this.finalScores = finalScores;
        this.winnerId = winnerId;
        this.isDraw = isDraw;
        this.opponentLeft = opponentLeft;
    }

    public Map<String, String> getPlayerDisplayNames() {
        return playerDisplayNames;
    }

    public void setPlayerDisplayNames(Map<String, String> playerDisplayNames) {
        this.playerDisplayNames = playerDisplayNames;
    }

    public Map<String, Integer> getFinalScores() {
        return finalScores;
    }

    public void setFinalScores(Map<String, Integer> finalScores) {
        this.finalScores = finalScores;
    }

    public String getWinnerId() {
        return winnerId;
    }

    public void setWinnerId(String winnerId) {
        this.winnerId = winnerId;
    }

    public boolean isDraw() {
        return isDraw;
    }

    public void setDraw(boolean draw) {
        isDraw = draw;
    }

    public boolean isOpponentLeft() {
        return opponentLeft;
    }

    public void setOpponentLeft(boolean opponentLeft) {
        this.opponentLeft = opponentLeft;
    }
}
