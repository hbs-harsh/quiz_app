package com.example.quizz_appp.dto;

public class LeaderboardEntryDTO {
    private int rank;
    private String displayName;
    private String publicUserId;
    private int wins;
    private long points;

    public LeaderboardEntryDTO() {}

    public LeaderboardEntryDTO(int rank, String displayName, String publicUserId, int wins, long points) {
        this.rank = rank;
        this.displayName = displayName;
        this.publicUserId = publicUserId;
        this.wins = wins;
        this.points = points;
    }

    public int getRank() {
        return rank;
    }

    public void setRank(int rank) {
        this.rank = rank;
    }

    public String getDisplayName() {
        return displayName;
    }

    public void setDisplayName(String displayName) {
        this.displayName = displayName;
    }

    public String getPublicUserId() {
        return publicUserId;
    }

    public void setPublicUserId(String publicUserId) {
        this.publicUserId = publicUserId;
    }

    public int getWins() {
        return wins;
    }

    public void setWins(int wins) {
        this.wins = wins;
    }

    public long getPoints() {
        return points;
    }

    public void setPoints(long points) {
        this.points = points;
    }
}
