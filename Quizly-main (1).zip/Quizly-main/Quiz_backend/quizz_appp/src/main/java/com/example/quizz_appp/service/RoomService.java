package com.example.quizz_appp.service;

import com.example.quizz_appp.dto.vs.RoomCreateRequest;
import com.example.quizz_appp.entity.Room;
import com.example.quizz_appp.entity.RoomPlayer;
import com.example.quizz_appp.enums.QuizSourceType;
import com.example.quizz_appp.enums.RoomStatus;
import com.example.quizz_appp.repository.RoomPlayerRepository;
import com.example.quizz_appp.repository.RoomRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

@Service
public class RoomService {

    private final RoomRepository roomRepository;
    private final RoomPlayerRepository roomPlayerRepository;

    public RoomService(RoomRepository roomRepository,
                       RoomPlayerRepository roomPlayerRepository) {
        this.roomRepository = roomRepository;
        this.roomPlayerRepository = roomPlayerRepository;
    }

    // ==================================================
    // CREATE ROOM (User-1)
    // ==================================================
    public Room createRoom(RoomCreateRequest request, String userId) {

        // Validate exactly one quiz source
        validateQuizSource(request);

        Room room = new Room();
        room.setRoomCode(generateRoomCode());
        room.setCreatedByUserId(userId);
        room.setQuizSourceType(request.getQuizSourceType());
        room.setTopic(request.getTopic());
        room.setDocumentUrl(request.getDocumentUrl());
        room.setCustomPrompt(request.getCustomPrompt());
        room.setDifficulty(request.getDifficulty());
        room.setTimerPerQuestion(request.getTimerPerQuestion());
        room.setStatus(RoomStatus.WAITING);
        room.setCreatedAt(LocalDateTime.now());

        // Save room
        room = roomRepository.save(room);

        // Add host as first player
        RoomPlayer host = new RoomPlayer();
        host.setRoom(room);
        host.setUserId(userId);
        roomPlayerRepository.save(host);

        return room;
    }

    // ==================================================
    // JOIN ROOM (User-2)
    // ==================================================
    @Transactional
    public JoinRoomResult joinRoom(String roomCode, String userId) {

        Room room = roomRepository.findByRoomCode(roomCode)
                .orElseThrow(() -> new RuntimeException("Room not found"));

        List<RoomPlayer> players =
                roomPlayerRepository.findByRoom_Id(room.getId());

        // Check if user is already in the room (for reconnects)
        boolean alreadyJoined = players.stream()
                .anyMatch(p -> p.getUserId().equals(userId));

        // If user is already in the room, allow reconnect regardless of status
        if (alreadyJoined) {
            return new JoinRoomResult(room, userId);
        }

        // For new players, only WAITING rooms can be joined
        if (room.getStatus() != RoomStatus.WAITING) {
            throw new RuntimeException("Room is not open for joining");
        }

        // Max 2 players only
        if (players.size() >= 2) {
            throw new RuntimeException("Room already full");
        }

        // Check if host is trying to join as second player (same account, two devices)
        boolean hostRejoining = players.size() == 1 && 
                players.get(0).getUserId().equals(userId);
        String joinerUserId = hostRejoining ? (userId + "_2") : userId;

        // Add second player
        RoomPlayer joiner = new RoomPlayer();
        joiner.setRoom(room);
        joiner.setUserId(joinerUserId);
        roomPlayerRepository.save(joiner);

        // Move room to READY so host can start the game
        room.setStatus(RoomStatus.READY);
        roomRepository.save(room);

        return new JoinRoomResult(room, joinerUserId);
    }

    public static class JoinRoomResult {
        private final Room room;
        private final String assignedUserId;

        public JoinRoomResult(Room room, String assignedUserId) {
            this.room = room;
            this.assignedUserId = assignedUserId;
        }

        public Room getRoom() {
            return room;
        }

        public String getAssignedUserId() {
            return assignedUserId;
        }
    }

    // ==================================================
    // HELPERS
    // ==================================================
    private void validateQuizSource(RoomCreateRequest request) {
        // Upload PDF/Word is coming soon - friendly message
        if (request.getQuizSourceType() == QuizSourceType.DOCUMENT) {
            if (request.getDocumentUrl() == null || request.getDocumentUrl().isBlank()) {
                throw new RuntimeException(
                        "Upload PDF/Word is coming soon. Please select a subject/topic for now."
                );
            }
        }

        int count = 0;
        if (request.getTopic() != null && !request.getTopic().isBlank()) count++;
        if (request.getDocumentUrl() != null && !request.getDocumentUrl().isBlank()) count++;
        if (request.getCustomPrompt() != null && !request.getCustomPrompt().isBlank()) count++;

        if (count != 1) {
            throw new RuntimeException(
                    "Exactly one quiz source must be provided (topic / document / prompt)"
            );
        }
    }

    private String generateRoomCode() {
        return UUID.randomUUID()
                .toString()
                .substring(0, 6)
                .toUpperCase();
    }
}
