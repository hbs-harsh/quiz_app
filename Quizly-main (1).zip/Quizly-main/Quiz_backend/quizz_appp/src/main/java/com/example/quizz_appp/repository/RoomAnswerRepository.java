package com.example.quizz_appp.repository;

import com.example.quizz_appp.entity.RoomAnswer;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface RoomAnswerRepository
        extends JpaRepository<RoomAnswer, Long> {

    List<RoomAnswer> findByRoomIdAndQuestionIndex(
            Long roomId,
            int questionIndex
    );
}
