package com.example.quizz_appp.entity;

import jakarta.persistence.*;
import java.util.List;

@Entity
@Table(name = "room_questions")
public class RoomQuestion {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private Long roomId;

    private int questionIndex;

    private String question;

    @ElementCollection(fetch = FetchType.EAGER)
    @CollectionTable(name = "room_question_options", joinColumns = @JoinColumn(name = "room_question_id"))
    @Column(name = "option_text")
    private List<String> options;

    private int correctAnswer;

    // Default Constructor
    public RoomQuestion() {
    }

    // Parameterized Constructor
    public RoomQuestion(Long roomId, int questionIndex, String question, List<String> options, int correctAnswer) {
        this.roomId = roomId;
        this.questionIndex = questionIndex;
        this.question = question;
        this.options = options;
        this.correctAnswer = correctAnswer;
    }

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getRoomId() {
        return roomId;
    }

    public void setRoomId(Long roomId) {
        this.roomId = roomId;
    }

    public int getQuestionIndex() {
        return questionIndex;
    }

    public void setQuestionIndex(int questionIndex) {
        this.questionIndex = questionIndex;
    }

    public String getQuestion() {
        return question;
    }

    public void setQuestion(String question) {
        this.question = question;
    }

    public List<String> getOptions() {
        return options;
    }

    public void setOptions(List<String> options) {
        this.options = options;
    }

    public int getCorrectAnswer() {
        return correctAnswer;
    }

    public void setCorrectAnswer(int correctAnswer) {
        this.correctAnswer = correctAnswer;
    }
}