package com.example.quizz_appp.config;

import com.example.quizz_appp.entity.User;
import com.example.quizz_appp.repository.UserRepository;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseToken;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;
import java.util.List;
import java.util.Random;

@Component
public class FirebaseAuthFilter extends OncePerRequestFilter {

    private final UserRepository userRepository;

    public FirebaseAuthFilter(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    @Override
    protected void doFilterInternal(
            HttpServletRequest request,
            HttpServletResponse response,
            FilterChain filterChain)
            throws ServletException, IOException {

        String authHeader = request.getHeader("Authorization");

        if (authHeader != null && authHeader.startsWith("Bearer ")) {
            String firebaseToken = authHeader.substring(7).trim();
            if (firebaseToken.isEmpty()) {
                sendUnauthorized(response);
                return;
            }

            try {
                FirebaseToken decodedToken =
                        FirebaseAuth.getInstance().verifyIdToken(firebaseToken);

                String uid = decodedToken.getUid();
                String email = decodedToken.getEmail();
                String nameRaw = decodedToken.getName();
                final String displayNameForNewUser = (nameRaw != null && !nameRaw.isBlank()) ? nameRaw.trim() : null;

                // Server-side validation: email required for new account (Firebase email sign-up provides it)
                if (email == null || email.isBlank()) {
                    sendBadRequest(response, "Email is required");
                    return;
                }
                String emailTrimmed = email.trim();
                if (emailTrimmed.isEmpty()) {
                    sendBadRequest(response, "Email is required");
                    return;
                }

                final String emailForNewUser = emailTrimmed;

                // Map Firebase user → MySQL user
                User user = userRepository.findByFirebaseUid(uid)
                        .orElseGet(() -> {
                            User newUser = new User();
                            newUser.setFirebaseUid(uid);
                            newUser.setEmail(emailForNewUser);
                            if (displayNameForNewUser != null) {
                                newUser.setDisplayName(displayNameForNewUser);
                            }
                            newUser.setPublicUserId(generateUniquePublicUserId());
                            newUser.setActive(true);
                            newUser.setPoints(0);
                            return userRepository.save(newUser);
                        });

                // Existing user without publicUserId (created before this feature)
                if (user.getPublicUserId() == null || user.getPublicUserId().isBlank()) {
                    user.setPublicUserId(generateUniquePublicUserId());
                    userRepository.save(user);
                }

                Authentication authentication =
                        new UsernamePasswordAuthenticationToken(
                                user, null, List.of());

                SecurityContextHolder.getContext()
                        .setAuthentication(authentication);

            } catch (Exception e) {
                sendUnauthorized(response);
                return;
            }
        }

        filterChain.doFilter(request, response);
    }

    private static final String PUBLIC_ID_CHARS = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
    private static final int PUBLIC_ID_LENGTH = 8;
    private final Random random = new Random();

    private String generateUniquePublicUserId() {
        for (int attempt = 0; attempt < 20; attempt++) {
            StringBuilder sb = new StringBuilder("QUIZ-");
            for (int i = 0; i < PUBLIC_ID_LENGTH; i++) {
                sb.append(PUBLIC_ID_CHARS.charAt(random.nextInt(PUBLIC_ID_CHARS.length())));
            }
            String candidate = sb.toString();
            if (!userRepository.existsByPublicUserId(candidate)) {
                return candidate;
            }
        }
        throw new IllegalStateException("Could not generate unique public user ID");
    }

    private void sendUnauthorized(HttpServletResponse response) throws IOException {
        response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        response.getWriter().write("{\"error\":\"Unauthorized\",\"message\":\"Invalid or expired token\"}");
    }

    private void sendBadRequest(HttpServletResponse response, String message) throws IOException {
        response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        String jsonMessage = message == null ? "" : message.replace("\"", "\\\"");
        response.getWriter().write("{\"error\":\"Validation failed\",\"message\":\"" + jsonMessage + "\"}");
    }
}
