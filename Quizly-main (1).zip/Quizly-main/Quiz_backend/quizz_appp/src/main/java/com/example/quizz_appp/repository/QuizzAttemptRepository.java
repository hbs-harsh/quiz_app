package com.example.quizz_appp.repository;

import com.example.quizz_appp.entity.QuizzAttempt;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface QuizzAttemptRepository extends JpaRepository<QuizzAttempt, Long> {

    List<QuizzAttempt> findByUser_Id(Long userId);

    long countByUser_Id(Long userId);

    Optional<QuizzAttempt> findTopByUser_IdOrderByScoreDesc(Long userId);
}
