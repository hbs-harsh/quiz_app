package com.example.quizz_appp.dto.vs;


public class RoomJoinRequest {

    private String roomCode;
    /** Firebase UID of the user joining (when auth is enabled). */
    private String userId;

    public String getRoomCode() {
        return roomCode;
    }

    public void setRoomCode(String roomCode) {
        this.roomCode = roomCode;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }
}