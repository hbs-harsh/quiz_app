package com.example.quizz_appp.dto.vs;

import com.example.quizz_appp.enums.QuizSourceType;

public class RoomCreateRequest {

    private QuizSourceType quizSourceType;
    private String topic;
    private String documentUrl;
    private String customPrompt;
    private String difficulty;
    private int timerPerQuestion;
    /** Firebase UID of the user creating the room (when auth is enabled). */
    private String userId;

    // Getters
    public QuizSourceType getQuizSourceType() {
        return quizSourceType;
    }

    public String getTopic() {
        return topic;
    }

    public String getDocumentUrl() {
        return documentUrl;
    }

    public String getCustomPrompt() {
        return customPrompt;
    }

    public String getDifficulty() {
        return difficulty;
    }

    public int getTimerPerQuestion() {
        return timerPerQuestion;
    }

    public String getUserId() {
        return userId;
    }

    // Setters
    public void setQuizSourceType(QuizSourceType quizSourceType) {
        this.quizSourceType = quizSourceType;
    }

    public void setTopic(String topic) {
        this.topic = topic;
    }

    public void setDocumentUrl(String documentUrl) {
        this.documentUrl = documentUrl;
    }

    public void setCustomPrompt(String customPrompt) {
        this.customPrompt = customPrompt;
    }

    public void setDifficulty(String difficulty) {
        this.difficulty = difficulty;
    }

    public void setTimerPerQuestion(int timerPerQuestion) {
        this.timerPerQuestion = timerPerQuestion;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }
}