package com.example.quizz_appp.entity;

import com.example.quizz_appp.enums.QuizSourceType;
import com.example.quizz_appp.enums.RoomStatus;
import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "rooms")
public class Room {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(unique = true, nullable = false)
    private String roomCode;

    @Column(nullable = false)
    private String createdByUserId;

    @Enumerated(EnumType.STRING)
    private QuizSourceType quizSourceType;

    private String topic;
    private String documentUrl;

    @Column(length = 1000)
    private String customPrompt;

    private String difficulty;
    private int timerPerQuestion;

    @Enumerated(EnumType.STRING)
    private RoomStatus status;

    private int currentQuestionIndex = 0;

    private LocalDateTime createdAt;

    @PrePersist
    protected void onCreate() {
        this.createdAt = LocalDateTime.now();
    }

    // Getters
    public Long getId() {
        return id;
    }

    public String getRoomCode() {
        return roomCode;
    }

    public String getCreatedByUserId() {
        return createdByUserId;
    }

    public QuizSourceType getQuizSourceType() {
        return quizSourceType;
    }

    public String getTopic() {
        return topic;
    }

    public String getDocumentUrl() {
        return documentUrl;
    }

    public String getCustomPrompt() {
        return customPrompt;
    }

    public String getDifficulty() {
        return difficulty;
    }

    public int getTimerPerQuestion() {
        return timerPerQuestion;
    }

    public RoomStatus getStatus() {
        return status;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    // Setters
    public void setId(Long id) {
        this.id = id;
    }

    public void setRoomCode(String roomCode) {
        this.roomCode = roomCode;
    }

    public void setCreatedByUserId(String createdByUserId) {
        this.createdByUserId = createdByUserId;
    }

    public void setQuizSourceType(QuizSourceType quizSourceType) {
        this.quizSourceType = quizSourceType;
    }

    public void setTopic(String topic) {
        this.topic = topic;
    }

    public void setDocumentUrl(String documentUrl) {
        this.documentUrl = documentUrl;
    }

    public void setCustomPrompt(String customPrompt) {
        this.customPrompt = customPrompt;
    }

    public void setDifficulty(String difficulty) {
        this.difficulty = difficulty;
    }

    public void setTimerPerQuestion(int timerPerQuestion) {
        this.timerPerQuestion = timerPerQuestion;
    }

    public void setStatus(RoomStatus status) {
        this.status = status;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public int getCurrentQuestionIndex() {
        return currentQuestionIndex;
    }

    public void setCurrentQuestionIndex(int currentQuestionIndex) {
        this.currentQuestionIndex = currentQuestionIndex;
    }
}