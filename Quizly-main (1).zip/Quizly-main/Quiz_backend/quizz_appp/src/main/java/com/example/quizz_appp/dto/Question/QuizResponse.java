package com.example.quizz_appp.dto.Question;

import java.util.List;


import java.util.List;

public class QuizResponse {
    private String category;
    private String difficulty;
    private List<QuestionDTO> questions;

    // Getters
    public String getCategory() { return category; }
    public String getDifficulty() { return difficulty; }
    public List<QuestionDTO> getQuestions() { return questions; }

    // Setters
    public void setCategory(String category) { this.category = category; }
    public void setDifficulty(String difficulty) { this.difficulty = difficulty; }
    public void setQuestions(List<QuestionDTO> questions) { this.questions = questions; }
}
