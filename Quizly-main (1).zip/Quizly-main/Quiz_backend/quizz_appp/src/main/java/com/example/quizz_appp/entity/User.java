package com.example.quizz_appp.entity;

import jakarta.persistence.*;

import java.security.Principal;

@Entity
@Table(name = "users")
public class User implements Principal {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    // 🔐 Firebase identity bridge
    @Column(nullable = false, unique = true)
    private String firebaseUid;

    // Email from Firebase token
    @Column(nullable = false, unique = true)
    private String email;

    // Display name (from Firebase or user-set)
    private String displayName;

    /** Unique public ID for display (e.g. leaderboard). Set once at creation, immutable. */
    @Column(unique = true)
    private String publicUserId;

    @Column(nullable = false)
    private boolean active;

    private long points;

    // Multiplayer stats
    private int totalWins = 0;
    private int totalLosses = 0;
    private int totalGamesPlayed = 0;

    // 🔹 JPA needs this
    public User() {}

    // 🔹 Convenience constructor
    public User(String firebaseUid, String email) {
        this.firebaseUid = firebaseUid;
        this.email = email;
        this.active = true;
        this.points = 0;
        this.totalWins = 0;
        this.totalLosses = 0;
        this.totalGamesPlayed = 0;
    }

    // 🔹 Getters & Setters

    public Long getId() {
        return id;
    }

    public String getFirebaseUid() {
        return firebaseUid;
    }

    public void setFirebaseUid(String firebaseUid) {
        this.firebaseUid = firebaseUid;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public boolean isActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }

    public long getPoints() {
        return points;
    }

    public void setPoints(long points) {
        this.points = points;
    }

    public String getDisplayName() {
        return displayName;
    }

    public void setDisplayName(String displayName) {
        this.displayName = displayName;
    }

    public String getPublicUserId() {
        return publicUserId;
    }

    public void setPublicUserId(String publicUserId) {
        this.publicUserId = publicUserId;
    }

    public int getTotalWins() {
        return totalWins;
    }

    public void setTotalWins(int totalWins) {
        this.totalWins = totalWins;
    }

    public int getTotalLosses() {
        return totalLosses;
    }

    public void setTotalLosses(int totalLosses) {
        this.totalLosses = totalLosses;
    }

    public int getTotalGamesPlayed() {
        return totalGamesPlayed;
    }

    public void setTotalGamesPlayed(int totalGamesPlayed) {
        this.totalGamesPlayed = totalGamesPlayed;
    }

    public void incrementWins() {
        this.totalWins++;
        this.totalGamesPlayed++;
    }

    public void incrementLosses() {
        this.totalLosses++;
        this.totalGamesPlayed++;
    }

    /** Principal name for WebSocket and security (Firebase UID). */
    @Override
    public String getName() {
        return firebaseUid;
    }
}
