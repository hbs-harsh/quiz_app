package com.example.quizz_appp.dto;

import java.util.List;

public class LeaderboardResponse {
    private List<LeaderboardEntryDTO> topPlayers;
    private LeaderboardEntryDTO currentUser;
    private int currentUserRank;

    public LeaderboardResponse() {}

    public LeaderboardResponse(List<LeaderboardEntryDTO> topPlayers, LeaderboardEntryDTO currentUser, int currentUserRank) {
        this.topPlayers = topPlayers;
        this.currentUser = currentUser;
        this.currentUserRank = currentUserRank;
    }

    public List<LeaderboardEntryDTO> getTopPlayers() {
        return topPlayers;
    }

    public void setTopPlayers(List<LeaderboardEntryDTO> topPlayers) {
        this.topPlayers = topPlayers;
    }

    public LeaderboardEntryDTO getCurrentUser() {
        return currentUser;
    }

    public void setCurrentUser(LeaderboardEntryDTO currentUser) {
        this.currentUser = currentUser;
    }

    public int getCurrentUserRank() {
        return currentUserRank;
    }

    public void setCurrentUserRank(int currentUserRank) {
        this.currentUserRank = currentUserRank;
    }
}
