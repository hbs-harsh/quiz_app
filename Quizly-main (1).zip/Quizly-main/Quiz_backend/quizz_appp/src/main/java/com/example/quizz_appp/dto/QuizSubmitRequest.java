package com.example.quizz_appp.dto;

import java.util.List;

public class QuizSubmitRequest {

    private String category;
    private List<QuestionAnswerDTO> questions;

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public List<QuestionAnswerDTO> getQuestions() {
        return questions;
    }

    public void setQuestions(List<QuestionAnswerDTO> questions) {
        this.questions = questions;
    }
}

