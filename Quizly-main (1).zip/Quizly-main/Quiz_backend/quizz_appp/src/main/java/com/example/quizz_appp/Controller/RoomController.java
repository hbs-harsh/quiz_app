package com.example.quizz_appp.Controller;

import com.example.quizz_appp.dto.SocketMessage;
import com.example.quizz_appp.dto.vs.RoomCreateRequest;
import com.example.quizz_appp.dto.vs.RoomJoinRequest;
import com.example.quizz_appp.dto.vs.RoomResponse;
import com.example.quizz_appp.entity.Room;
import com.example.quizz_appp.entity.User;
import com.example.quizz_appp.enums.SocketEventType;
import com.example.quizz_appp.service.RoomService;
import org.springframework.http.ResponseEntity;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/1v1/room")
public class RoomController {

        private final RoomService roomService;
        private final SimpMessagingTemplate messagingTemplate;

        public RoomController(RoomService roomService, SimpMessagingTemplate messagingTemplate) {
                this.roomService = roomService;
                this.messagingTemplate = messagingTemplate;
        }

        private static String getAuthenticatedUserId(Authentication authentication) {
                if (authentication == null || !(authentication.getPrincipal() instanceof User)) {
                        throw new SecurityException("Not authenticated");
                }
                return ((User) authentication.getPrincipal()).getFirebaseUid();
        }

        // -----------------------------
        // CREATE ROOM (uses authenticated user)
        // -----------------------------
        @PostMapping("/create")
        public ResponseEntity<RoomResponse> createRoom(
                        Authentication authentication,
                        @RequestBody RoomCreateRequest request) {
                String userId = getAuthenticatedUserId(authentication);

                Room room = roomService.createRoom(request, userId);

                return ResponseEntity.ok(
                                new RoomResponse(room.getId(), room.getRoomCode(), room.getStatus(), userId));
        }

        // -----------------------------
        // JOIN ROOM (uses authenticated user)
        // -----------------------------
        @PostMapping("/join")
        public ResponseEntity<RoomResponse> joinRoom(
                        Authentication authentication,
                        @RequestBody RoomJoinRequest request) {
                String userId = getAuthenticatedUserId(authentication);

                RoomService.JoinRoomResult result = roomService.joinRoom(
                                request.getRoomCode(),
                                userId);

                Room room = result.getRoom();

                // Notify the room (host) that a player has joined
                if (room.getStatus() == com.example.quizz_appp.enums.RoomStatus.READY) {
                        SocketMessage playerJoinedMsg = new SocketMessage(
                                SocketEventType.PLAYER_JOINED,
                                Map.of(
                                        "userId", result.getAssignedUserId(),
                                        "roomStatus", room.getStatus().name(),
                                        "playerCount", 2
                                )
                        );
                        messagingTemplate.convertAndSend(
                                "/topic/room/" + room.getRoomCode(),
                                playerJoinedMsg
                        );
                }

                return ResponseEntity.ok(
                                new RoomResponse(
                                        room.getId(),
                                        room.getRoomCode(),
                                        room.getStatus(),
                                        result.getAssignedUserId()));
        }
}
