package com.example.quizz_appp.repository;

import com.example.quizz_appp.entity.RoomQuestion;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface RoomQuestionRepository
        extends JpaRepository<RoomQuestion, Long> {

    List<RoomQuestion> findByRoomIdOrderByQuestionIndex(Long roomId);
}

