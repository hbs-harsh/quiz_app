package com.example.quizz_appp.Controller;

import com.example.quizz_appp.dto.SocketMessage;
import com.example.quizz_appp.dto.vs.AnswerMessage;
import com.example.quizz_appp.dto.vs.AnswerResultPayload;
import com.example.quizz_appp.dto.vs.GameCompletedPayload;
import com.example.quizz_appp.dto.vs.NextQuestionPayload;
import com.example.quizz_appp.entity.RoomQuestion;
import com.example.quizz_appp.entity.User;
import com.example.quizz_appp.enums.SocketEventType;
import com.example.quizz_appp.service.QuizGameService;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.handler.annotation.Payload;
import com.example.quizz_appp.dto.vs.LeaveGameRequest;
import com.example.quizz_appp.dto.vs.StartGameRequest;
import com.example.quizz_appp.entity.Room;
import com.example.quizz_appp.repository.RoomRepository;
import com.example.quizz_appp.service.QuizGameService.AnswerSubmissionResult;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Controller;

import java.security.Principal;
import java.util.Map;

@Controller
public class QuizSocketController {

        private static final Logger log = LoggerFactory.getLogger(QuizSocketController.class);

        private final SimpMessagingTemplate messagingTemplate;
        private final QuizGameService quizGameService;
        private final RoomRepository roomRepository;

        public QuizSocketController(
                        SimpMessagingTemplate messagingTemplate,
                        QuizGameService quizGameService,
                        RoomRepository roomRepository) {
                this.messagingTemplate = messagingTemplate;
                this.quizGameService = quizGameService;
                this.roomRepository = roomRepository;
        }

        /** Validates that the message's userId is the connected user (or same user as second player _2). */
        private static void validateUserId(Principal principal, String messageUserId) {
                if (principal == null || !(principal instanceof User)) {
                        throw new SecurityException("Not authenticated");
                }
                String firebaseUid = ((User) principal).getFirebaseUid();
                boolean allowed = firebaseUid.equals(messageUserId)
                        || (firebaseUid + "_2").equals(messageUserId);
                if (!allowed) {
                        throw new SecurityException("UserId does not match authenticated user");
                }
        }

        /** Validates that the principal is the room creator (only host can start). */
        private void validateRoomHost(Principal principal, Long roomId) {
                if (principal == null || !(principal instanceof User)) {
                        throw new SecurityException("Not authenticated");
                }
                Room room = roomRepository.findById(roomId)
                        .orElseThrow(() -> new SecurityException("Room not found"));
                String firebaseUid = ((User) principal).getFirebaseUid();
                if (!firebaseUid.equals(room.getCreatedByUserId())) {
                        throw new SecurityException("Only room host can start the game");
                }
        }

        // ============================================
        // START GAME
        // ============================================
        @MessageMapping("/start")
        public void startGame(Principal principal, @Payload StartGameRequest request) {
                validateRoomHost(principal, request.getRoomId());
                try {
                        // Validate that both players have joined before starting
                        RoomQuestion firstQuestion = quizGameService.generateQuizForRoom(request.getRoomId());
                        Room room = roomRepository.findById(request.getRoomId())
                                        .orElseThrow(() -> new RuntimeException("Room not found"));
                        int timerSeconds = room.getTimerPerQuestion();

                        SocketMessage startMsg = new SocketMessage(
                                        SocketEventType.START_QUESTION,
                                        new NextQuestionPayload(
                                                        firstQuestion.getQuestionIndex(),
                                                        firstQuestion.getQuestion(),
                                                        firstQuestion.getOptions(),
                                                        timerSeconds));

                        log.info("🎮 Starting game - RoomId: {}, RoomCode: {}, Timer: {}s", request.getRoomId(), request.getRoomCode(), timerSeconds);

                        messagingTemplate.convertAndSend(
                                        "/topic/room/" + request.getRoomCode(),
                                        startMsg);
                } catch (RuntimeException e) {
                        log.error("❌ Cannot start game - RoomId: {}, RoomCode: {}, Error: {}",
                                        request.getRoomId(), request.getRoomCode(), e.getMessage());
                        // Optionally send error message to client via WebSocket
                        // For now, just log the error
                }
        }

        // ============================================
        // ANSWER SUBMISSION
        // ============================================
        @MessageMapping("/answer")
        public void handleAnswer(Principal principal, @Payload AnswerMessage message) {
                validateUserId(principal, message.getUserId());
                AnswerSubmissionResult result;
                
                try {
                        result = quizGameService.submitAnswer(
                                        message.getRoomId(),
                                        message.getUserId(),
                                        message.getQuestionIndex(),
                                        message.getSelectedOption());
                } catch (RuntimeException e) {
                        // Handle validation errors (duplicate answer, wrong question, etc.)
                        log.error("❌ Answer submission failed - RoomId: {}, UserId: {}, Question: {}, Error: {}",
                                        message.getRoomId(), message.getUserId(), message.getQuestionIndex(), e.getMessage());
                        // Don't broadcast anything, just log the error
                        return;
                }

                // 1. Broadcast answer result to both players
                SocketMessage answerResultMsg = new SocketMessage(
                                SocketEventType.ANSWER_RESULT,
                                new AnswerResultPayload(
                                                message.getUserId(),
                                                message.getQuestionIndex(),
                                                message.getSelectedOption(),
                                                result.isCorrect()));

                messagingTemplate.convertAndSend(
                                "/topic/room/" + message.getRoomCode(),
                                answerResultMsg);

                // 2. Check if both players answered and room should advance
                if (result.isBothPlayersAnswered()) {
                        if (result.isShouldAdvance()) {
                                // Broadcast next question to both players (with same timer for sync)
                                RoomQuestion nextQ = result.getNextQuestion();
                                Room room = roomRepository.findById(message.getRoomId())
                                                .orElseThrow(() -> new RuntimeException("Room not found"));
                                int timerSeconds = room.getTimerPerQuestion();
                                SocketMessage nextQuestionMsg = new SocketMessage(
                                                SocketEventType.NEXT_QUESTION,
                                                new NextQuestionPayload(
                                                                nextQ.getQuestionIndex(),
                                                                nextQ.getQuestion(),
                                                                nextQ.getOptions(),
                                                                timerSeconds));

                                log.info("📤 Broadcasting NEXT_QUESTION to room {} - Question {}, Timer: {}s",
                                                message.getRoomCode(), nextQ.getQuestionIndex(), timerSeconds);

                                messagingTemplate.convertAndSend(
                                                "/topic/room/" + message.getRoomCode(),
                                                nextQuestionMsg);
                        } else if (result.isGameCompleted()) {
                                // Broadcast game completion with scores
                                Map<String, Integer> scores = result.getFinalScores();
                                
                                log.info("🎯 Game completed! Final scores: {}", scores);

                                // Determine winner
                                String winnerId = null;
                                boolean isDraw = false;
                                int maxScore = -1;
                                int winnerCount = 0;

                                for (Map.Entry<String, Integer> entry : scores.entrySet()) {
                                        log.info("🎯 Checking player {} with score {}", entry.getKey(), entry.getValue());
                                        if (entry.getValue() > maxScore) {
                                                maxScore = entry.getValue();
                                                winnerId = entry.getKey();
                                                winnerCount = 1;
                                        } else if (entry.getValue() == maxScore) {
                                                winnerCount++;
                                        }
                                }

                                isDraw = winnerCount > 1;
                                if (isDraw)
                                        winnerId = null;

                                log.info("🎯 Winner determined - WinnerId: {}, IsDraw: {}, MaxScore: {}",
                                                winnerId, isDraw, maxScore);

                                GameCompletedPayload payload = new GameCompletedPayload(scores, winnerId, isDraw);
                                payload.setPlayerDisplayNames(quizGameService.getPlayerDisplayNamesForRoom(message.getRoomId()));

                                SocketMessage gameOverMsg = new SocketMessage(
                                                SocketEventType.GAME_OVER,
                                                payload);

                                log.info("📤 Broadcasting GAME_OVER to room {} - Scores: {}, Winner: {}, Draw: {}",
                                                message.getRoomCode(), scores, winnerId, isDraw);

                                messagingTemplate.convertAndSend(
                                                "/topic/room/" + message.getRoomCode(),
                                                gameOverMsg);
                                
                                log.info("✅ GAME_OVER message sent successfully");
                        }
                }
        }

        // ============================================
        // PLAYER LEAVE / QUIT GAME
        // ============================================
        @MessageMapping("/leave")
        public void handleLeave(Principal principal, @Payload LeaveGameRequest request) {
                validateUserId(principal, request.getUserId());
                try {
                        GameCompletedPayload payload =
                                        quizGameService.playerLeft(request.getRoomId(), request.getUserId());
                        payload.setPlayerDisplayNames(quizGameService.getPlayerDisplayNamesForRoom(request.getRoomId()));

                        SocketMessage gameOverMsg = new SocketMessage(
                                        SocketEventType.GAME_OVER,
                                        payload);

                        log.info("📤 Broadcasting GAME_OVER (player left) to room {} - Winner: {}",
                                        request.getRoomCode(), payload.getWinnerId());

                        messagingTemplate.convertAndSend(
                                        "/topic/room/" + request.getRoomCode(),
                                        gameOverMsg);
                } catch (RuntimeException e) {
                        log.error("❌ Leave game failed - RoomId: {}, UserId: {}, Error: {}",
                                        request.getRoomId(), request.getUserId(), e.getMessage());
                }
        }
}
