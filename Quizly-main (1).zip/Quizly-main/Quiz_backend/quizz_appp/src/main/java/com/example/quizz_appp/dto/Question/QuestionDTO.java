package com.example.quizz_appp.dto.Question;

import java.util.List;

public class QuestionDTO {
    private String question;
    private List<String> options;
    private int correctAnswer;

    /** No-args constructor for JSON deserialization (e.g. from Python AI service). */
    public QuestionDTO() {
    }

    public QuestionDTO(int correctAnswer, String question, List<String> options) {
        this.correctAnswer = correctAnswer;
        this.question = question;
        this.options = options;
    }

    // Getters
    public String getQuestion() {
        return question;
    }

    public List<String> getOptions() {
        return options;
    }

    public int getCorrectAnswer() {
        return correctAnswer;
    }

    // Setters
    public void setQuestion(String question) {
        this.question = question;
    }

    public void setOptions(List<String> options) {
        this.options = options;
    }

    public void setCorrectAnswer(int correctAnswer) {
        this.correctAnswer = correctAnswer;
    }
}