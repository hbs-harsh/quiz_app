package com.example.quizz_appp.Controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * Supported quiz subjects/topics for 1v1 rooms.
 * Upload PDF/Word is planned (coming soon).
 */
@RestController
@RequestMapping("/1v1")
public class SubjectController {

    @GetMapping("/subjects")
    public List<SubjectItem> getSubjects() {
        return List.of(
                new SubjectItem("NEET_UG", "NEET UG"),
                new SubjectItem("JEE", "JEE"),
                new SubjectItem("JEE_Advanced", "JEE Advanced"),
                new SubjectItem("Physics", "Physics"),
                new SubjectItem("Chemistry", "Chemistry"),
                new SubjectItem("Mathematics", "Mathematics"),
                new SubjectItem("Biology", "Biology"),
                new SubjectItem("GATE", "GATE"),
                new SubjectItem("Computer_Science", "Computer Science (B.Tech)"),
                new SubjectItem("General_Knowledge", "General Knowledge"),
                new SubjectItem("History", "History"),
                new SubjectItem("Geography", "Geography"),
                new SubjectItem("Current_Affairs", "Current Affairs")
        );
    }

    public static class SubjectItem {
        private final String id;
        private final String displayName;

        public SubjectItem(String id, String displayName) {
            this.id = id;
            this.displayName = displayName;
        }

        public String getId() {
            return id;
        }

        public String getDisplayName() {
            return displayName;
        }
    }
}
