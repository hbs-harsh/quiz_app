package com.example.quizz_appp.repository;

import com.example.quizz_appp.entity.User;
import jakarta.transaction.Transactional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

public interface UserRepository extends JpaRepository<User, Long> {

    Optional<User> findByEmail(String email);

    boolean existsByEmail(String email);

    Optional<User> findByFirebaseUid(String firebaseUid);

    boolean existsByPublicUserId(String publicUserId);

    List<User> findByActiveTrue();

    List<User> findTop10ByOrderByPointsDesc();

    // Leaderboard: Top N users by wins
    List<User> findTop200ByActiveTrueOrderByTotalWinsDescPointsDesc();

    // Get user's rank by wins
    @Query("SELECT COUNT(u) + 1 FROM User u WHERE u.active = true AND " +
           "(u.totalWins > :wins OR (u.totalWins = :wins AND u.points > :points))")
    int getUserRankByWins(@Param("wins") int wins, @Param("points") long points);

    @Modifying
    @Transactional
    @Query("UPDATE User u SET u.points = u.points + :points WHERE u.id = :userId")
    void addPoints(@Param("userId") Long userId,
                   @Param("points") long points);

    @Modifying
    @Transactional
    @Query("UPDATE User u SET u.totalWins = u.totalWins + 1, u.totalGamesPlayed = u.totalGamesPlayed + 1 WHERE u.firebaseUid = :firebaseUid")
    void incrementWins(@Param("firebaseUid") String firebaseUid);

    @Modifying
    @Transactional
    @Query("UPDATE User u SET u.totalLosses = u.totalLosses + 1, u.totalGamesPlayed = u.totalGamesPlayed + 1 WHERE u.firebaseUid = :firebaseUid")
    void incrementLosses(@Param("firebaseUid") String firebaseUid);

}

