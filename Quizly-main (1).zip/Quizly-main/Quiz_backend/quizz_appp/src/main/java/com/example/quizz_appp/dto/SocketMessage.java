package com.example.quizz_appp.dto;


import com.example.quizz_appp.enums.SocketEventType;

public class SocketMessage {

    private SocketEventType type;
    private Object payload;

    public SocketMessage(SocketEventType type, Object payload) {
        this.type = type;
        this.payload = payload;
    }

    public SocketEventType getType() {
        return type;
    }

    public Object getPayload() {
        return payload;
    }
}

