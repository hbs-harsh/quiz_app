package com.example.quizz_appp.service;

import com.example.quizz_appp.dto.Question.QuestionDTO;
import com.example.quizz_appp.dto.Question.QuizResponse;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

@Service
public class MockQuizService {

    private static final List<QuestionDTO> ALL_QUESTIONS = List.of(
            new QuestionDTO(0, "Who was the first Prime Minister of India?",
                    List.of("Jawaharlal Nehru", "Mahatma Gandhi", "Sardar Patel", "Subhas Chandra Bose")),
            new QuestionDTO(2, "In which year did India gain independence?",
                    List.of("1942", "1945", "1947", "1950")),
            new QuestionDTO(1, "Who founded the Maurya Empire?",
                    List.of("Ashoka", "Chandragupta Maurya", "Bindusara", "Bimbisara")),
            new QuestionDTO(0, "What is the capital of India?",
                    List.of("New Delhi", "Mumbai", "Kolkata", "Chennai")),
            new QuestionDTO(2, "Which planet is known as the Red Planet?",
                    List.of("Venus", "Jupiter", "Mars", "Saturn")),
            new QuestionDTO(1, "What is the chemical symbol for water?",
                    List.of("O2", "H2O", "CO2", "NaCl")),
            new QuestionDTO(3, "Who wrote 'Romeo and Juliet'?",
                    List.of("Charles Dickens", "Jane Austen", "Mark Twain", "William Shakespeare")),
            new QuestionDTO(0, "What is the largest ocean on Earth?",
                    List.of("Pacific Ocean", "Atlantic Ocean", "Indian Ocean", "Arctic Ocean")),
            new QuestionDTO(2, "In which year did World War II end?",
                    List.of("1943", "1944", "1945", "1946")),
            new QuestionDTO(1, "Who painted the Mona Lisa?",
                    List.of("Vincent van Gogh", "Leonardo da Vinci", "Pablo Picasso", "Michelangelo")),
            new QuestionDTO(0, "What is the speed of light (approx)?",
                    List.of("300,000 km/s", "150,000 km/s", "450,000 km/s", "200,000 km/s")),
            new QuestionDTO(3, "Which element has the atomic number 1?",
                    List.of("Helium", "Oxygen", "Carbon", "Hydrogen")),
            new QuestionDTO(1, "What is the largest mammal?",
                    List.of("Elephant", "Blue Whale", "Giraffe", "Hippopotamus")),
            new QuestionDTO(0, "Who developed the theory of relativity?",
                    List.of("Albert Einstein", "Isaac Newton", "Galileo Galilei", "Nikola Tesla")),
            new QuestionDTO(2, "What is the hardest natural substance?",
                    List.of("Gold", "Iron", "Diamond", "Platinum")),
            new QuestionDTO(1, "Which country is known as the Land of Rising Sun?",
                    List.of("China", "Japan", "Korea", "Thailand")),
            new QuestionDTO(0, "What is the smallest prime number?",
                    List.of("2", "1", "3", "0")),
            new QuestionDTO(3, "Who discovered penicillin?",
                    List.of("Louis Pasteur", "Marie Curie", "Robert Koch", "Alexander Fleming")),
            new QuestionDTO(2, "What is the chemical formula for table salt?",
                    List.of("KCl", "CaCl2", "NaCl", "MgCl2")),
            new QuestionDTO(0, "Which blood type is known as the universal donor?",
                    List.of("O negative", "A positive", "B negative", "AB positive")),
            new QuestionDTO(1, "What is the largest planet in our solar system?",
                    List.of("Saturn", "Jupiter", "Neptune", "Uranus")),
            new QuestionDTO(3, "Who invented the telephone?",
                    List.of("Thomas Edison", "Nikola Tesla", "Guglielmo Marconi", "Alexander Graham Bell")),
            new QuestionDTO(0, "What is the boiling point of water in Celsius?",
                    List.of("100°C", "90°C", "110°C", "80°C")),
            new QuestionDTO(2, "Which organ pumps blood in the human body?",
                    List.of("Liver", "Lungs", "Heart", "Kidney")),
            new QuestionDTO(1, "What is the capital of France?",
                    List.of("London", "Paris", "Berlin", "Rome")),
            new QuestionDTO(0, "How many continents are there on Earth?",
                    List.of("7", "6", "5", "8")),
            new QuestionDTO(3, "What is the main gas in Earth's atmosphere?",
                    List.of("Oxygen", "Carbon Dioxide", "Hydrogen", "Nitrogen")),
            new QuestionDTO(2, "Who was the first person to walk on the Moon?",
                    List.of("Buzz Aldrin", "Yuri Gagarin", "Neil Armstrong", "Michael Collins")),
            new QuestionDTO(1, "What is the currency of Japan?",
                    List.of("Won", "Yen", "Yuan", "Ringgit")),
            new QuestionDTO(0, "Which vitamin is produced when skin is exposed to sunlight?",
                    List.of("Vitamin D", "Vitamin C", "Vitamin A", "Vitamin B12")),
            new QuestionDTO(2, "What is the longest river in the world?",
                    List.of("Amazon", "Mississippi", "Nile", "Yangtze")),
            new QuestionDTO(1, "Who is known as the Father of Computers?",
                    List.of("Alan Turing", "Charles Babbage", "Bill Gates", "Steve Jobs")),
            new QuestionDTO(0, "What is the SI unit of force?",
                    List.of("Newton", "Joule", "Watt", "Pascal")),
            new QuestionDTO(3, "Which gas do plants absorb during photosynthesis?",
                    List.of("Oxygen", "Nitrogen", "Hydrogen", "Carbon Dioxide")),
            new QuestionDTO(2, "What is the square root of 144?",
                    List.of("10", "11", "12", "14")),
            new QuestionDTO(0, "Who wrote the national anthem of India?",
                    List.of("Rabindranath Tagore", "Bankim Chandra Chatterjee", "Sarojini Naidu", "Mahatma Gandhi")),
            new QuestionDTO(1, "What is the freezing point of water in Fahrenheit?",
                    List.of("0°F", "32°F", "100°F", "212°F")),
            new QuestionDTO(3, "Which planet has the most moons?",
                    List.of("Jupiter", "Uranus", "Neptune", "Saturn")),
            new QuestionDTO(0, "What is the chemical symbol for gold?",
                    List.of("Au", "Ag", "Fe", "Cu")),
            new QuestionDTO(2, "How many bones are in the adult human body?",
                    List.of("186", "196", "206", "216"))
    );

    public QuizResponse getQuiz(String category, int questionCount) {
        List<QuestionDTO> shuffled = new ArrayList<>(ALL_QUESTIONS);
        Collections.shuffle(shuffled);
        
        int count = Math.min(questionCount, shuffled.size());
        List<QuestionDTO> selected = shuffled.subList(0, count);

        QuizResponse response = new QuizResponse();
        response.setCategory(category);
        response.setDifficulty("mixed");
        response.setQuestions(selected);

        return response;
    }
}

