package com.example.quizz_appp.dto.vs;

public class SocketMessage {
}
