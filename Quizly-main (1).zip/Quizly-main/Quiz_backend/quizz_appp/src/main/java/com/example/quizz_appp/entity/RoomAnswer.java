package com.example.quizz_appp.entity;

import jakarta.persistence.*;

@Entity
@Table(name = "room_answers", uniqueConstraints = @UniqueConstraint(columnNames = { "room_id", "user_id",
        "question_index" }, name = "uk_room_user_question"))
public class RoomAnswer {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "room_id", nullable = false)
    private Long roomId;

    @Column(name = "user_id", nullable = false)
    private String userId;

    @Column(name = "question_index", nullable = false)
    private int questionIndex;

    private int selectedOption;

    private boolean correct;

    // Default Constructor (Required by JPA)
    public RoomAnswer() {
    }

    // Parameterized Constructor (Convenience for Service Layer)
    public RoomAnswer(Long roomId, String userId, int questionIndex, int selectedOption, boolean correct) {
        this.roomId = roomId;
        this.userId = userId;
        this.questionIndex = questionIndex;
        this.selectedOption = selectedOption;
        this.correct = correct;
    }

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getRoomId() {
        return roomId;
    }

    public void setRoomId(Long roomId) {
        this.roomId = roomId;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public int getQuestionIndex() {
        return questionIndex;
    }

    public void setQuestionIndex(int questionIndex) {
        this.questionIndex = questionIndex;
    }

    public int getSelectedOption() {
        return selectedOption;
    }

    public void setSelectedOption(int selectedOption) {
        this.selectedOption = selectedOption;
    }

    public boolean isCorrect() {
        return correct;
    }

    public void setCorrect(boolean correct) {
        this.correct = correct;
    }
}