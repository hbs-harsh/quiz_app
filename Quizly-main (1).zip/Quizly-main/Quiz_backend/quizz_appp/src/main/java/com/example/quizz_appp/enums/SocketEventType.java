package com.example.quizz_appp.enums;


public enum SocketEventType {
    COUNTDOWN,
    START_QUESTION,
    ANSWER_RESULT,
    NEXT_QUESTION,
    GAME_OVER,
    PLAYER_JOINED
}

