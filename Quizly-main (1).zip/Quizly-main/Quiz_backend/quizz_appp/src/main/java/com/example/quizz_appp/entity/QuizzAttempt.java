package com.example.quizz_appp.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "quiz_attempts")
public class QuizzAttempt {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    // 🔹 Many attempts can belong to one user
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id", nullable = false)
    private User user;

    // 🔹 Score earned in this quiz attempt
    @Column(nullable = false)
    private int score;

    // 🔹 When quiz was attempted
    @Column(nullable = false)
    private LocalDateTime attemptedAt;

    // 🔹 Optional: total questions attempted
    private int totalQuestions;

    private String category;

    public String getCategory(){
        return category;
    }

    public void setCategory(String category){
        this.category=category;
    }

    // 🔹 No-arg constructor (required by JPA)
    public QuizzAttempt() {}

    // 🔹 Convenience constructor
    public QuizzAttempt(User user, int score, int totalQuestions) {
        this.user = user;
        this.score = score;
        this.totalQuestions = totalQuestions;
        this.attemptedAt = LocalDateTime.now();
    }

    // 🔹 Getters & Setters

    public Long getId() {
        return id;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public int getScore() {
        return score;
    }

    public void setScore(int score) {
        this.score = score;
    }

    public LocalDateTime getAttemptedAt() {
        return attemptedAt;
    }

    public void setAttemptedAt(LocalDateTime attemptedAt) {
        this.attemptedAt = attemptedAt;
    }

    public int getTotalQuestions() {
        return totalQuestions;
    }

    public void setTotalQuestions(int totalQuestions) {
        this.totalQuestions = totalQuestions;
    }
}
