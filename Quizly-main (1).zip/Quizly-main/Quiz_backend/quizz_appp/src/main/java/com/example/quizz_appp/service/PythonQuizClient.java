package com.example.quizz_appp.service;

import com.example.quizz_appp.dto.Question.QuizRequest;
import com.example.quizz_appp.dto.Question.QuizResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientResponseException;

import java.time.Duration;
import java.util.Map;

@Service
public class PythonQuizClient {

    private static final Logger logger = LoggerFactory.getLogger(PythonQuizClient.class);

    private final WebClient webClient;

    @Value("${quiz.python.enabled:false}")
    private boolean pythonEnabled;

    @Value("${quiz.python.timeout:30}")
    private int timeoutSeconds;

    public PythonQuizClient(WebClient.Builder builder,
                           @Value("${quiz.python.url:http://127.0.0.1:8000}") String pythonUrl) {
        this.webClient = builder
                .baseUrl(pythonUrl)
                .build();
        logger.info("PythonQuizClient initialized with URL: {}", pythonUrl);
    }

    public boolean isPythonEnabled() {
        return pythonEnabled;
    }

    public QuizResponse fetchQuiz(String category, int questionCount, String difficulty) {
        logger.info("Fetching quiz from Python service - category: {}, questions: {}, difficulty: {}",
                category, questionCount, difficulty);

        try {
            QuizResponse response = webClient.get()
                    .uri(uriBuilder -> uriBuilder
                            .path("/quiz/generate")
                            .queryParam("category", category)
                            .queryParam("difficulty", difficulty != null ? difficulty : "medium")
                            .queryParam("limit", questionCount)
                            .build()
                    )
                    .retrieve()
                    .bodyToMono(QuizResponse.class)
                    .timeout(Duration.ofSeconds(timeoutSeconds))
                    .block();

            logger.info("Successfully fetched {} questions from Python service",
                    response != null && response.getQuestions() != null ? response.getQuestions().size() : 0);
            return response;

        } catch (WebClientResponseException e) {
            logger.error("Python service returned error: {} - {}", e.getStatusCode(), e.getMessage());
            throw new RuntimeException("Failed to fetch quiz from AI service: " + e.getMessage(), e);
        } catch (Exception e) {
            logger.error("Failed to connect to Python service: {}", e.getMessage());
            throw new RuntimeException("AI quiz service unavailable: " + e.getMessage(), e);
        }
    }

    public QuizResponse fetchQuiz(QuizRequest request) {
        return fetchQuiz(
                request.getCategory(),
                request.getLimit(),
                request.getDifficulty()
        );
    }

    public QuizResponse fetchQuizFromText(String text, int questionCount, String difficulty) {
        if (text == null || text.isBlank()) {
            throw new IllegalArgumentException("Text content is empty");
        }
        logger.info("Fetching quiz from Python service (from text), questions: {}, difficulty: {}",
                questionCount, difficulty);

        Map<String, Object> body = Map.of(
                "text", text,
                "num_questions", questionCount,
                "difficulty", difficulty != null ? difficulty : "medium"
        );

        try {
            QuizResponse response = webClient.post()
                    .uri("/quiz/generate-from-text")
                    .bodyValue(body)
                    .retrieve()
                    .bodyToMono(QuizResponse.class)
                    .timeout(Duration.ofSeconds(Math.max(timeoutSeconds, 60)))
                    .block();

            logger.info("Successfully fetched {} questions from Python (from text)",
                    response != null && response.getQuestions() != null ? response.getQuestions().size() : 0);
            return response;
        } catch (WebClientResponseException e) {
            logger.error("Python from-text returned error: {} - {}", e.getStatusCode(), e.getMessage());
            throw new RuntimeException("Failed to generate quiz from text: " + e.getMessage(), e);
        } catch (Exception e) {
            logger.error("Failed to connect to Python service (from text): {}", e.getMessage());
            throw new RuntimeException("AI quiz service unavailable: " + e.getMessage(), e);
        }
    }

    public boolean isServiceHealthy() {
        try {
            webClient.get()
                    .uri("/")
                    .retrieve()
                    .bodyToMono(String.class)
                    .timeout(Duration.ofSeconds(5))
                    .block();
            return true;
        } catch (Exception e) {
            logger.warn("Python quiz service health check failed: {}", e.getMessage());
            return false;
        }
    }
}
