package com.example.quizz_appp.Controller;


import com.example.quizz_appp.dto.QuizSubmitRequest;
import com.example.quizz_appp.entity.User;
import com.example.quizz_appp.service.QuizAttemptService;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/quizzsection")
public class QuizzSubmissionController {

    private final QuizAttemptService quizAttemptService;

    public QuizzSubmissionController(QuizAttemptService quizAttemptService) {
        this.quizAttemptService = quizAttemptService;
    }

    @PostMapping("/submit")
    public ResponseEntity<Integer> submitQuiz(
            Authentication authentication,
            @RequestBody QuizSubmitRequest request) {

        // ✅ Extract logged-in user from JWT
        User user = (User) authentication.getPrincipal();

        int score = quizAttemptService.submitQuiz(user, request);

        return ResponseEntity.ok(score);
    }
}

