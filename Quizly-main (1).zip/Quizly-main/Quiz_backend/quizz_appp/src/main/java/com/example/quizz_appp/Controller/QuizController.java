package com.example.quizz_appp.Controller;

import com.example.quizz_appp.dto.Question.QuizRequest;
import com.example.quizz_appp.dto.Question.QuizResponse;
import com.example.quizz_appp.service.MockQuizService;
import com.example.quizz_appp.service.PythonQuizClient;
import org.apache.pdfbox.Loader;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.text.PDFTextStripper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.Map;

@Controller
@RequestMapping("/qizzsection")
public class QuizController {

    private static final Logger logger = LoggerFactory.getLogger(QuizController.class);

    private final MockQuizService mockQuizService;
    private final PythonQuizClient pythonQuizClient;

    public QuizController(PythonQuizClient pythonQuizClient, MockQuizService mockQuizService) {
        this.pythonQuizClient = pythonQuizClient;
        this.mockQuizService = mockQuizService;
    }

    /**
     * Start a quiz - works for both static quizzes and multiplayer.
     * Uses AI-generated questions when Python service is enabled and available.
     * Falls back to mock questions otherwise.
     */
    @GetMapping("/start")
    public ResponseEntity<?> startQuiz(
            @RequestParam String category,
            @RequestParam(defaultValue = "10") int questionCount,
            @RequestParam(defaultValue = "medium") String difficulty,
            @RequestParam(defaultValue = "false") boolean useAI
    ) {
        logger.info("Starting quiz - category: {}, questions: {}, difficulty: {}, useAI: {}",
                category, questionCount, difficulty, useAI);

        QuizResponse response;

        if (useAI && pythonQuizClient.isPythonEnabled()) {
            try {
                response = pythonQuizClient.fetchQuiz(category, questionCount, difficulty);
                logger.info("Quiz generated using AI service");
            } catch (Exception e) {
                logger.warn("AI service failed, falling back to mock questions: {}", e.getMessage());
                response = mockQuizService.getQuiz(category, questionCount);
            }
        } else {
            response = mockQuizService.getQuiz(category, questionCount);
            logger.info("Quiz generated using mock service");
        }

        return ResponseEntity.ok(response);
    }

    /**
     * Generate a custom quiz from an uploaded PDF.
     * Extracts text from the PDF and uses the Python AI service to generate questions.
     */
    @PostMapping("/from-pdf")
    public ResponseEntity<?> quizFromPdf(
            @RequestParam("file") MultipartFile file,
            @RequestParam(defaultValue = "10") int questionCount,
            @RequestParam(defaultValue = "medium") String difficulty
    ) {
        if (file.isEmpty()) {
            return ResponseEntity.badRequest().body(Map.of("error", "No file uploaded"));
        }
        String contentType = file.getContentType();
        if (contentType == null || !contentType.toLowerCase().contains("pdf")) {
            return ResponseEntity.badRequest().body(Map.of("error", "File must be a PDF"));
        }
        logger.info("Processing PDF for quiz, questionCount={}, difficulty={}", questionCount, difficulty);

        if (!pythonQuizClient.isPythonEnabled()) {
            return ResponseEntity.status(503).body(Map.of(
                    "error", "AI quiz service is not enabled. Enable quiz.python.enabled and run the Python service."
            ));
        }

        try {
            String text;
            try (PDDocument document = Loader.loadPDF(file.getBytes())) {
                PDFTextStripper stripper = new PDFTextStripper();
                text = stripper.getText(document);
            }
            if (text == null || text.isBlank()) {
                return ResponseEntity.badRequest().body(Map.of("error", "PDF contains no extractable text"));
            }
            QuizResponse response = pythonQuizClient.fetchQuizFromText(text, questionCount, difficulty);
            if (response.getQuestions() == null || response.getQuestions().isEmpty()) {
                return ResponseEntity.status(500).body(Map.of("error", "No questions could be generated from the PDF"));
            }
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            logger.warn("PDF quiz generation failed: {}", e.getMessage());
            return ResponseEntity.status(500).body(Map.of("error", e.getMessage()));
        }
    }

    /**
     * Health check for AI quiz service
     */
    @GetMapping("/ai-status")
    public ResponseEntity<?> getAIStatus() {
        boolean enabled = pythonQuizClient.isPythonEnabled();
        boolean healthy = enabled && pythonQuizClient.isServiceHealthy();

        return ResponseEntity.ok(Map.of(
                "aiEnabled", enabled,
                "serviceHealthy", healthy,
                "status", healthy ? "AI quiz generation available" : "Using mock questions"
        ));
    }
}
