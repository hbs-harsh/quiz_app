package com.example.quizz_appp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class QuizzApppApplication {

	public static void main(String[] args) {
		SpringApplication.run(QuizzApppApplication.class, args);
	}

}
