package com.example.quizz_appp.enums;


public enum RoomStatus {
    WAITING,     // only host exists
    READY,       // both players joined
    COUNTDOWN,
    ACTIVE,
    COMPLETED,
    EXPIRED
}

