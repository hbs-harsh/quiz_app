package com.example.quizz_appp.service;

import com.example.quizz_appp.dto.Question.QuestionDTO;
import com.example.quizz_appp.dto.Question.QuizResponse;
import com.example.quizz_appp.entity.Room;
import com.example.quizz_appp.entity.RoomAnswer;
import com.example.quizz_appp.entity.RoomPlayer;
import com.example.quizz_appp.entity.RoomQuestion;
import com.example.quizz_appp.enums.RoomStatus;
import com.example.quizz_appp.repository.RoomAnswerRepository;
import com.example.quizz_appp.repository.RoomPlayerRepository;
import com.example.quizz_appp.repository.RoomQuestionRepository;
import com.example.quizz_appp.repository.RoomRepository;
import com.example.quizz_appp.repository.UserRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Transactional;

import com.example.quizz_appp.entity.User;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@Service
public class QuizGameService {

        private static final Logger log = LoggerFactory.getLogger(QuizGameService.class);

        private final RoomRepository roomRepository;
        private final RoomQuestionRepository questionRepository;
        private final RoomAnswerRepository answerRepository;
        private final RoomPlayerRepository playerRepository;
        private final PythonQuizClient pythonQuizClient;
        private final MockQuizService mockQuizService;
        private final UserRepository userRepository;

        public QuizGameService(
                        RoomRepository roomRepository,
                        RoomQuestionRepository questionRepository,
                        RoomAnswerRepository answerRepository,
                        RoomPlayerRepository playerRepository,
                        PythonQuizClient pythonQuizClient,
                        MockQuizService mockQuizService,
                        UserRepository userRepository) {
                this.roomRepository = roomRepository;
                this.questionRepository = questionRepository;
                this.answerRepository = answerRepository;
                this.playerRepository = playerRepository;
                this.pythonQuizClient = pythonQuizClient;
                this.mockQuizService = mockQuizService;
                this.userRepository = userRepository;
        }

        // ======================================
        // GENERATE QUIZ WHEN ROOM BECOMES READY
        // ======================================
        public RoomQuestion generateQuizForRoom(Long roomId) {

                Room room = roomRepository.findById(roomId)
                                .orElseThrow(() -> new RuntimeException("Room not found"));

                // Validate that room is ready (both players joined) and not already started
                if (room.getStatus() == RoomStatus.ACTIVE || room.getStatus() == RoomStatus.COMPLETED) {
                        log.warn("⚠️ Cannot start game - RoomId: {}, Status: {}, Game already started/completed",
                                        roomId, room.getStatus());
                        throw new RuntimeException("Cannot start game. Game has already started or completed. Current status: " + room.getStatus());
                }
                
                if (room.getStatus() != RoomStatus.READY) {
                        log.warn("⚠️ Cannot start game - RoomId: {}, Status: {}, Expected: READY",
                                        roomId, room.getStatus());
                        throw new RuntimeException("Cannot start game. Room status must be READY (both players must join). Current status: " + room.getStatus());
                }

                // Validate that exactly 2 players are in the room
                List<RoomPlayer> players = playerRepository.findByRoom_Id(roomId);
                if (players.size() < 2) {
                        log.warn("⚠️ Cannot start game - RoomId: {}, Players: {}/2",
                                        roomId, players.size());
                        throw new RuntimeException("Cannot start game. Both players must join. Current players: " + players.size() + "/2");
                }

                log.info("✅ Starting game - RoomId: {}, Players: {}", roomId, players.size());

                // Get questions - try AI first, fallback to mock
                List<RoomQuestion> questions = generateQuestionsForRoom(room, roomId);

                questionRepository.saveAll(questions);

                room.setStatus(RoomStatus.ACTIVE);
                room.setCurrentQuestionIndex(0);
                roomRepository.save(room);

                return questions.get(0);
        }

        private List<RoomQuestion> generateQuestionsForRoom(Room room, Long roomId) {
                String topic = room.getTopic() != null ? room.getTopic() : "General Knowledge";
                String difficulty = room.getDifficulty() != null ? room.getDifficulty() : "medium";
                int questionCount = 5; // Default for multiplayer

                List<RoomQuestion> questions = new ArrayList<>();

                // Try to use AI-generated questions
                if (pythonQuizClient.isPythonEnabled()) {
                        try {
                                log.info("🤖 Generating AI questions - Topic: {}, Difficulty: {}, Count: {}",
                                                topic, difficulty, questionCount);
                                
                                QuizResponse aiResponse = pythonQuizClient.fetchQuiz(topic, questionCount, difficulty);
                                
                                if (aiResponse != null && aiResponse.getQuestions() != null && !aiResponse.getQuestions().isEmpty()) {
                                        List<QuestionDTO> aiQuestions = aiResponse.getQuestions();
                                        
                                        for (int i = 0; i < aiQuestions.size(); i++) {
                                                QuestionDTO q = aiQuestions.get(i);
                                                questions.add(createQuestion(
                                                        roomId, 
                                                        i, 
                                                        q.getQuestion(), 
                                                        q.getOptions(), 
                                                        q.getCorrectAnswer()
                                                ));
                                        }
                                        
                                        log.info("✅ Generated {} AI questions for room {}", questions.size(), roomId);
                                        return questions;
                                }
                        } catch (Exception e) {
                                log.warn("⚠️ AI quiz generation failed, using mock questions: {}", e.getMessage());
                        }
                }

                // Fallback to mock questions
                log.info("📝 Using mock questions for room {}", roomId);
                QuizResponse mockResponse = mockQuizService.getQuiz(topic, questionCount);
                
                if (mockResponse != null && mockResponse.getQuestions() != null) {
                        for (int i = 0; i < mockResponse.getQuestions().size(); i++) {
                                QuestionDTO q = mockResponse.getQuestions().get(i);
                                questions.add(createQuestion(
                                        roomId, 
                                        i, 
                                        q.getQuestion(), 
                                        q.getOptions(), 
                                        q.getCorrectAnswer()
                                ));
                        }
                }

                // Ultimate fallback - hardcoded questions
                if (questions.isEmpty()) {
                        log.warn("⚠️ All quiz generation failed, using hardcoded fallback");
                        questions = List.of(
                                createQuestion(roomId, 0,
                                        "Who was first PM of India?",
                                        List.of("Nehru", "Gandhi", "Patel", "Bose"),
                                        0),
                                createQuestion(roomId, 1,
                                        "India got independence in?",
                                        List.of("1942", "1945", "1947", "1950"),
                                        2),
                                createQuestion(roomId, 2,
                                        "Founder of Maurya Empire?",
                                        List.of("Ashoka", "Chandragupta", "Bindusara", "Bimbisara"),
                                        1));
                }

                return questions;
        }

        private RoomQuestion createQuestion(
                        Long roomId,
                        int index,
                        String question,
                        List<String> options,
                        int correct) {
                RoomQuestion q = new RoomQuestion();
                q.setRoomId(roomId);
                q.setQuestionIndex(index);
                q.setQuestion(question);
                q.setOptions(options);
                q.setCorrectAnswer(correct);
                return q;
        }

        // ======================================
        // VALIDATE ANSWER IMMEDIATELY
        // ======================================
        @Transactional(isolation = Isolation.READ_COMMITTED)
        public AnswerSubmissionResult submitAnswer(
                        Long roomId,
                        String userId,
                        int questionIndex,
                        int selectedOption) {

                // Use pessimistic write lock to prevent concurrent modifications
                Room room = roomRepository.findByIdWithLock(roomId)
                                .orElseThrow(() -> new RuntimeException("Room not found"));

                RoomQuestion question = questionRepository
                                .findByRoomIdOrderByQuestionIndex(roomId)
                                .stream()
                                .filter(q -> q.getQuestionIndex() == questionIndex)
                                .findFirst()
                                .orElseThrow(() -> new RuntimeException("Question not found"));

                // Check if this user has already answered this question
                boolean alreadyAnswered = answerRepository
                                .findByRoomIdAndQuestionIndex(roomId, questionIndex)
                                .stream()
                                .anyMatch(a -> a.getUserId().equals(userId));

                if (alreadyAnswered) {
                        log.warn("⚠️ Duplicate answer rejected - RoomId: {}, UserId: {}, Question: {}",
                                        roomId, userId, questionIndex);
                        throw new RuntimeException("You have already answered question " + questionIndex);
                }

                // selectedOption -1 = timeout/no answer (counts as wrong, allows game to advance when both timed out)
                boolean isCorrect = selectedOption >= 0 && question.getCorrectAnswer() == selectedOption;

                log.info("📝 Answer submitted - RoomId: {}, UserId: {}, Question: {}, Option: {} ({}), Correct: {}",
                                roomId, userId, questionIndex, selectedOption, selectedOption < 0 ? "timeout" : "choice", isCorrect);

                RoomAnswer answer = new RoomAnswer();
                answer.setRoomId(roomId);
                answer.setUserId(userId);
                answer.setQuestionIndex(questionIndex);
                answer.setSelectedOption(selectedOption);
                answer.setCorrect(isCorrect);

                answerRepository.save(answer);

                if (isCorrect) {
                        updateScore(roomId, userId);
                }

                // Validate that player is answering the CURRENT question
                if (room.getCurrentQuestionIndex() != questionIndex) {
                        log.warn("⚠️ Answer rejected - RoomId: {}, UserId: {}, Room is on Q{}, but answer submitted for Q{}",
                                        roomId, userId, room.getCurrentQuestionIndex(), questionIndex);
                        throw new RuntimeException("Cannot answer question " + questionIndex + 
                                        ". Room is currently on question " + room.getCurrentQuestionIndex());
                }

                // Check if both players have answered THIS question
                List<RoomAnswer> answersForCurrentQuestion = answerRepository
                                .findByRoomIdAndQuestionIndex(roomId, questionIndex);

                List<RoomPlayer> players = playerRepository.findByRoom_Id(roomId);

                // Verify that we have answers from DISTINCT players
                long distinctPlayerCount = answersForCurrentQuestion.stream()
                                .map(RoomAnswer::getUserId)
                                .distinct()
                                .count();

                log.info("🔍 Answer check - RoomId: {}, Question: {}, Distinct players answered: {}/{} total players, Total answer records: {}",
                                roomId, questionIndex, distinctPlayerCount, players.size(), answersForCurrentQuestion.size());

                // Both players must have answered (check distinct count, not total records)
                boolean bothPlayersAnswered = distinctPlayerCount >= players.size() && players.size() >= 2;

                // Prepare result
                AnswerSubmissionResult result = new AnswerSubmissionResult();
                result.setCorrect(isCorrect);
                result.setBothPlayersAnswered(bothPlayersAnswered);

                if (bothPlayersAnswered) {
                        log.info("✅ BOTH PLAYERS ANSWERED - RoomId: {}, Question: {} - Checking if should advance",
                                        roomId, questionIndex);

                        // Double-check room is still on this question (prevents race conditions)
                        // Re-fetch room to ensure we have latest state
                        Room currentRoom = roomRepository.findByIdWithLock(roomId)
                                        .orElseThrow(() -> new RuntimeException("Room not found"));

                        if (currentRoom.getCurrentQuestionIndex() != questionIndex) {
                                log.warn("⚠️ Room already advanced - RoomId: {}, Expected Q{}, but room is on Q{}",
                                                roomId, questionIndex, currentRoom.getCurrentQuestionIndex());
                                // Don't advance, room already moved forward
                                return result;
                        }

                        // Get all questions
                        List<RoomQuestion> allQuestions = questionRepository.findByRoomIdOrderByQuestionIndex(roomId);
                        int nextQuestionIndex = questionIndex + 1;

                        log.info("🔍 Checking if game should complete - Current Q: {}, Next Q: {}, Total Questions: {}",
                                        questionIndex, nextQuestionIndex, allQuestions.size());

                        if (nextQuestionIndex < allQuestions.size()) {
                                // Advance to next question
                                currentRoom.setCurrentQuestionIndex(nextQuestionIndex);
                                roomRepository.save(currentRoom);

                                RoomQuestion nextQuestion = allQuestions.get(nextQuestionIndex);
                                result.setShouldAdvance(true);
                                result.setNextQuestion(nextQuestion);

                                log.info("⏭️ ADVANCING to Question {} - Title: '{}'",
                                                nextQuestionIndex, nextQuestion.getQuestion());
                        } else {
                                // Game completed - all questions answered
                                log.info("🏁 LAST QUESTION ANSWERED - Calculating final scores...");
                                
                                Map<String, Integer> finalScores = calculateFinalScores(roomId);
                                result.setGameCompleted(true);
                                result.setFinalScores(finalScores);
                                
                                // Update room status to COMPLETED
                                currentRoom.setStatus(RoomStatus.COMPLETED);
                                roomRepository.save(currentRoom);

                                // Update user stats (wins/losses)
                                updateUserStats(finalScores);

                                log.info("🏁 GAME COMPLETED - RoomId: {}, Final Scores: {}, Room status set to COMPLETED",
                                                roomId, finalScores);
                        }
                } else {
                        log.info("⏳ Waiting for other player - RoomId: {}, Question: {}, Distinct answers: {}/{}",
                                        roomId, questionIndex, distinctPlayerCount, players.size());
                }

                return result;
        }

        private void updateScore(Long roomId, String userId) {
                List<RoomPlayer> players = playerRepository.findByRoom_Id(roomId);

                players.stream()
                                .filter(p -> p.getUserId().equals(userId))
                                .findFirst()
                                .ifPresent(p -> {
                                        p.setScore(p.getScore() + 1);
                                        playerRepository.save(p);
                                });
        }

        private Map<String, Integer> calculateFinalScores(Long roomId) {
                List<RoomPlayer> players = playerRepository.findByRoom_Id(roomId);
                Map<String, Integer> scores = new HashMap<>();

                log.info("📊 Calculating final scores for RoomId: {}, Players: {}", roomId, players.size());
                
                for (RoomPlayer player : players) {
                        log.info("📊 Player {} - Score: {}", player.getUserId(), player.getScore());
                        scores.put(player.getUserId(), player.getScore());
                }

                log.info("📊 Final scores map: {}", scores);
                return scores;
        }

        /**
         * Resolves room player userIds to display names for multiplayer UI.
         * Keys match finalScores keys (userId may be firebaseUid or firebaseUid_2).
         */
        public Map<String, String> getPlayerDisplayNamesForRoom(Long roomId) {
                List<RoomPlayer> players = playerRepository.findByRoom_Id(roomId);
                Map<String, String> names = new HashMap<>();
                for (RoomPlayer player : players) {
                        String userId = player.getUserId();
                        String firebaseUid = userId.endsWith("_2")
                                ? userId.substring(0, userId.length() - 2)
                                : userId;
                        Optional<User> userOpt = userRepository.findByFirebaseUid(firebaseUid);
                        String displayName = userOpt.map(u -> {
                                String dn = u.getDisplayName();
                                if (dn != null && !dn.isEmpty()) return dn;
                                String email = u.getEmail();
                                return (email != null && email.contains("@"))
                                        ? email.substring(0, email.indexOf('@'))
                                        : "Player";
                        }).orElse("Player");
                        names.put(userId, displayName);
                }
                return names;
        }

        private void updateUserStats(Map<String, Integer> finalScores) {
                if (finalScores.size() < 2) {
                        log.warn("⚠️ Cannot update user stats - less than 2 players");
                        return;
                }

                // Find winner (highest score)
                String winnerId = null;
                int highestScore = -1;
                boolean isTie = false;

                for (Map.Entry<String, Integer> entry : finalScores.entrySet()) {
                        if (entry.getValue() > highestScore) {
                                highestScore = entry.getValue();
                                winnerId = entry.getKey();
                                isTie = false;
                        } else if (entry.getValue() == highestScore) {
                                isTie = true;
                        }
                }

                // Update stats for each player
                for (Map.Entry<String, Integer> entry : finalScores.entrySet()) {
                        String oduserId = entry.getKey();
                        try {
                                if (isTie) {
                                        // In case of tie, both get a "game played" but no win/loss
                                        log.info("📊 Game was a tie - oduserId: {}", oduserId);
                                } else if (oduserId.equals(winnerId)) {
                                        userRepository.incrementWins(oduserId);
                                        log.info("🏆 Incremented wins for oduserId: {}", oduserId);
                                } else {
                                        userRepository.incrementLosses(oduserId);
                                        log.info("📉 Incremented losses for oduserId: {}", oduserId);
                                }
                        } catch (Exception e) {
                                log.error("❌ Failed to update stats for oduserId: {} - {}", oduserId, e.getMessage());
                        }
                }
        }

        // ======================================
        // PLAYER LEFT / QUIT GAME
        // ======================================
        @Transactional
        public com.example.quizz_appp.dto.vs.GameCompletedPayload playerLeft(Long roomId, String userIdWhoLeft) {
                Room room = roomRepository.findById(roomId)
                                .orElseThrow(() -> new RuntimeException("Room not found"));

                if (room.getStatus() != RoomStatus.ACTIVE && room.getStatus() != RoomStatus.READY) {
                        log.warn("⚠️ Player leave ignored - RoomId: {}, Status: {}", roomId, room.getStatus());
                        throw new RuntimeException("Room is not in an active game. Status: " + room.getStatus());
                }

                List<RoomPlayer> players = playerRepository.findByRoom_Id(roomId);
                String winnerId = players.stream()
                                .map(RoomPlayer::getUserId)
                                .filter(id -> !id.equals(userIdWhoLeft))
                                .findFirst()
                                .orElse(null);

                room.setStatus(RoomStatus.COMPLETED);
                roomRepository.save(room);

                Map<String, Integer> scores = calculateFinalScores(roomId);
                
                // Update user stats - winner wins, leaver loses
                if (winnerId != null) {
                        try {
                                userRepository.incrementWins(winnerId);
                                log.info("🏆 Player left - Incremented wins for winner: {}", winnerId);
                        } catch (Exception e) {
                                log.error("❌ Failed to update winner stats: {}", e.getMessage());
                        }
                }
                try {
                        userRepository.incrementLosses(userIdWhoLeft);
                        log.info("📉 Player left - Incremented losses for leaver: {}", userIdWhoLeft);
                } catch (Exception e) {
                        log.error("❌ Failed to update leaver stats: {}", e.getMessage());
                }
                
                log.info("🚪 Player left - RoomId: {}, UserLeft: {}, Winner: {}", roomId, userIdWhoLeft, winnerId);

                return new com.example.quizz_appp.dto.vs.GameCompletedPayload(scores, winnerId, false, true);
        }

        // Inner class to hold the result
        public static class AnswerSubmissionResult {
                private boolean correct;
                private boolean bothPlayersAnswered;
                private boolean shouldAdvance;
                private boolean gameCompleted;
                private RoomQuestion nextQuestion;
                private Map<String, Integer> finalScores;

                public boolean isCorrect() {
                        return correct;
                }

                public void setCorrect(boolean correct) {
                        this.correct = correct;
                }

                public boolean isBothPlayersAnswered() {
                        return bothPlayersAnswered;
                }

                public void setBothPlayersAnswered(boolean bothPlayersAnswered) {
                        this.bothPlayersAnswered = bothPlayersAnswered;
                }

                public boolean isShouldAdvance() {
                        return shouldAdvance;
                }

                public void setShouldAdvance(boolean shouldAdvance) {
                        this.shouldAdvance = shouldAdvance;
                }

                public boolean isGameCompleted() {
                        return gameCompleted;
                }

                public void setGameCompleted(boolean gameCompleted) {
                        this.gameCompleted = gameCompleted;
                }

                public RoomQuestion getNextQuestion() {
                        return nextQuestion;
                }

                public void setNextQuestion(RoomQuestion nextQuestion) {
                        this.nextQuestion = nextQuestion;
                }

                public Map<String, Integer> getFinalScores() {
                        return finalScores;
                }

                public void setFinalScores(Map<String, Integer> finalScores) {
                        this.finalScores = finalScores;
                }
        }
}
