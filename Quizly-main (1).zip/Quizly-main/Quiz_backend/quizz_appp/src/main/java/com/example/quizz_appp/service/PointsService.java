package com.example.quizz_appp.service;

import com.example.quizz_appp.repository.UserRepository;
import jakarta.transaction.Transactional;
import org.springframework.stereotype.Service;

@Service
public class PointsService {

    private final UserRepository userRepository;
     PointsService( UserRepository userRepository1){

         this.userRepository = userRepository1;
     }

     @Transactional
    public void addPoints(Long userId, int score){
         long pointsToAdd=score*10;
         userRepository.addPoints(userId,pointsToAdd);
     }
}
