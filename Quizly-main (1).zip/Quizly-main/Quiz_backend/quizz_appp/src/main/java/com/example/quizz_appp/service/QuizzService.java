package com.example.quizz_appp.service;


import com.example.quizz_appp.dto.QuestionAnswerDTO;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class QuizzService {

    public int evaluateQuiz(List<QuestionAnswerDTO> questions) {

        int score = 0;

        for (QuestionAnswerDTO q : questions) {
            if (q.getSelectedOption() == q.getCorrectOption()) {
                score++;
            }
        }
        return score;
    }
}


