package com.example.quizz_appp.dto.vs;

public class AnswerResultPayload {

    private String userId;
    private int questionIndex;
    private int selectedOption;
    private boolean correct;

    public AnswerResultPayload(
            String userId,
            int questionIndex,
            int selectedOption,
            boolean correct) {
        this.userId = userId;
        this.questionIndex = questionIndex;
        this.selectedOption = selectedOption;
        this.correct = correct;
    }

    // Getters
    public String getUserId() {
        return userId;
    }

    public int getQuestionIndex() {
        return questionIndex;
    }

    public int getSelectedOption() {
        return selectedOption;
    }

    public boolean isCorrect() {
        return correct;
    }
}
