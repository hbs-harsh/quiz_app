package com.example.quizz_app.model

data class NextQuestionPayload(
    val questionIndex: Int,
    val question: String,
    val options: List<String>,
    /** Per-question timer in seconds; same on both devices (synced). */
    val timerSeconds: Int = 30
)
