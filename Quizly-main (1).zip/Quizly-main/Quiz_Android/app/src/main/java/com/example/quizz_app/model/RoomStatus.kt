package com.example.quizz_app.model

enum class RoomStatus {
    WAITING,
    READY,
    ACTIVE,
    COMPLETED
}
