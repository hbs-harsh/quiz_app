package com.example.quizz_app.ui.quiz

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.animation.PropertyValuesHolder
import android.os.Bundle
import android.os.CountDownTimer
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.NavHostFragment
import com.example.quizz_app.R
import com.example.quizz_app.dto.Question
import com.example.quizz_app.dto.QuizResponse
import com.example.quizz_app.utils.QuizFeedbackHelper
import com.google.android.material.card.MaterialCardView
import com.google.android.material.progressindicator.CircularProgressIndicator

class QuizFragment : Fragment(R.layout.fragment_quiz) {

    private lateinit var quizResponse: QuizResponse
    private lateinit var questions: List<Question>

    private var currentIndex = 0
    private val selectedAnswers = mutableMapOf<Int, Int>()
    private var timerSeconds = 30
    private var countDownTimer: CountDownTimer? = null
    private var hasAnsweredCurrent = false

    private lateinit var tvProgress: TextView
    private lateinit var tvQuestion: TextView
    private lateinit var questionCard: View
    private lateinit var optionsContainer: LinearLayout
    private lateinit var timerCircular: CircularProgressIndicator
    private lateinit var tvTimerCount: TextView

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        quizResponse = requireArguments().getParcelable("quizData")!!
        questions = quizResponse.questions
        timerSeconds = arguments?.getInt("timerSeconds", 30) ?: 30

        Log.d("QuizFragment", "Received quiz with ${questions.size} questions, timer: ${timerSeconds}s")

        tvProgress = view.findViewById(R.id.tvProgress)
        tvQuestion = view.findViewById(R.id.tvQuestion)
        questionCard = view.findViewById(R.id.questionCard)
        optionsContainer = view.findViewById(R.id.optionsContainer)
        timerCircular = view.findViewById(R.id.timerCircular)
        tvTimerCount = view.findViewById(R.id.tvTimerCount)

        QuizFeedbackHelper.init(requireContext())
        showQuestion()
    }

    override fun onDestroyView() {
        countDownTimer?.cancel()
        countDownTimer = null
        QuizFeedbackHelper.release()
        super.onDestroyView()
    }

    private fun showQuestion() {
        hasAnsweredCurrent = false
        val question = questions[currentIndex]

        tvProgress.text = "Question ${currentIndex + 1} / ${questions.size}"
        tvQuestion.text = question.question

        optionsContainer.removeAllViews()

        val optionLetters = listOf("A", "B", "C", "D")
        question.options.forEachIndexed { index, option ->
            val optionView = LayoutInflater.from(requireContext())
                .inflate(R.layout.item_quiz_option, optionsContainer, false) as MaterialCardView
            
            optionView.findViewById<TextView>(R.id.tvOptionLetter)?.text = optionLetters.getOrElse(index) { "" }
            optionView.findViewById<TextView>(R.id.tvOption)?.text = option
            
            optionView.setOnClickListener {
                if (!hasAnsweredCurrent) {
                    QuizFeedbackHelper.tapHaptic(optionView)
                    hasAnsweredCurrent = true
                    countDownTimer?.cancel()
                    selectedAnswers[currentIndex] = index
                    highlightSelectedOption(optionView, index == question.correct)
                    optionView.postDelayed({ moveToNextQuestion() }, 600)
                }
            }
            
            optionsContainer.addView(optionView)
        }

        startTimer()
    }

    private fun highlightSelectedOption(card: MaterialCardView, isCorrect: Boolean) {
        if (isCorrect) QuizFeedbackHelper.playCorrect(card) else QuizFeedbackHelper.playWrong(card)
        val color = if (isCorrect) {
            requireContext().getColor(R.color.correctOption)
        } else {
            requireContext().getColor(R.color.wrongOption)
        }
        card.strokeColor = color
        card.strokeWidth = 4
        if (isCorrect) animateCorrectPulse(card) else animateWrongShake(card)
    }

    private fun animateCorrectPulse(view: View) {
        val scaleX = PropertyValuesHolder.ofFloat(View.SCALE_X, 1f, 1.08f, 1f)
        val scaleY = PropertyValuesHolder.ofFloat(View.SCALE_Y, 1f, 1.08f, 1f)
        ObjectAnimator.ofPropertyValuesHolder(view, scaleX, scaleY).apply {
            duration = 250
            start()
        }
    }

    private fun animateWrongShake(view: View) {
        ObjectAnimator.ofFloat(view, View.TRANSLATION_X, 0f, -14f, 14f, -10f, 10f, 0f).apply {
            duration = 380
            start()
        }
    }

    private fun startTimer() {
        countDownTimer?.cancel()
        
        val totalMs = timerSeconds * 1000L
        tvTimerCount.text = timerSeconds.toString()
        timerCircular.progress = 100

        countDownTimer = object : CountDownTimer(totalMs, 100) {
            override fun onTick(millisUntilFinished: Long) {
                val secondsLeft = (millisUntilFinished / 1000).toInt() + 1
                tvTimerCount.text = secondsLeft.toString()
                val progress = ((millisUntilFinished.toFloat() / totalMs) * 100).toInt()
                timerCircular.progress = progress
            }

            override fun onFinish() {
                tvTimerCount.text = "0"
                timerCircular.progress = 0
                onTimerExpired()
            }
        }.start()
    }

    private fun onTimerExpired() {
        if (!hasAnsweredCurrent) {
            hasAnsweredCurrent = true
            disableOptions()
            view?.postDelayed({ moveToNextQuestion() }, 800)
        }
    }

    private fun disableOptions() {
        for (i in 0 until optionsContainer.childCount) {
            val child = optionsContainer.getChildAt(i)
            child.isEnabled = false
            child.alpha = 0.5f
        }
    }

    private fun moveToNextQuestion() {
        if (currentIndex < questions.size - 1) {
            runQuestionTransition {
                currentIndex++
                showQuestion()
            }
        } else {
            openResultScreen()
        }
    }

    private fun runQuestionTransition(onTransitionEnd: () -> Unit) {
        val fadeOutCard = ObjectAnimator.ofFloat(questionCard, View.ALPHA, 1f, 0f).apply { duration = 180 }
        val fadeOutOptions = ObjectAnimator.ofFloat(optionsContainer, View.ALPHA, 1f, 0f).apply { duration = 180 }
        AnimatorSet().apply {
            playTogether(fadeOutCard, fadeOutOptions)
            addListener(object : AnimatorListenerAdapter() {
                override fun onAnimationEnd(animation: Animator) {
                    questionCard.alpha = 0f
                    optionsContainer.alpha = 0f
                    onTransitionEnd()
                    questionCard.animate().alpha(1f).setDuration(220).start()
                    optionsContainer.animate().alpha(1f).setDuration(220).start()
                }
            })
            start()
        }
    }

    private fun openResultScreen() {
        val score = calculateScore()
        val points = score * 10

        val bundle = Bundle().apply {
            putInt("score", score)
            putInt("total", questions.size)
            putInt("points", points)
        }

        NavHostFragment.findNavController(this)
                .navigate(R.id.action_quizFragment_to_resultFragment, bundle)
    }

    private fun calculateScore(): Int {
        var score = 0
        selectedAnswers.forEach { (index, selected) ->
            if (questions[index].correct == selected) score++
        }
        return score
    }

}
