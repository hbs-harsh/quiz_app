package com.example.quizz_app.ui.settings

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatDelegate
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import com.example.quizz_app.MainActivity
import com.example.quizz_app.remote.RetrofitClient
import com.example.quizz_app.remote.UpdateProfileRequest
import com.example.quizz_app.R
import com.example.quizz_app.utils.SessionManager
import com.google.android.material.button.MaterialButton
import com.google.android.material.card.MaterialCardView
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.UserProfileChangeRequest
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class SettingsFragment : Fragment() {

    private lateinit var session: SessionManager

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_settings, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        session = SessionManager(requireContext())

        setupProfile(view)
        setupAppearance(view)
        setupAppInfo(view)
        setupLegal(view)
        setupAccountActions(view)
    }

    private fun setupProfile(view: View) {
        val user = FirebaseAuth.getInstance().currentUser
        val tvDisplayName = view.findViewById<TextView>(R.id.tvDisplayName)
        val tvEmail = view.findViewById<TextView>(R.id.tvEmail)
        val tvAvatarLetter = view.findViewById<TextView>(R.id.tvAvatarLetter)
        val cardProfile = view.findViewById<MaterialCardView>(R.id.cardProfile)

        fun updateProfileUI() {
            val currentUser = FirebaseAuth.getInstance().currentUser
            if (currentUser != null) {
                val name = currentUser.displayName?.takeIf { it.isNotBlank() } ?: "Quizzer"
                val email = currentUser.email ?: ""
                tvDisplayName.text = name
                tvEmail.text = email
                tvAvatarLetter.text = name.firstOrNull()?.uppercaseChar()?.toString()
                    ?: email.firstOrNull()?.uppercaseChar()?.toString() ?: "?"
            } else {
                tvDisplayName.text = "Guest"
                tvEmail.text = ""
                tvAvatarLetter.text = "?"
            }
        }

        updateProfileUI()

        cardProfile.setOnClickListener {
            showEditNameDialog { updateProfileUI() }
        }
    }

    private fun showEditNameDialog(onSuccess: () -> Unit) {
        val user = FirebaseAuth.getInstance().currentUser ?: return

        val editText = EditText(requireContext()).apply {
            hint = "Enter display name"
            setText(user.displayName ?: "")
            setPadding(48, 32, 48, 32)
        }

        MaterialAlertDialogBuilder(requireContext())
            .setTitle("Edit Display Name")
            .setView(editText)
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Save") { _, _ ->
                val newName = editText.text.toString().trim()
                if (newName.isNotEmpty()) {
                    val profileUpdates = UserProfileChangeRequest.Builder()
                        .setDisplayName(newName)
                        .build()

                    user.updateProfile(profileUpdates)
                        .addOnSuccessListener {
                            lifecycleScope.launch {
                                try {
                                    withContext(Dispatchers.IO) {
                                        RetrofitClient.create(requireContext())
                                            .updateProfile(UpdateProfileRequest(newName))
                                    }
                                    Toast.makeText(context, "Name updated!", Toast.LENGTH_SHORT).show()
                                    onSuccess()
                                } catch (e: Exception) {
                                    Toast.makeText(
                                        context,
                                        "Name updated on device. Sync to server may have failed.",
                                        Toast.LENGTH_SHORT
                                    ).show()
                                    onSuccess()
                                }
                            }
                        }
                        .addOnFailureListener { e ->
                            Toast.makeText(context, "Failed: ${e.message}", Toast.LENGTH_SHORT).show()
                        }
                }
            }
            .show()
    }

    private fun setupAppearance(view: View) {
        val switchDark = view.findViewById<androidx.appcompat.widget.SwitchCompat>(R.id.switchDarkMode)
        switchDark.isChecked = session.isDarkMode()
        switchDark.setOnCheckedChangeListener { _, isChecked ->
            session.setDarkMode(isChecked)
            AppCompatDelegate.setDefaultNightMode(
                if (isChecked) AppCompatDelegate.MODE_NIGHT_YES
                else AppCompatDelegate.MODE_NIGHT_NO
            )
        }
    }

    private fun setupAppInfo(view: View) {
        val tvAppVersion = view.findViewById<TextView>(R.id.tvAppVersion)
        try {
            val versionName = requireContext().packageManager
                .getPackageInfo(requireContext().packageName, 0).versionName
            tvAppVersion.text = versionName
        } catch (e: Exception) {
            tvAppVersion.text = "1.0.0"
        }

        view.findViewById<LinearLayout>(R.id.btnRateApp).setOnClickListener {
            openPlayStore()
        }

        view.findViewById<LinearLayout>(R.id.btnShareApp).setOnClickListener {
            shareApp()
        }
    }

    private fun openPlayStore() {
        val packageName = requireContext().packageName
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=$packageName")))
        } catch (e: Exception) {
            startActivity(Intent(Intent.ACTION_VIEW, 
                Uri.parse("https://play.google.com/store/apps/details?id=$packageName")))
        }
    }

    private fun shareApp() {
        val packageName = requireContext().packageName
        val shareText = "Check out Quizly - A fun quiz app! Download here: https://play.google.com/store/apps/details?id=$packageName"
        
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_SUBJECT, "Quizly - Quiz App")
            putExtra(Intent.EXTRA_TEXT, shareText)
        }
        startActivity(Intent.createChooser(intent, "Share via"))
    }

    private fun setupLegal(view: View) {
        view.findViewById<LinearLayout>(R.id.btnPrivacyPolicy).setOnClickListener {
            openUrl("https://quizly.app/privacy")
        }

        view.findViewById<LinearLayout>(R.id.btnTermsOfService).setOnClickListener {
            openUrl("https://quizly.app/terms")
        }

        view.findViewById<LinearLayout>(R.id.btnContactSupport).setOnClickListener {
            sendSupportEmail()
        }
    }

    private fun openUrl(url: String) {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        } catch (e: Exception) {
            Toast.makeText(context, "Could not open link", Toast.LENGTH_SHORT).show()
        }
    }

    private fun sendSupportEmail() {
        val intent = Intent(Intent.ACTION_SENDTO).apply {
            data = Uri.parse("mailto:support@quizly.app")
            putExtra(Intent.EXTRA_SUBJECT, "Quizly Support Request")
        }
        try {
            startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(context, "No email app found", Toast.LENGTH_SHORT).show()
        }
    }

    private fun setupAccountActions(view: View) {
        view.findViewById<MaterialButton>(R.id.btnLogout).setOnClickListener {
            MaterialAlertDialogBuilder(requireContext())
                .setTitle("Log out")
                .setMessage("Are you sure you want to log out?")
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Log out") { _, _ ->
                    logout()
                }
                .show()
        }

        view.findViewById<MaterialButton>(R.id.btnDeleteAccount).setOnClickListener {
            showDeleteAccountDialog()
        }
    }

    private fun logout() {
        FirebaseAuth.getInstance().signOut()
        session.clearSession()
        navigateToLogin()
    }

    private fun showDeleteAccountDialog() {
        MaterialAlertDialogBuilder(requireContext())
            .setTitle("Delete Account")
            .setMessage("Are you sure you want to delete your account? This action cannot be undone. All your data will be permanently deleted.")
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Delete") { _, _ ->
                showFinalDeleteConfirmation()
            }
            .show()
    }

    private fun showFinalDeleteConfirmation() {
        MaterialAlertDialogBuilder(requireContext())
            .setTitle("Confirm Deletion")
            .setMessage("Type DELETE to confirm account deletion")
            .setView(EditText(requireContext()).apply {
                hint = "Type DELETE"
                id = android.R.id.edit
                setPadding(48, 32, 48, 32)
            })
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Confirm") { dialog, _ ->
                val editText = (dialog as AlertDialog).findViewById<EditText>(android.R.id.edit)
                if (editText?.text.toString().uppercase() == "DELETE") {
                    deleteAccount()
                } else {
                    Toast.makeText(context, "Please type DELETE to confirm", Toast.LENGTH_SHORT).show()
                }
            }
            .show()
    }

    private fun deleteAccount() {
        val user = FirebaseAuth.getInstance().currentUser
        if (user == null) {
            Toast.makeText(context, "No user logged in", Toast.LENGTH_SHORT).show()
            return
        }

        user.delete()
            .addOnSuccessListener {
                Toast.makeText(context, "Account deleted successfully", Toast.LENGTH_SHORT).show()
                session.clearSession()
                navigateToLogin()
            }
            .addOnFailureListener { e ->
                if (e.message?.contains("recent") == true) {
                    Toast.makeText(context, 
                        "Please log out and log in again before deleting your account", 
                        Toast.LENGTH_LONG).show()
                } else {
                    Toast.makeText(context, "Failed to delete account: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
    }

    private fun navigateToLogin() {
        startActivity(Intent(requireContext(), MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        })
        requireActivity().finish()
    }
}
