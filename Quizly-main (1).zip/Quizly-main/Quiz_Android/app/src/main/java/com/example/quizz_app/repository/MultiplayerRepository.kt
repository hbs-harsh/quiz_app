package com.example.quizz_app.repository

import android.content.Context
import android.util.Log
import com.example.quizz_app.model.*
import com.example.quizz_app.remote.ApiService
import com.example.quizz_app.remote.RetrofitClient
import com.example.quizz_app.remote.WebSocketManager
import com.example.quizz_app.utils.SessionManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Repository for multiplayer quiz operations
 * Handles both REST API calls (room management) and WebSocket communication (game events)
 */
class MultiplayerRepository(private val context: Context) {
    
    private val apiService: ApiService = RetrofitClient.create(context)
    private val webSocketManager = WebSocketManager()
    
    // WebSocket event callbacks
    var onConnectionChanged: ((Boolean) -> Unit)? = null
        set(value) {
            field = value
            webSocketManager.onConnectionChanged = value
        }
    
    var onStartQuestion: ((NextQuestionPayload) -> Unit)? = null
        set(value) {
            field = value
            webSocketManager.onStartQuestion = value
        }
    
    var onNextQuestion: ((NextQuestionPayload) -> Unit)? = null
        set(value) {
            field = value
            webSocketManager.onNextQuestion = value
        }
    
    var onAnswerResult: ((AnswerResultPayload) -> Unit)? = null
        set(value) {
            field = value
            webSocketManager.onAnswerResult = value
        }
    
    var onGameOver: ((GameCompletedPayload) -> Unit)? = null
        set(value) {
            field = value
            webSocketManager.onGameOver = value
        }

    var onPlayerJoined: ((String) -> Unit)? = null
        set(value) {
            field = value
            webSocketManager.onPlayerJoined = value
        }
    
    var onError: ((String) -> Unit)? = null
        set(value) {
            field = value
            webSocketManager.onError = value
        }
    
    /**
     * Create a new multiplayer room
     */
    suspend fun createRoom(request: RoomCreateRequest): Result<RoomResponse> {
        return withContext(Dispatchers.IO) {
            try {
                val response = apiService.createRoom(request)
                Log.d(TAG, "Room created: ${response.roomCode}")
                Result.success(response)
            } catch (e: Exception) {
                Log.e(TAG, "Failed to create room", e)
                Result.failure(e)
            }
        }
    }
    
    /**
     * Join an existing room
     */
    suspend fun joinRoom(roomCode: String, userId: String? = null): Result<RoomResponse> {
        return withContext(Dispatchers.IO) {
            try {
                val request = RoomJoinRequest(roomCode = roomCode, userId = userId)
                val response = apiService.joinRoom(request)
                Log.d(TAG, "Joined room: ${response.roomCode}")
                Result.success(response)
            } catch (e: Exception) {
                Log.e(TAG, "Failed to join room", e)
                Result.failure(e)
            }
        }
    }
    
    /**
     * Connect to WebSocket server with Firebase token so the backend accepts the handshake (avoids 401).
     */
    fun connectWebSocket() {
        val token = SessionManager(context).getFirebaseToken()
        webSocketManager.connect(authToken = token)
    }
    
    /**
     * Subscribe to room events
     */
    fun subscribeToRoom(roomCode: String) {
        webSocketManager.subscribeToRoom(roomCode)
    }
    
    /**
     * Start the game
     */
    fun startGame(roomId: Long, roomCode: String) {
        webSocketManager.sendStartGame(roomId, roomCode)
    }
    
    /**
     * Submit an answer
     */
    fun submitAnswer(
        roomId: Long,
        roomCode: String,
        userId: String,
        questionIndex: Int,
        selectedOption: Int
    ) {
        webSocketManager.sendAnswer(roomId, roomCode, userId, questionIndex, selectedOption)
    }

    /**
     * Leave game (quit) - notifies server so the other player wins
     */
    fun leaveGame(roomId: Long, roomCode: String, userId: String) {
        webSocketManager.sendLeaveGame(roomId, roomCode, userId)
    }
    
    /**
     * Check if WebSocket is connected
     */
    fun isWebSocketConnected(): Boolean {
        return webSocketManager.isConnected
    }
    
    /**
     * Disconnect from WebSocket
     */
    fun disconnectWebSocket() {
        webSocketManager.disconnect()
    }
    
    companion object {
        private const val TAG = "MultiplayerRepository"
    }
}
