package com.example.quizz_app.ui.leaderboard

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ProgressBar
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import com.example.quizz_app.R
import com.example.quizz_app.remote.RetrofitClient
import com.google.android.material.card.MaterialCardView
import com.google.firebase.auth.FirebaseAuth
import kotlinx.coroutines.launch

/**
 * Leaderboard (bottom nav). Shows top 200 ranks in RecyclerView and the current user's rank
 * (even if outside top 200). Data loaded from backend.
 */
class LeaderBoardFragment : Fragment() {

    companion object {
        const val MAX_LEADERBOARD_RANKS = 200
    }

    private lateinit var recycler: RecyclerView
    private lateinit var emptyView: TextView
    private lateinit var cardYourRank: MaterialCardView
    private lateinit var tvYourRankValue: TextView
    private lateinit var adapter: LeaderboardAdapter
    private lateinit var progressBar: ProgressBar
    private var swipeRefresh: SwipeRefreshLayout? = null

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_leader_board, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        
        recycler = view.findViewById(R.id.recyclerLeaderboard)
        emptyView = view.findViewById(R.id.tvLeaderboardEmpty)
        cardYourRank = view.findViewById(R.id.cardYourRank)
        tvYourRankValue = view.findViewById(R.id.tvYourRankValue)
        progressBar = view.findViewById(R.id.progressBar)
        swipeRefresh = view.findViewById(R.id.swipeRefresh)
        
        adapter = LeaderboardAdapter()

        recycler.layoutManager = LinearLayoutManager(requireContext())
        recycler.adapter = adapter
        recycler.setHasFixedSize(true)

        swipeRefresh?.setOnRefreshListener {
            loadLeaderboard()
        }

        loadLeaderboard()
    }

    private fun loadLeaderboard() {
        val currentUserId = FirebaseAuth.getInstance().currentUser?.uid

        showLoading(true)

        lifecycleScope.launch {
            try {
                val response = RetrofitClient.create(requireContext())
                    .getLeaderboard(currentUserId)

                val topEntries = response.topPlayers.map { entry ->
                    LeaderboardEntry(
                        rank = entry.rank,
                        displayName = entry.displayName,
                        publicUserId = entry.publicUserId,
                        wins = entry.wins,
                        points = entry.points
                    )
                }

                adapter.submitList(topEntries)

                if (topEntries.isEmpty()) {
                    recycler.visibility = View.GONE
                    emptyView.visibility = View.VISIBLE
                } else {
                    recycler.visibility = View.VISIBLE
                    emptyView.visibility = View.GONE
                }

                // Show current user's rank
                if (response.currentUser != null && response.currentUserRank > 0) {
                    cardYourRank.visibility = View.VISIBLE
                    val wins = response.currentUser.wins
                    val points = response.currentUser.points
                    tvYourRankValue.text = "#${response.currentUserRank} • $wins win${if (wins == 1) "" else "s"} • $points pts"
                } else {
                    cardYourRank.visibility = View.GONE
                }

            } catch (e: Exception) {
                e.printStackTrace()
                emptyView.text = "Failed to load leaderboard.\nPull to refresh."
                emptyView.visibility = View.VISIBLE
                recycler.visibility = View.GONE
                cardYourRank.visibility = View.GONE
            } finally {
                showLoading(false)
            }
        }
    }

    private fun showLoading(loading: Boolean) {
        if (loading) {
            progressBar.visibility = View.VISIBLE
            recycler.visibility = View.GONE
            emptyView.visibility = View.GONE
        } else {
            progressBar.visibility = View.GONE
            swipeRefresh?.isRefreshing = false
        }
    }
}