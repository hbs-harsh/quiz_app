package com.example.quizz_app.ui.result

import android.animation.ObjectAnimator
import android.os.Bundle
import android.view.View
import android.widget.ImageView
import android.widget.TextView
import androidx.fragment.app.Fragment
import com.bumptech.glide.Glide
import com.bumptech.glide.load.resource.gif.GifDrawable
import com.bumptech.glide.request.target.CustomTarget
import com.bumptech.glide.request.transition.Transition
import com.example.quizz_app.R
import com.google.android.material.button.MaterialButton

class ResultFragment : Fragment(R.layout.fragment_result2) {

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val score = arguments?.getInt("score") ?: 0
        val total = arguments?.getInt("total") ?: 0
        val points = arguments?.getInt("points") ?: (score * 10)

        val tvPoints = view.findViewById<TextView>(R.id.tvPoints)
        val tvCorrect = view.findViewById<TextView>(R.id.tvCorrect)
        val tvTotal = view.findViewById<TextView>(R.id.tvTotal)
        val tvBadge = view.findViewById<TextView>(R.id.tvBadge)
        val ivTrophy = view.findViewById<ImageView>(R.id.ivTrophy)
        val confettiView = view.findViewById<ImageView>(R.id.confettiView)

        tvPoints.text = points.toString()
        tvCorrect.text = score.toString()
        tvTotal.text = total.toString()

        val percentage = if (total > 0) (score * 100 / total) else 0
        tvBadge.text = when {
            percentage >= 90 -> "🏆"
            percentage >= 70 -> "🥇"
            percentage >= 50 -> "🥈"
            percentage >= 30 -> "🥉"
            else -> "📝"
        }

        loadTrophyGif(ivTrophy)
        loadConfettiAndAnimateFromBottom(confettiView)

        view.findViewById<MaterialButton>(R.id.btnContinue).setOnClickListener {
            requireActivity().finish()
        }
    }

    private fun loadTrophyGif(imageView: ImageView) {
        Glide.with(requireContext())
            .asGif()
            .load(R.drawable.trophy)
            .into(imageView)
    }

    private fun loadConfettiAndAnimateFromBottom(confettiView: ImageView) {
        Glide.with(requireContext())
            .asGif()
            .load(R.drawable.confetti)
            .into(object : CustomTarget<GifDrawable>() {
                override fun onResourceReady(
                    resource: GifDrawable,
                    transition: Transition<in GifDrawable>?
                ) {
                    resource.setLoopCount(GifDrawable.LOOP_FOREVER)
                    confettiView.setImageDrawable(resource)
                    resource.start()
                    confettiView.visibility = View.VISIBLE
                    confettiView.post {
                        val fromY = requireView().height.toFloat()
                        confettiView.translationY = fromY
                        ObjectAnimator.ofFloat(confettiView, View.TRANSLATION_Y, fromY, 0f).apply {
                            duration = 2200
                            start()
                        }
                    }
                }
                override fun onLoadCleared(placeholder: android.graphics.drawable.Drawable?) {}
            })
    }
}
