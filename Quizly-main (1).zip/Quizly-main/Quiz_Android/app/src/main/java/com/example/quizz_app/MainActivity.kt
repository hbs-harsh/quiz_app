package com.example.quizz_app

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatDelegate
import androidx.appcompat.app.AppCompatActivity
import com.example.quizz_app.ui.auth.LoginFragment
import com.example.quizz_app.utils.SessionManager
import com.google.firebase.auth.FirebaseAuth

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        val dark = SessionManager(this).isDarkMode()
        AppCompatDelegate.setDefaultNightMode(
            if (dark) AppCompatDelegate.MODE_NIGHT_YES else AppCompatDelegate.MODE_NIGHT_NO
        )
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        if (savedInstanceState == null) {
            // Session persistence: if user is already signed in, go to main app
            val currentUser = FirebaseAuth.getInstance().currentUser
            val session = SessionManager(this)
            if (currentUser != null && session.isLoggedIn()) {
                session.saveUserId(currentUser.uid)
                startActivity(Intent(this, MainActivity2::class.java))
                finish()
                return
            }
            supportFragmentManager.beginTransaction()
                .replace(R.id.container, LoginFragment())
                .commit()
        }
    }
}
