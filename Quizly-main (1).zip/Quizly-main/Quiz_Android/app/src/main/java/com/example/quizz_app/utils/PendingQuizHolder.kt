package com.example.quizz_app.utils

import com.example.quizz_app.dto.QuizResponse

/**
 * Holds a quiz loaded from PDF (or other custom source) so QuizLoadingFragment
 * can use it instead of calling the topic API.
 */
object PendingQuizHolder {

    @Volatile
    private var quiz: QuizResponse? = null

    @Volatile
    private var timerSeconds: Int = 30

    fun set(quizResponse: QuizResponse, timerSec: Int) {
        quiz = quizResponse
        timerSeconds = timerSec
    }

    fun consume(): Pair<QuizResponse, Int>? {
        val q = quiz
        quiz = null
        return if (q != null) Pair(q, timerSeconds) else null
    }

    fun hasPending(): Boolean = quiz != null
}
