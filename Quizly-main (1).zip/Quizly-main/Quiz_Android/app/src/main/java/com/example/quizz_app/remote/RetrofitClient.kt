package com.example.quizz_app.remote

import android.content.Context
import com.example.quizz_app.remote.ApiService
import com.example.quizz_app.remote.AuthInterceptor
import com.example.quizz_app.utils.SessionManager
import com.example.quizz_app.utils.Constants
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

object RetrofitClient {

    fun create(context: Context): ApiService {

        val sessionManager = SessionManager(context)

        val client = OkHttpClient.Builder()
            .addInterceptor(AuthInterceptor(sessionManager))
            .build()

        return Retrofit.Builder()
            .baseUrl(Constants.BASE_URL)
            .client(client)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(ApiService::class.java)
    }
}
