package com.example.quizz_app.ui.auth

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.quizz_app.model.AuthState
import com.example.quizz_app.repository.AuthRepository
import com.google.firebase.auth.FirebaseAuth

class AuthViewModel : ViewModel() {

    private val repository = AuthRepository()

    private val _authState = MutableLiveData<AuthState>(AuthState.Idle)
    val authState: LiveData<AuthState> = _authState

    private val _firebaseToken = MutableLiveData<String?>()
    val firebaseToken: LiveData<String?> = _firebaseToken

    fun register(name: String, email: String, password: String) {
        _authState.value = AuthState.Loading
        repository.register(
            name,
            email,
            password,
            onSuccess = { fetchFirebaseToken() },
            onError = { _authState.value = AuthState.Error(it) }
        )
    }

    fun login(email: String, password: String) {
        _authState.value = AuthState.Loading
        repository.login(
            email,
            password,
            onSuccess = { fetchFirebaseToken() },
            onError = { _authState.value = AuthState.Error(it) }
        )
    }

    fun signInWithGoogle(idToken: String) {
        _authState.value = AuthState.Loading
        repository.signInWithGoogle(
            idToken,
            onSuccess = { fetchFirebaseToken() },
            onError = { _authState.value = AuthState.Error(it) }
        )
    }

    private fun fetchFirebaseToken() {
        FirebaseAuth.getInstance().currentUser
            ?.getIdToken(true)
            ?.addOnSuccessListener { result ->
                val token = result.token
                if (token != null) {
                    _firebaseToken.value = token
                    _authState.value = AuthState.Success
                } else {
                    _authState.value = AuthState.Error("Token generation failed")
                }
            }
            ?.addOnFailureListener {
                _authState.value = AuthState.Error(it.message ?: "Token error")
            }


    }


}
