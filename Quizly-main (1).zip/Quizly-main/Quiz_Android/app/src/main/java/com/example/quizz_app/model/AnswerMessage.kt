package com.example.quizz_app.model

data class AnswerMessage(
    val roomId: Long,
    val roomCode: String,
    val userId: String,
    val questionIndex: Int,
    val selectedOption: Int
)
