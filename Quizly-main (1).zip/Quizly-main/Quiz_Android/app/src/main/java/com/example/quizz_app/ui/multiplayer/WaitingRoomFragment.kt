package com.example.quizz_app.ui.multiplayer

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.DialogFragment
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.navigation.fragment.findNavController
import com.example.quizz_app.QuizzActivity
import com.example.quizz_app.R
import com.example.quizz_app.model.RoomStatus
import com.example.quizz_app.ui.quiz.LoadingQuizDialogFragment

/** Waiting room fragment - Shows room code and waits for players */
class WaitingRoomFragment : Fragment(R.layout.fragment_waiting_room) {

    private val viewModel: MultiplayerViewModel by activityViewModels()

    private lateinit var tvRoomCode: TextView
    private lateinit var tvPlayerCount: TextView
    private lateinit var tvStatus: TextView
    private lateinit var btnStartGame: Button
    private lateinit var progressBar: ProgressBar

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        tvRoomCode = view.findViewById(R.id.tvRoomCode)
        tvPlayerCount = view.findViewById(R.id.tvPlayerCount)
        tvStatus = view.findViewById(R.id.tvStatus)
        btnStartGame = view.findViewById(R.id.btnStartGame)
        progressBar = view.findViewById(R.id.progressBar)

        setupClickListeners()
        observeViewModel()
    }

    private fun setupClickListeners() {
        btnStartGame.setOnClickListener {
            showLoadingQuizDialog()
            viewModel.startGame()
        }
    }

    private fun showLoadingQuizDialog() {
        LoadingQuizDialogFragment().show(childFragmentManager, LoadingQuizDialogFragment.LOADING_QUIZ_DIALOG_TAG)
    }

    private fun dismissLoadingQuizDialog() {
        (childFragmentManager.findFragmentByTag(LoadingQuizDialogFragment.LOADING_QUIZ_DIALOG_TAG) as? DialogFragment)?.dismiss()
    }

    private fun observeViewModel() {
        viewModel.roomCode.observe(viewLifecycleOwner) { roomCode ->
            tvRoomCode.text = roomCode ?: "---"
        }

        viewModel.roomStatus.observe(viewLifecycleOwner) { status ->
            updateUI()
        }

        viewModel.isConnected.observe(viewLifecycleOwner) { connected ->
            updateUI()
        }

        viewModel.currentQuestion.observe(viewLifecycleOwner) { question ->
            if (question == null) return@observe
            dismissLoadingQuizDialog()
            // Inside QuizzActivity: question is already in ViewModel (from WebSocket). Just navigate - do NOT set again or we trigger observer loop.
            if (requireActivity() is QuizzActivity) {
                val navController = findNavController()
                if (navController.currentDestination?.id == R.id.waitingRoomFragment) {
                    navController.navigate(R.id.action_waitingRoomFragment_to_multiplayerQuizFragment)
                }
            } else {
                // Legacy: started from MainActivity2, launch QuizActivity
                val intent = Intent(requireContext(), QuizzActivity::class.java).apply {
                    putExtra("QUIZ_MODE", "MULTIPLAYER")
                    putExtra("ROOM_CODE", viewModel.getRoomCode())
                    putExtra("ROOM_ID", viewModel.getRoomId())
                    putExtra("USER_ID", viewModel.getUserId())
                    putExtra("QUESTION_INDEX", question.questionIndex)
                    putExtra("QUESTION_TEXT", question.question)
                    putExtra("QUESTION_OPTIONS", question.options.toTypedArray())
                }
                startActivity(intent)
                viewModel.clearCurrentQuestion()
            }
        }

        viewModel.errorMessage.observe(viewLifecycleOwner) { error ->
            error?.let {
                dismissLoadingQuizDialog()
                Toast.makeText(context, it, Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun updateUI() {
        val status = viewModel.roomStatus.value
        val connected = viewModel.isConnected.value ?: false

        val isReady = status == RoomStatus.READY && connected

        if (isReady) {
            tvPlayerCount.text = "2 / 2"
            tvStatus.text = "Ready to start!"
            btnStartGame.isEnabled = true
            progressBar.visibility = View.GONE
        } else {
            tvPlayerCount.text = "1 / 2"
            tvStatus.text = if (connected) "Waiting for opponent..." else "Connecting..."
            btnStartGame.isEnabled = false
            progressBar.visibility = View.VISIBLE
        }
    }
}
