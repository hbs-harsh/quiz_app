package com.example.quizz_app.ui.multiplayer

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.animation.PropertyValuesHolder
import android.os.Bundle
import android.os.CountDownTimer
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import androidx.cardview.widget.CardView
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.navigation.fragment.findNavController
import com.example.quizz_app.R
import com.example.quizz_app.utils.QuizFeedbackHelper
import com.google.android.material.progressindicator.CircularProgressIndicator
import com.google.firebase.auth.FirebaseAuth

/**
 * Multiplayer quiz fragment - Real-time quiz gameplay with enhanced UI
 */
class MultiplayerQuizFragment : Fragment(R.layout.fragment_multiplayer_quiz) {
    
    private val viewModel: MultiplayerViewModel by activityViewModels()
    
    private lateinit var tvMyScore: TextView
    private lateinit var tvOpponentScore: TextView
    private lateinit var tvProgress: TextView
    private lateinit var tvQuestion: TextView
    private lateinit var questionCard: View
    private lateinit var optionsContainer: LinearLayout
    private lateinit var waitingOverlay: View
    private lateinit var tvWaitingStatus: TextView
    private lateinit var progressBar: View
    private lateinit var timerCircular: CircularProgressIndicator
    
    private var countDownTimer: CountDownTimer? = null
    private var currentQuestionIndex = 0
    private var hasAnswered = false
    private val optionViews = mutableListOf<CardView>()
    private var mySelectedOption = -1
    private var correctAnswerIndex = -1 // Will be set when we receive answer results
    
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        
        android.util.Log.d("MultiplayerQuiz", "onViewCreated called")
        
        tvMyScore = view.findViewById(R.id.tvMyScore)
        tvOpponentScore = view.findViewById(R.id.tvOpponentScore)
        view.findViewById<TextView>(R.id.tvMyName).text =
            FirebaseAuth.getInstance().currentUser?.displayName?.takeIf { it.isNotBlank() } ?: "You"
        view.findViewById<TextView>(R.id.tvOpponentName).text = "Opponent"
        tvProgress = view.findViewById(R.id.tvProgress)
        tvQuestion = view.findViewById(R.id.tvQuestion)
        questionCard = view.findViewById(R.id.questionCard)
        optionsContainer = view.findViewById(R.id.optionsContainer)
        waitingOverlay = view.findViewById(R.id.waitingOverlay)
        tvWaitingStatus = view.findViewById(R.id.tvWaitingStatus)
        progressBar = view.findViewById(R.id.progressBar)
        timerCircular = view.findViewById(R.id.timerCircular)
        
        QuizFeedbackHelper.init(requireContext())
        
        // Ensure options container is visible initially
        optionsContainer.visibility = View.VISIBLE
        
        android.util.Log.d("MultiplayerQuiz", "Setting up observers...")
        observeViewModel()
        
        // Check if question already exists (in case it arrived before fragment was created)
        viewModel.currentQuestion.value?.let { question ->
            android.util.Log.d("MultiplayerQuiz", "Question already exists, displaying immediately")
            currentQuestionIndex = question.questionIndex
            hasAnswered = false
            mySelectedOption = -1
            correctAnswerIndex = -1
            displayQuestion(question.question, question.options, question.timerSeconds)
        }
    }
    
    override fun onDestroyView() {
        countDownTimer?.cancel()
        countDownTimer = null
        QuizFeedbackHelper.release()
        super.onDestroyView()
    }
    
    private fun observeViewModel() {
        android.util.Log.d("MultiplayerQuiz", "Setting up currentQuestion observer")
        viewModel.currentQuestion.observe(viewLifecycleOwner) { question ->
            android.util.Log.d("MultiplayerQuiz", "currentQuestion observer triggered. Question: ${question?.question}, Options: ${question?.options}")
            question?.let {
                android.util.Log.d("MultiplayerQuiz", "Processing question in observer")
                currentQuestionIndex = it.questionIndex
                hasAnswered = false
                mySelectedOption = -1
                correctAnswerIndex = -1
                viewModel.hasAnsweredCurrentQuestion.value?.let { answered ->
                    hasAnswered = answered
                }
                val isFirstQuestion = optionViews.isEmpty()
                if (isFirstQuestion) {
                    displayQuestion(it.question, it.options, it.timerSeconds)
                } else {
                    runQuestionTransition {
                        displayQuestion(it.question, it.options, it.timerSeconds)
                    }
                }
            } ?: android.util.Log.d("MultiplayerQuiz", "Question is null in observer")
        }
        
        viewModel.myScore.observe(viewLifecycleOwner) { score ->
            animateScore(tvMyScore, score)
        }
        
        viewModel.opponentScore.observe(viewLifecycleOwner) { score ->
            animateScore(tvOpponentScore, score)
        }
        
        viewModel.waitingForOpponent.observe(viewLifecycleOwner) { waiting ->
            if (waiting && hasAnswered) {
                // Show waiting overlay only if user has answered and opponent hasn't
                waitingOverlay.visibility = View.VISIBLE
                tvWaitingStatus.text = "Waiting for opponent to answer..."
                progressBar.visibility = View.VISIBLE
            } else if (hasAnswered && viewModel.opponentAnswered.value == true) {
                // Both answered, show brief message before next question
                waitingOverlay.visibility = View.VISIBLE
                tvWaitingStatus.text = "Both players answered! Moving to next question..."
                progressBar.visibility = View.VISIBLE
            } else {
                waitingOverlay.visibility = View.GONE
                progressBar.visibility = View.GONE
            }
            // Disable options if answered
            optionsContainer.isEnabled = !hasAnswered
        }
        
        viewModel.hasAnsweredCurrentQuestion.observe(viewLifecycleOwner) { answered ->
            hasAnswered = answered
            if (answered) {
                // Disable all options
                optionViews.forEach { 
                    it.isEnabled = false
                    it.isClickable = false
                }
                optionsContainer.isEnabled = false
            } else {
                // Enable options
                optionViews.forEach { 
                    it.isEnabled = true
                    it.isClickable = true
                }
                optionsContainer.isEnabled = true
            }
        }
        
        viewModel.myAnswerResult.observe(viewLifecycleOwner) { result ->
            result?.let {
                // Show only MY correct/incorrect feedback (my chosen option turns green/red)
                showAnswerFeedback(it.selectedOption, it.correct, isMyAnswer = true)
            }
        }
        
        viewModel.opponentAnswerResult.observe(viewLifecycleOwner) { result ->
            result?.let {
                // Do NOT show which option the opponent chose - they should not see each other's answer.
                // Only update status text when both have answered.
                if (hasAnswered) {
                    tvWaitingStatus.text = "Both players answered! Moving to next question..."
                }
            }
        }
        
        viewModel.gameOver.observe(viewLifecycleOwner) { gameOverData ->
            gameOverData?.let {
                android.util.Log.d("MultiplayerQuiz", "Game over observed! Scores: ${it.finalScores}, Winner: ${it.winnerId}, Draw: ${it.isDraw}, OpponentLeft: ${it.opponentLeft}")
                // Defer navigation to next frame so UI state is committed (fixes "other player doesn't see result" when someone exits)
                view?.post {
                    try {
                        if (view == null || !isAdded) return@post
                        findNavController().navigate(R.id.action_multiplayerQuizFragment_to_multiplayerResultFragment)
                        android.util.Log.d("MultiplayerQuiz", "Navigated to result fragment")
                    } catch (e: Exception) {
                        android.util.Log.e("MultiplayerQuiz", "Failed to navigate to result fragment", e)
                    }
                }
            }
        }
    }
    
    private fun runQuestionTransition(onTransitionEnd: () -> Unit) {
        val fadeOutCard = ObjectAnimator.ofFloat(questionCard, View.ALPHA, 1f, 0f).apply { duration = 180 }
        val fadeOutOptions = ObjectAnimator.ofFloat(optionsContainer, View.ALPHA, 1f, 0f).apply { duration = 180 }
        AnimatorSet().apply {
            playTogether(fadeOutCard, fadeOutOptions)
            addListener(object : AnimatorListenerAdapter() {
                override fun onAnimationEnd(animation: Animator) {
                    questionCard.alpha = 0f
                    optionsContainer.alpha = 0f
                    onTransitionEnd()
                    questionCard.animate().alpha(1f).setDuration(220).start()
                    optionsContainer.animate().alpha(1f).setDuration(220).start()
                }
            })
            start()
        }
    }

    private fun displayQuestion(question: String, options: List<String>, timerSeconds: Int = 30) {
        android.util.Log.d("MultiplayerQuiz", "Displaying question: $question, timer: ${timerSeconds}s")
        countDownTimer?.cancel()
        countDownTimer = null
        
        tvProgress.text = "Question ${currentQuestionIndex + 1}"
        tvQuestion.text = question
        
        // Modern circular timer (same duration on both devices - synced by server)
        timerCircular.max = 100
        timerCircular.progress = 100
        timerCircular.visibility = View.VISIBLE
        if (timerSeconds > 0) {
            countDownTimer = object : CountDownTimer((timerSeconds * 1000).toLong(), 100) {
                override fun onTick(millisUntilFinished: Long) {
                    if (!isAdded) return
                    val remainingSec = (millisUntilFinished / 1000.0).coerceAtLeast(0.0)
                    timerCircular.progress = ((remainingSec / timerSeconds) * 100).toInt().coerceIn(0, 100)
                }
                override fun onFinish() {
                    if (!isAdded) return
                    timerCircular.progress = 0
                    onTimerExpired()
                }
            }.start()
        }
        
        // Clear previous options
        optionsContainer.removeAllViews()
        optionViews.clear()
        
        // Reset visual state
        mySelectedOption = -1
        correctAnswerIndex = -1
        
        // Ensure container is visible and enabled
        optionsContainer.visibility = View.VISIBLE
        optionsContainer.isEnabled = !hasAnswered
        
        if (options.isEmpty()) {
            android.util.Log.e("MultiplayerQuiz", "ERROR: Options list is empty!")
            return
        }
        
        options.forEachIndexed { index, option ->
            android.util.Log.d("MultiplayerQuiz", "Creating option $index: $option")
            
            val optionCard = layoutInflater.inflate(
                R.layout.item_quiz_option,
                optionsContainer,
                false
            ) as CardView
            
            val optionText = optionCard.findViewById<TextView>(R.id.tvOption)
            val optionLetter = optionCard.findViewById<TextView>(R.id.tvOptionLetter)
            optionText.text = option
            optionLetter.text = ('A' + index).toString()
            
            // Reset to default colors
            optionText.setTextColor(resources.getColor(R.color.mp_text_primary, null))
            optionCard.setCardBackgroundColor(resources.getColor(R.color.mp_bg_card, null))
            optionCard.alpha = 1.0f
            optionCard.isEnabled = !hasAnswered
            
            optionCard.setOnClickListener {
                if (!hasAnswered && optionsContainer.isEnabled) {
                    QuizFeedbackHelper.tapHaptic(optionCard)
                    mySelectedOption = index
                    selectOption(optionCard, index)
                    countDownTimer?.cancel()
                    countDownTimer = null
                    viewModel.submitAnswer(currentQuestionIndex, index)
                }
            }
            
            optionsContainer.addView(optionCard)
            optionViews.add(optionCard)
            
            android.util.Log.d("MultiplayerQuiz", "Option $index added to container. Container child count: ${optionsContainer.childCount}")
        }
        
        android.util.Log.d("MultiplayerQuiz", "All options displayed. Total: ${optionsContainer.childCount}")
    }
    
    private fun onTimerExpired() {
        countDownTimer = null
        if (hasAnswered) return
        hasAnswered = true
        // Submit timeout answer (-1) so server can advance when both players have answered or timed out
        viewModel.submitAnswer(currentQuestionIndex, -1)
        optionViews.forEach {
            it.isEnabled = false
            it.isClickable = false
        }
        optionsContainer.isEnabled = false
        waitingOverlay.visibility = View.VISIBLE
        tvWaitingStatus.text = "Time's up! Waiting for opponent..."
        progressBar.visibility = View.VISIBLE
    }
    
    private fun selectOption(selectedCard: CardView, optionIndex: Int) {
        // Highlight selected option
        selectedCard.setCardBackgroundColor(resources.getColor(R.color.mp_primary_purple, null))
        selectedCard.findViewById<TextView>(R.id.tvOption)
            .setTextColor(resources.getColor(R.color.mp_text_white, null))
    }
    
    private fun showAnswerFeedback(optionIndex: Int, isCorrect: Boolean, isMyAnswer: Boolean) {
        if (optionIndex < 0 || optionIndex >= optionViews.size) return
        
        val optionCard = optionViews[optionIndex]
        val optionText = optionCard.findViewById<TextView>(R.id.tvOption)
        
        if (isMyAnswer) {
            if (isCorrect) QuizFeedbackHelper.playCorrect(optionCard) else QuizFeedbackHelper.playWrong(optionCard)
            if (isCorrect) {
                optionCard.setCardBackgroundColor(resources.getColor(R.color.mp_correct, null))
                optionText.setTextColor(resources.getColor(R.color.mp_text_white, null))
                animateCorrectPulse(optionCard)
            } else {
                optionCard.setCardBackgroundColor(resources.getColor(R.color.mp_wrong, null))
                optionText.setTextColor(resources.getColor(R.color.mp_text_white, null))
                animateWrongShake(optionCard)
            }
        } else {
            optionCard.alpha = 0.7f
            if (isCorrect) {
                optionCard.setCardBackgroundColor(resources.getColor(R.color.mp_correct, null))
            } else {
                optionCard.setCardBackgroundColor(resources.getColor(R.color.mp_wrong, null))
            }
            optionText.setTextColor(resources.getColor(R.color.mp_text_white, null))
        }
        
        if (isCorrect) correctAnswerIndex = optionIndex
    }
    
    private fun animateCorrectPulse(card: View) {
        val scaleX = PropertyValuesHolder.ofFloat(View.SCALE_X, 1f, 1.08f, 1f)
        val scaleY = PropertyValuesHolder.ofFloat(View.SCALE_Y, 1f, 1.08f, 1f)
        ObjectAnimator.ofPropertyValuesHolder(card, scaleX, scaleY).apply {
            duration = 250
            start()
        }
    }
    
    private fun animateWrongShake(card: View) {
        ObjectAnimator.ofFloat(card, View.TRANSLATION_X, 0f, -14f, 14f, -10f, 10f, 0f).apply {
            duration = 380
            start()
        }
    }
    
    private fun animateScore(textView: TextView, newScore: Int) {
        val currentScore = textView.text.toString().toIntOrNull() ?: 0
        if (currentScore < newScore) {
            ObjectAnimator.ofInt(currentScore, newScore).apply {
                duration = 400
                addUpdateListener { animator ->
                    textView.text = (animator.animatedValue as Int).toString()
                }
                start()
            }
            textView.animate().scaleX(1.25f).scaleY(1.25f).setDuration(120).withEndAction {
                textView.animate().scaleX(1f).scaleY(1f).setDuration(180).start()
            }.start()
        } else {
            textView.text = newScore.toString()
        }
    }
}
