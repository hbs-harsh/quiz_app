package com.example.quizz_app.model

data class AnswerResultPayload(
    val userId: String,
    val questionIndex: Int,
    val selectedOption: Int,
    val correct: Boolean
)
