package com.example.quizz_app.model

data class GameCompletedPayload(
    val finalScores: Map<String, Int>,
    val winnerId: String?,
    val isDraw: Boolean,
    val opponentLeft: Boolean = false,
    val playerDisplayNames: Map<String, String>? = null
)
