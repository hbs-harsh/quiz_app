package com.example.quizz_app.remote

import android.util.Log
import com.example.quizz_app.model.*
import com.example.quizz_app.utils.Constants
import com.google.gson.Gson
import com.google.gson.JsonObject
import com.google.gson.reflect.TypeToken
import io.reactivex.disposables.CompositeDisposable
import io.reactivex.disposables.Disposable
import ua.naiksoftware.stomp.Stomp
import ua.naiksoftware.stomp.StompClient
import ua.naiksoftware.stomp.dto.LifecycleEvent

/** WebSocket Manager using STOMP protocol for multiplayer quiz game */
class WebSocketManager {

    private var stompClient: StompClient? = null
    private val compositeDisposable = CompositeDisposable()
    private val gson = Gson()

    // Pending subscriptions to process after connection
    private val pendingSubscriptions = mutableSetOf<String>()

    // Connection status
    var isConnected = false
        private set

    // Callbacks
    var onConnectionChanged: ((Boolean) -> Unit)? = null
    var onStartQuestion: ((NextQuestionPayload) -> Unit)? = null
    var onNextQuestion: ((NextQuestionPayload) -> Unit)? = null
    var onAnswerResult: ((AnswerResultPayload) -> Unit)? = null
    var onGameOver: ((GameCompletedPayload) -> Unit)? = null
    var onPlayerJoined: ((String) -> Unit)? = null  // roomStatus
    var onError: ((String) -> Unit)? = null

    /**
     * Connect to WebSocket server.
     * @param authToken Firebase ID token; if non-null, sent as Authorization: Bearer on the handshake (required by backend to avoid 401).
     */
    fun connect(authToken: String? = null) {
        if (stompClient != null && isConnected) {
            Log.d(TAG, "Already connected")
            return
        }

        val headers = mutableMapOf<String, String>()
        if (!authToken.isNullOrBlank()) {
            headers["Authorization"] = "Bearer $authToken"
        }

        Log.d(TAG, "Connecting to ${Constants.WS_URL} (auth: ${if (headers.isNotEmpty()) "yes" else "no"})")
        stompClient = Stomp.over(Stomp.ConnectionProvider.OKHTTP, Constants.WS_URL, headers, null)

        // Lifecycle listener
        val lifecycleDisposable: Disposable =
                stompClient!!.lifecycle().subscribe { lifecycleEvent ->
                    when (lifecycleEvent.type) {
                        LifecycleEvent.Type.OPENED -> {
                            Log.d(TAG, "WebSocket OPENED")
                            isConnected = true
                            onConnectionChanged?.invoke(true)

                            // Process any pending subscriptions
                            processPendingSubscriptions()
                        }
                        LifecycleEvent.Type.CLOSED -> {
                            Log.d(TAG, "WebSocket CLOSED")
                            isConnected = false
                            onConnectionChanged?.invoke(false)
                        }
                        LifecycleEvent.Type.ERROR -> {
                            Log.e(TAG, "WebSocket ERROR: ${lifecycleEvent.exception?.message}")
                            isConnected = false
                            onConnectionChanged?.invoke(false)
                            onError?.invoke(lifecycleEvent.exception?.message ?: "Connection error")
                        }
                        else -> {
                            Log.d(TAG, "WebSocket: ${lifecycleEvent.type}")
                        }
                    }
                }

        compositeDisposable.add(lifecycleDisposable)
        stompClient?.connect()
    }

    /** Subscribe to a room's topic to receive game events */
    fun subscribeToRoom(roomCode: String) {
        // If not connected yet, queue the subscription
        if (!isConnected) {
            Log.d(TAG, "Not connected yet, queueing subscription for room: $roomCode")
            pendingSubscriptions.add(roomCode)
            return
        }

        val topic = Constants.getWsRoomTopic(roomCode)
        Log.d(TAG, "Subscribing to topic: $topic")

        val topicDisposable: Disposable =
                stompClient!!
                        .topic(topic)
                        .subscribe(
                                { topicMessage ->
                                    Log.d(TAG, "Received message: ${topicMessage.payload}")
                                    handleMessage(topicMessage.payload)
                                },
                                { error ->
                                    Log.e(TAG, "Error on topic $topic", error)
                                    onError?.invoke("Subscription error: ${error.message}")
                                }
                        )

        compositeDisposable.add(topicDisposable)
        // Remove from pending if it was queued
        pendingSubscriptions.remove(roomCode)
    }

    /** Process any pending subscriptions after connection is established */
    private fun processPendingSubscriptions() {
        if (pendingSubscriptions.isEmpty()) return

        Log.d(TAG, "Processing ${pendingSubscriptions.size} pending subscriptions")
        val roomsToSubscribe = pendingSubscriptions.toList()
        pendingSubscriptions.clear()

        roomsToSubscribe.forEach { roomCode -> subscribeToRoom(roomCode) }
    }

    /** Parse and route incoming messages based on event type */
    private fun handleMessage(jsonPayload: String) {
        try {
            Log.d(TAG, "Raw message received: $jsonPayload")
            val jsonObject = gson.fromJson(jsonPayload, JsonObject::class.java)
            val eventType = SocketEventType.valueOf(jsonObject.get("type").asString)
            val payload = jsonObject.get("payload")

            Log.d(TAG, "Event type: $eventType")
            Log.d(TAG, "Payload JSON: ${payload.toString()}")

            when (eventType) {
                SocketEventType.START_QUESTION -> {
                    Log.d(TAG, "Parsing START_QUESTION payload...")
                    val data = gson.fromJson(payload, NextQuestionPayload::class.java)
                    Log.d(TAG, "Parsed NextQuestionPayload - Index: ${data.questionIndex}, Question: ${data.question}, Options: ${data.options}")
                    onStartQuestion?.invoke(data)
                }
                SocketEventType.NEXT_QUESTION -> {
                    Log.d(TAG, "Parsing NEXT_QUESTION payload...")
                    val data = gson.fromJson(payload, NextQuestionPayload::class.java)
                    Log.d(TAG, "Parsed NextQuestionPayload - Index: ${data.questionIndex}, Question: ${data.question}, Options: ${data.options}")
                    onNextQuestion?.invoke(data)
                }
                SocketEventType.ANSWER_RESULT -> {
                    val data = gson.fromJson(payload, AnswerResultPayload::class.java)
                    onAnswerResult?.invoke(data)
                }
                SocketEventType.GAME_OVER -> {
                    Log.d(TAG, "GAME_OVER event received! Parsing payload...")
                    // Parse Map<String, Int> for finalScores
                    val gameOverJson = payload.asJsonObject
                    Log.d(TAG, "Game over JSON: $gameOverJson")
                    
                    val scoresType = object : TypeToken<Map<String, Int>>() {}.type
                    val finalScores: Map<String, Int> =
                            gson.fromJson(gameOverJson.get("finalScores"), scoresType)
                    
                    Log.d(TAG, "Final scores parsed: $finalScores")

                    // Null-safe parsing
                    val winnerIdElement = gameOverJson.get("winnerId")
                    val winnerId =
                            if (winnerIdElement?.isJsonNull != false) null
                            else winnerIdElement.asString

                    val isDrawElement = gameOverJson.get("isDraw")
                    val isDraw = isDrawElement?.asBoolean ?: false

                    val opponentLeftElement = gameOverJson.get("opponentLeft")
                    val opponentLeft = opponentLeftElement?.asBoolean ?: false

                    val playerDisplayNamesElement = gameOverJson.get("playerDisplayNames")
                    val playerDisplayNamesType = object : TypeToken<Map<String, String>>() {}.type
                    val playerDisplayNames: Map<String, String>? =
                        if (playerDisplayNamesElement != null && !playerDisplayNamesElement.isJsonNull)
                            gson.fromJson(playerDisplayNamesElement, playerDisplayNamesType)
                        else null

                    Log.d(TAG, "Winner ID: $winnerId, Is Draw: $isDraw, Opponent Left: $opponentLeft")
                    
                    val data = GameCompletedPayload(finalScores, winnerId, isDraw, opponentLeft, playerDisplayNames)
                    Log.d(TAG, "Invoking onGameOver callback")
                    onGameOver?.invoke(data)
                }
                SocketEventType.COUNTDOWN -> {
                    // Optionally handle countdown events
                    Log.d(TAG, "Countdown event received")
                }
                SocketEventType.PLAYER_JOINED -> {
                    Log.d(TAG, "Player joined event received")
                    val payloadObj = payload.asJsonObject
                    val roomStatus = payloadObj.get("roomStatus")?.asString ?: "UNKNOWN"
                    Log.d(TAG, "Room status after join: $roomStatus")
                    onPlayerJoined?.invoke(roomStatus)
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error parsing message", e)
            onError?.invoke("Message parsing error: ${e.message}")
        }
    }

    /** Send start game request */
    fun sendStartGame(roomId: Long, roomCode: String) {
        if (!isConnected) {
            Log.e(TAG, "Cannot start game: Not connected to server")
            onError?.invoke("Cannot start game: Not connected to server")
            return
        }

        val request = StartGameRequest(roomId, roomCode)
        val jsonString = gson.toJson(request)

        Log.d(TAG, "Sending start game: $jsonString")
        stompClient
                ?.send(Constants.WS_SEND_START, jsonString)
                ?.subscribe(
                        { Log.d(TAG, "Start game message sent") },
                        { error ->
                            Log.e(TAG, "Error sending start game", error)
                            onError?.invoke("Failed to start game: ${error.message}")
                        }
                )
                ?.let { compositeDisposable.add(it) }
    }

    /** Send answer submission */
    fun sendAnswer(
            roomId: Long,
            roomCode: String,
            userId: String,
            questionIndex: Int,
            selectedOption: Int
    ) {
        if (!isConnected) {
            Log.e(TAG, "Cannot submit answer: Not connected to server")
            onError?.invoke("Cannot submit answer: Not connected to server")
            return
        }

        val answer = AnswerMessage(roomId, roomCode, userId, questionIndex, selectedOption)
        val jsonString = gson.toJson(answer)

        Log.d(TAG, "Sending answer: $jsonString")
        stompClient
                ?.send(Constants.WS_SEND_ANSWER, jsonString)
                ?.subscribe(
                        { Log.d(TAG, "Answer message sent") },
                        { error ->
                            Log.e(TAG, "Error sending answer", error)
                            onError?.invoke("Failed to submit answer: ${error.message}")
                        }
                )
                ?.let { compositeDisposable.add(it) }
    }

    /** Send leave game (player quit) */
    fun sendLeaveGame(roomId: Long, roomCode: String, userId: String) {
        if (!isConnected) {
            Log.e(TAG, "Cannot leave game: Not connected to server")
            onError?.invoke("Not connected to server")
            return
        }
        val request = LeaveGameRequest(roomId, roomCode, userId)
        val jsonString = gson.toJson(request)
        Log.d(TAG, "Sending leave game: $jsonString")
        stompClient
            ?.send(Constants.WS_SEND_LEAVE, jsonString)
            ?.subscribe(
                { Log.d(TAG, "Leave game message sent") },
                { error ->
                    Log.e(TAG, "Error sending leave game", error)
                    onError?.invoke("Failed to leave game: ${error.message}")
                }
            )
            ?.let { compositeDisposable.add(it) }
    }

    /** Disconnect and clean up */
    fun disconnect() {
        Log.d(TAG, "Disconnecting WebSocket")
        compositeDisposable.clear()
        stompClient?.disconnect()
        stompClient = null
        isConnected = false
        onConnectionChanged?.invoke(false)
    }

    companion object {
        private const val TAG = "WebSocketManager"
    }
}
