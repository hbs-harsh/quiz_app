package com.example.quizz_app.model

data class RoomCreateRequest(
    val quizSourceType: QuizSourceType,
    val topic: String? = null,
    val documentUrl: String? = null,
    val customPrompt: String? = null,
    val difficulty: String,
    val timerPerQuestion: Int = 30,
    /** Firebase UID of the user creating the room. */
    val userId: String? = null
)
