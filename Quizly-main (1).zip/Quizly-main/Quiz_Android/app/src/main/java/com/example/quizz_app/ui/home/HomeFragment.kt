package com.example.quizz_app.ui.home

import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.view.animation.DecelerateInterpolator
import android.view.animation.LinearInterpolator
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import com.example.quizz_app.QuizzActivity
import com.example.quizz_app.R
import com.example.quizz_app.remote.RetrofitClient
import com.google.android.material.card.MaterialCardView
import com.google.android.material.chip.ChipGroup
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.firebase.auth.FirebaseAuth
import kotlinx.coroutines.launch
import kotlin.math.cos
import kotlin.math.sin

class HomeFragment : Fragment(R.layout.fragment_home) {

    private val floatAnimators = mutableListOf<ValueAnimator>()

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val tvGreeting = view.findViewById<TextView>(R.id.tvGreeting)
        val tvPoints = view.findViewById<TextView>(R.id.tvPoints)
        val user = FirebaseAuth.getInstance().currentUser
        val displayName = user?.displayName?.takeIf { it.isNotBlank() } ?: "Quizzer"
        tvGreeting.text = getString(R.string.hello_username, displayName)

        lifecycleScope.launch {
            try {
                val uid = user?.uid
                val response = RetrofitClient.create(requireContext()).getLeaderboard(uid)
                val points = response.currentUser?.points ?: 0L
                tvPoints.text = getString(R.string.points_format, points.toInt())
            } catch (_: Exception) {
                tvPoints.text = getString(R.string.points_format, 0)
            }
        }

        // PLAY NOW -> 1v1 multiplayer
        view.findViewById<TextView>(R.id.btnPlayNow)?.setOnClickListener {
            startActivity(
                Intent(requireContext(), QuizzActivity::class.java).apply {
                    putExtra("QUIZ_MODE", "MULTIPLAYER_MENU")
                }
            )
        }

        // Custom Quiz – only START button navigates (not the whole card)
        view.findViewById<View>(R.id.btnCustomQuiz)?.setOnClickListener {
            findNavController().navigate(R.id.action_homeFragment_to_customQuizFragment)
        }

        val cardCbse = view.findViewById<MaterialCardView>(R.id.cardCbse)
        val cardNeet = view.findViewById<MaterialCardView>(R.id.cardNeet)
        val cardPhysics = view.findViewById<MaterialCardView>(R.id.cardPhysics)
        val cardChemistry = view.findViewById<MaterialCardView>(R.id.cardChemistry)
        val cardMath = view.findViewById<MaterialCardView>(R.id.cardMath)
        val cardHistory = view.findViewById<MaterialCardView>(R.id.cardHistory)
        val cardReasoning = view.findViewById<MaterialCardView>(R.id.cardReasoning)
        val cardCurrentAffairs = view.findViewById<MaterialCardView>(R.id.cardCurrentAffairs)
        val cardTechnology = view.findViewById<MaterialCardView>(R.id.cardTechnology)
        val cardGeography = view.findViewById<MaterialCardView>(R.id.cardGeography)
        val cardMoviesTv = view.findViewById<MaterialCardView>(R.id.cardMoviesTv)
        val cardSports = view.findViewById<MaterialCardView>(R.id.cardSports)

        val categoryCards = listOf(
            cardCbse to "General Knowledge",
            cardNeet to "NEET_UG",
            cardPhysics to "Physics",
            cardChemistry to "Chemistry",
            cardMath to "Mathematics",
            cardHistory to "History",
            cardReasoning to "Reasoning_Logic",
            cardCurrentAffairs to "Current_Affairs",
            cardTechnology to "Technology",
            cardGeography to "Geography",
            cardMoviesTv to "Movies",
            cardSports to "Sports"
        )
        categoryCards.forEach { (card, category) ->
            card?.setOnClickListener { showQuizConfigDialog(category) }
        }

        playEntryAnimations(view)
        startFloatingAnimations(view)
    }

    private fun startFloatingAnimations(view: View) {
        val blob1 = view.findViewById<View>(R.id.floatBlob1)
        val blob2 = view.findViewById<View>(R.id.floatBlob2)
        val blob3 = view.findViewById<View>(R.id.floatBlob3)
        startCircularFloat(blob1, radiusPx = 42f, durationMs = 13_000L, phaseDeg = 0f)
        startCircularFloat(blob2, radiusPx = 34f, durationMs = 15_000L, phaseDeg = 120f)
        startCircularFloat(blob3, radiusPx = 28f, durationMs = 11_000L, phaseDeg = 240f)
    }

    private fun startCircularFloat(
        view: View,
        radiusPx: Float,
        durationMs: Long,
        phaseDeg: Float
    ) {
        val phaseRad = Math.toRadians(phaseDeg.toDouble()).toFloat()
        ValueAnimator.ofFloat(0f, 360f).apply {
            duration = durationMs
            repeatCount = ValueAnimator.INFINITE
            repeatMode = ValueAnimator.RESTART
            interpolator = LinearInterpolator()
            addUpdateListener { anim ->
                val deg = (anim.animatedValue as Float) * (Math.PI / 180).toFloat()
                view.translationX = radiusPx * cos(deg + phaseRad)
                view.translationY = radiusPx * sin(deg + phaseRad)
            }
            floatAnimators.add(this)
            start()
        }
    }

    override fun onDestroyView() {
        floatAnimators.forEach { it.cancel() }
        floatAnimators.clear()
        super.onDestroyView()
    }

    private fun playEntryAnimations(view: View) {
        val promoCard = view.findViewById<View>(R.id.promoCard)
        val cards = listOfNotNull(
            promoCard,
            view.findViewById<MaterialCardView>(R.id.cardCbse),
            view.findViewById<MaterialCardView>(R.id.cardNeet),
            view.findViewById<MaterialCardView>(R.id.cardPhysics),
            view.findViewById<MaterialCardView>(R.id.cardChemistry),
            view.findViewById<MaterialCardView>(R.id.cardMath),
            view.findViewById<MaterialCardView>(R.id.cardHistory),
            view.findViewById<MaterialCardView>(R.id.cardReasoning),
            view.findViewById<MaterialCardView>(R.id.cardCurrentAffairs),
            view.findViewById<MaterialCardView>(R.id.cardTechnology),
            view.findViewById<MaterialCardView>(R.id.cardGeography),
            view.findViewById<MaterialCardView>(R.id.cardMoviesTv),
            view.findViewById<MaterialCardView>(R.id.cardSports)
        )
        cards.forEachIndexed { index, card ->
            card.alpha = 0f
            card.translationY = 20f
            ObjectAnimator.ofFloat(card, "alpha", 0f, 1f).apply {
                duration = 280
                startDelay = 80L * index
                interpolator = DecelerateInterpolator()
                start()
            }
            ObjectAnimator.ofFloat(card, "translationY", 20f, 0f).apply {
                duration = 280
                startDelay = 80L * index
                interpolator = DecelerateInterpolator()
                start()
            }
        }
    }

    private fun showQuizConfigDialog(category: String) {
        val dialogView = layoutInflater.inflate(R.layout.dialog_quiz_config, null)
        val chipGroupTimer = dialogView.findViewById<ChipGroup>(R.id.chipGroupTimer)
        val chipGroupQuestions = dialogView.findViewById<ChipGroup>(R.id.chipGroupQuestions)
        val chipGroupDifficulty = dialogView.findViewById<ChipGroup>(R.id.chipGroupDifficulty)

        MaterialAlertDialogBuilder(requireContext())
            .setTitle("Start Quiz")
            .setView(dialogView)
            .setNegativeButton("Cancel") { dialog, _ -> dialog.dismiss() }
            .setPositiveButton("Start") { _, _ ->
                val timerSeconds = when (chipGroupTimer.checkedChipId) {
                    R.id.chip15s -> 15
                    R.id.chip30s -> 30
                    R.id.chip45s -> 45
                    R.id.chip60s -> 60
                    else -> 30
                }
                val questionCount = when (chipGroupQuestions.checkedChipId) {
                    R.id.chip10q -> 10
                    R.id.chip20q -> 20
                    R.id.chip30q -> 30
                    R.id.chip40q -> 40
                    else -> 10
                }
                val difficulty = when (chipGroupDifficulty.checkedChipId) {
                    R.id.chipEasy -> "easy"
                    R.id.chipMedium -> "medium"
                    R.id.chipHard -> "hard"
                    else -> "medium"
                }
                startQuiz(category, timerSeconds, questionCount, difficulty)
            }
            .show()
    }

    private fun startQuiz(category: String, timerSeconds: Int, questionCount: Int, difficulty: String) {
        startActivity(
            Intent(requireContext(), QuizzActivity::class.java).apply {
                putExtra("QUIZ_MODE", "SINGLE_PLAYER")
                putExtra("category", category)
                putExtra("timerSeconds", timerSeconds)
                putExtra("questionCount", questionCount)
                putExtra("difficulty", difficulty)
            }
        )
    }
}
