package com.example.quizz_app.ui.leaderboard

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.quizz_app.R

data class LeaderboardEntry(
    val rank: Int,
    val displayName: String,
    val publicUserId: String? = null,
    val wins: Int,
    val points: Long = 0
)

class LeaderboardAdapter : ListAdapter<LeaderboardEntry, LeaderboardAdapter.ViewHolder>(DiffCallback) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_leaderboard, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val tvRank: TextView = itemView.findViewById(R.id.tvRank)
        private val tvPlayerName: TextView = itemView.findViewById(R.id.tvPlayerName)
        private val tvPlayerId: TextView = itemView.findViewById(R.id.tvPlayerId)
        private val tvPlayerScore: TextView = itemView.findViewById(R.id.tvPlayerScore)
        private val tvScore: TextView = itemView.findViewById(R.id.tvScore)

        fun bind(entry: LeaderboardEntry) {
            tvRank.text = when (entry.rank) {
                1 -> "🥇"
                2 -> "🥈"
                3 -> "🥉"
                else -> entry.rank.toString()
            }
            tvPlayerName.text = entry.displayName
            tvPlayerId.text = entry.publicUserId?.takeIf { it.isNotBlank() } ?: "—"
            tvPlayerId.visibility = View.VISIBLE
            tvPlayerScore.text = "${entry.wins} win${if (entry.wins == 1) "" else "s"} • ${entry.points} pts"
            tvScore.text = entry.wins.toString()
            tvPlayerName.setTextColor(
                ContextCompat.getColor(
                    itemView.context,
                    if (entry.rank <= 3) R.color.primary else R.color.mp_text_primary
                )
            )
        }
    }

    private object DiffCallback : DiffUtil.ItemCallback<LeaderboardEntry>() {
        override fun areItemsTheSame(a: LeaderboardEntry, b: LeaderboardEntry) = a.rank == b.rank
        override fun areContentsTheSame(a: LeaderboardEntry, b: LeaderboardEntry) = a == b
    }
}
