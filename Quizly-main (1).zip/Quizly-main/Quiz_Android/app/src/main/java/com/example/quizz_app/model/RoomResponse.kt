package com.example.quizz_app.model

data class RoomResponse(
    val roomId: Long,
    val roomCode: String,
    val status: RoomStatus,
    val assignedUserId: String? = null
)
