package com.example.quizz_app.repository

import android.content.Context
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.GoogleAuthProvider
import com.google.firebase.auth.UserProfileChangeRequest



class AuthRepository {




    private val auth = FirebaseAuth.getInstance()

    fun register(
        name: String,
        email: String,
        password: String,
        onSuccess: () -> Unit,
        onError: (String) -> Unit
    ) {
        val nameTrimmed = name.trim()
        val emailTrimmed = email.trim()
        when {
            nameTrimmed.isEmpty() -> {
                onError("Name is required")
                return
            }
            nameTrimmed.length > 50 -> {
                onError("Name must be at most 50 characters")
                return
            }
            emailTrimmed.isEmpty() -> {
                onError("Email is required")
                return
            }
            !android.util.Patterns.EMAIL_ADDRESS.matcher(emailTrimmed).matches() -> {
                onError("Enter a valid email address")
                return
            }
            password.isEmpty() -> {
                onError("Password is required")
                return
            }
            password.length < 6 -> {
                onError("Password must be at least 6 characters")
                return
            }
        }
        auth.createUserWithEmailAndPassword(emailTrimmed, password)
            .addOnSuccessListener {
                val user = auth.currentUser ?: run {
                    onSuccess()
                    return@addOnSuccessListener
                }
                val profileUpdates = UserProfileChangeRequest.Builder()
                    .setDisplayName(nameTrimmed)
                    .build()
                user.updateProfile(profileUpdates)
                    .addOnSuccessListener { onSuccess() }
                    .addOnFailureListener { e ->
                        onSuccess()
                    }
            }
            .addOnFailureListener {
                onError(it.message ?: "Registration failed")
            }
    }

    fun login(
        email: String,
        password: String,
        onSuccess: () -> Unit,
        onError: (String) -> Unit
    ) {
        auth.signInWithEmailAndPassword(email, password)
            .addOnSuccessListener { onSuccess() }
            .addOnFailureListener {
                onError(it.message ?: "Login failed")
            }
    }

    fun signInWithGoogle(
        idToken: String,
        onSuccess: () -> Unit,
        onError: (String) -> Unit
    ) {
        val credential = GoogleAuthProvider.getCredential(idToken, null)
        auth.signInWithCredential(credential)
            .addOnSuccessListener { onSuccess() }
            .addOnFailureListener {
                onError(it.message ?: "Google sign-in failed")
            }
    }
}


