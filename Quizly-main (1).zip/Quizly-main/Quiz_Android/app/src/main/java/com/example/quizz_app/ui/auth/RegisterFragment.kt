package com.example.quizz_app.ui.auth

import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.os.Bundle
import android.util.Patterns
import android.view.View
import android.view.animation.AccelerateDecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.core.view.isVisible
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import com.example.quizz_app.R
import com.example.quizz_app.model.AuthState
import com.google.android.material.button.MaterialButton
import com.google.android.material.textfield.TextInputLayout

class RegisterFragment : Fragment(R.layout.fragment_register) {

    private val viewModel: AuthViewModel by viewModels()

    private lateinit var tvLogo: TextView
    private lateinit var tvSubtitle: TextView
    private lateinit var nameInputLayout: TextInputLayout
    private lateinit var emailInputLayout: TextInputLayout
    private lateinit var passwordInputLayout: TextInputLayout
    private lateinit var confirmPasswordInputLayout: TextInputLayout
    private lateinit var registerBtn: MaterialButton
    private lateinit var loadingIndicator: ProgressBar
    private lateinit var goToLoginBtn: TextView

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        initViews(view)
        setupClickListeners()
        observeAuthState()
        playEntryAnimations()
    }

    private fun initViews(view: View) {
        tvLogo = view.findViewById(R.id.tvLogo)
        tvSubtitle = view.findViewById(R.id.tvSubtitle)
        nameInputLayout = view.findViewById(R.id.nameInputLayout)
        emailInputLayout = view.findViewById(R.id.emailInputLayout)
        passwordInputLayout = view.findViewById(R.id.passwordInputLayout)
        confirmPasswordInputLayout = view.findViewById(R.id.confirmPasswordInputLayout)
        registerBtn = view.findViewById(R.id.registerBtn)
        loadingIndicator = view.findViewById(R.id.loadingIndicator)
        goToLoginBtn = view.findViewById(R.id.goToLoginBtn)

        // Initially hide for animations
        tvLogo.alpha = 0f
        tvSubtitle.alpha = 0f
        nameInputLayout.alpha = 0f
        nameInputLayout.translationY = 50f
        emailInputLayout.alpha = 0f
        emailInputLayout.translationY = 50f
        passwordInputLayout.alpha = 0f
        passwordInputLayout.translationY = 50f
        confirmPasswordInputLayout.alpha = 0f
        confirmPasswordInputLayout.translationY = 50f
        registerBtn.alpha = 0f
        registerBtn.scaleX = 0.8f
        registerBtn.scaleY = 0.8f
    }

    private fun setupClickListeners() {
        registerBtn.setOnClickListener {
            animateButtonPress(it) {
                val name = nameInputLayout.editText?.text.toString().trim()
                val email = emailInputLayout.editText?.text.toString().trim()
                val password = passwordInputLayout.editText?.text.toString().trim()
                val confirmPassword = confirmPasswordInputLayout.editText?.text.toString().trim()

                if (validateInputs(name, email, password, confirmPassword)) {
                    viewModel.register(name, email, password)
                }
            }
        }

        goToLoginBtn.setOnClickListener { parentFragmentManager.popBackStack() }
    }

    private fun validateInputs(
            name: String,
            email: String,
            password: String,
            confirmPassword: String
    ): Boolean {
        var isValid = true

        // Name: required, 1–50 chars
        when {
            name.isEmpty() -> {
                nameInputLayout.error = "Name is required"
                isValid = false
            }
            name.length > 50 -> {
                nameInputLayout.error = "Name must be at most 50 characters"
                isValid = false
            }
            else -> nameInputLayout.error = null
        }

        // Email: required, valid format
        when {
            email.isEmpty() -> {
                emailInputLayout.error = "Email is required"
                isValid = false
            }
            !Patterns.EMAIL_ADDRESS.matcher(email).matches() -> {
                emailInputLayout.error = "Enter a valid email address"
                isValid = false
            }
            else -> emailInputLayout.error = null
        }

        // Password: required, min 6 chars
        when {
            password.isEmpty() -> {
                passwordInputLayout.error = "Password is required"
                isValid = false
            }
            password.length < 6 -> {
                passwordInputLayout.error = "Password must be at least 6 characters"
                isValid = false
            }
            else -> passwordInputLayout.error = null
        }

        // Confirm password: required, must match
        when {
            confirmPassword.isEmpty() -> {
                confirmPasswordInputLayout.error = "Confirm password is required"
                isValid = false
            }
            password != confirmPassword -> {
                confirmPasswordInputLayout.error = "Passwords don't match"
                isValid = false
            }
            else -> confirmPasswordInputLayout.error = null
        }

        return isValid
    }

    private fun playEntryAnimations() {
        // Logo animation
        ObjectAnimator.ofFloat(tvLogo, "alpha", 0f, 1f).apply {
            duration = 500
            interpolator = AccelerateDecelerateInterpolator()
            start()
        }

        ObjectAnimator.ofFloat(tvLogo, "scaleX", 0.8f, 1.05f, 1f).apply {
            duration = 600
            interpolator = OvershootInterpolator()
            start()
        }

        ObjectAnimator.ofFloat(tvLogo, "scaleY", 0.8f, 1.05f, 1f).apply {
            duration = 600
            interpolator = OvershootInterpolator()
            start()
        }

        // Subtitle
        ObjectAnimator.ofFloat(tvSubtitle, "alpha", 0f, 1f).apply {
            duration = 500
            startDelay = 200
            start()
        }

        // Input fields (stagger)
        animateEntryView(nameInputLayout, 300)
        animateEntryView(emailInputLayout, 380)
        animateEntryView(passwordInputLayout, 460)
        animateEntryView(confirmPasswordInputLayout, 540)

        // Button bounce in
        AnimatorSet().apply {
            playTogether(
                    ObjectAnimator.ofFloat(registerBtn, "alpha", 0f, 1f),
                    ObjectAnimator.ofFloat(registerBtn, "scaleX", 0.8f, 1f),
                    ObjectAnimator.ofFloat(registerBtn, "scaleY", 0.8f, 1f)
            )
            duration = 400
            startDelay = 620
            interpolator = OvershootInterpolator()
            start()
        }
    }

    private fun animateEntryView(view: View, delay: Long) {
        AnimatorSet().apply {
            playTogether(
                    ObjectAnimator.ofFloat(view, "alpha", 0f, 1f),
                    ObjectAnimator.ofFloat(view, "translationY", 50f, 0f)
            )
            duration = 400
            startDelay = delay
            interpolator = AccelerateDecelerateInterpolator()
            start()
        }
    }

    private fun animateButtonPress(view: View, action: () -> Unit) {
        AnimatorSet().apply {
            playSequentially(
                    AnimatorSet().apply {
                        playTogether(
                                ObjectAnimator.ofFloat(view, "scaleX", 1f, 0.95f),
                                ObjectAnimator.ofFloat(view, "scaleY", 1f, 0.95f)
                        )
                        duration = 100
                    },
                    AnimatorSet().apply {
                        playTogether(
                                ObjectAnimator.ofFloat(view, "scaleX", 0.95f, 1f),
                                ObjectAnimator.ofFloat(view, "scaleY", 0.95f, 1f)
                        )
                        duration = 100
                    }
            )
            start()
        }

        view.postDelayed({ action() }, 150)
    }

    private fun observeAuthState() {
        viewModel.authState.observe(viewLifecycleOwner) { state ->
            when (state) {
                is AuthState.Loading -> {
                    registerBtn.isEnabled = false
                    loadingIndicator.isVisible = true
                }
                is AuthState.Success -> {
                    loadingIndicator.isVisible = false
                    Toast.makeText(
                                    requireContext(),
                                    "Account created! Please login.",
                                    Toast.LENGTH_SHORT
                            )
                            .show()
                    parentFragmentManager.popBackStack()
                }
                is AuthState.Error -> {
                    registerBtn.isEnabled = true
                    loadingIndicator.isVisible = false
                    Toast.makeText(requireContext(), state.message, Toast.LENGTH_SHORT).show()
                }
                else -> Unit
            }
        }
    }
}
