package com.example.quizz_app.remote

import com.example.quizz_app.utils.SessionManager
import com.google.firebase.auth.FirebaseAuth
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.suspendCancellableCoroutine
import okhttp3.Interceptor
import okhttp3.Response
import kotlin.coroutines.resume

class AuthInterceptor(
    private val sessionManager: SessionManager
) : Interceptor {

    override fun intercept(chain: Interceptor.Chain): Response {
        val token = getValidToken()

        val request = chain.request().newBuilder().apply {
            if (!token.isNullOrBlank()) {
                header("Authorization", "Bearer $token")
            }
        }.build()

        return chain.proceed(request)
    }

    /**
     * Prefer a fresh Firebase ID token (avoids 401 when stored token is expired).
     * Falls back to stored token if Firebase user is not available.
     */
    private fun getValidToken(): String? {
        val user = FirebaseAuth.getInstance().currentUser ?: return sessionManager.getFirebaseToken()
        return runBlocking {
            suspendCancellableCoroutine { cont ->
                user.getIdToken(true)
                    .addOnCompleteListener { task ->
                        if (task.isSuccessful) {
                            val t = task.result?.token
                            if (!t.isNullOrBlank()) {
                                sessionManager.saveFirebaseToken(t)
                            }
                            cont.resume(t)
                        } else {
                            cont.resume(sessionManager.getFirebaseToken())
                        }
                    }
            }
        }
    }
}