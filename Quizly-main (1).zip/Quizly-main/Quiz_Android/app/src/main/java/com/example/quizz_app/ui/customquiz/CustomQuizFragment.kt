package com.example.quizz_app.ui.customquiz

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.example.quizz_app.QuizzActivity
import com.example.quizz_app.R
import com.example.quizz_app.utils.PendingQuizHolder
import com.google.android.material.button.MaterialButton
import com.google.android.material.chip.ChipGroup
import com.google.android.material.dialog.MaterialAlertDialogBuilder

/**
 * Custom Quiz (solo): by topic or from PDF.
 * Reuses quiz config dialog and QuizzActivity single-player flow.
 */
class CustomQuizFragment : Fragment(R.layout.fragment_custom_quiz) {

    private val pdfPicker = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            uploadPdfAndStartQuiz(uri)
        }
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        view.findViewById<MaterialButton>(R.id.btnByTopic).setOnClickListener {
            showTopicConfigDialog()
        }

        view.findViewById<MaterialButton>(R.id.btnFromPdf).setOnClickListener {
            pdfPicker.launch(arrayOf("application/pdf"))
        }
    }

    private fun showTopicConfigDialog() {
        val dialogView = layoutInflater.inflate(R.layout.dialog_custom_quiz_config, null)
        val chipGroupTopic = dialogView.findViewById<ChipGroup>(R.id.chipGroupTopic)
        val chipGroupTimer = dialogView.findViewById<ChipGroup>(R.id.chipGroupTimer)
        val chipGroupQuestions = dialogView.findViewById<ChipGroup>(R.id.chipGroupQuestions)
        val chipGroupDifficulty = dialogView.findViewById<ChipGroup>(R.id.chipGroupDifficulty)

        MaterialAlertDialogBuilder(requireContext())
            .setTitle("Custom quiz – by topic")
            .setView(dialogView)
            .setNegativeButton("Cancel") { dialog, _ -> dialog.dismiss() }
            .setPositiveButton("Start") { _, _ ->
                val category = when (chipGroupTopic.checkedChipId) {
                    R.id.chipCatPhysics -> "Physics"
                    R.id.chipCatChemistry -> "Chemistry"
                    R.id.chipCatMath -> "Mathematics"
                    R.id.chipCatHistory -> "History"
                    R.id.chipCatNeet -> "NEET_UG"
                    R.id.chipCatReasoning -> "Reasoning_Logic"
                    R.id.chipCatCurrentAffairs -> "Current_Affairs"
                    R.id.chipCatTechnology -> "Technology"
                    R.id.chipCatGeography -> "Geography"
                    R.id.chipCatMoviesTv -> "Movies"
                    R.id.chipCatSports -> "Sports"
                    else -> "General Knowledge"
                }
                val timerSeconds = when (chipGroupTimer.checkedChipId) {
                    R.id.chip15s -> 15
                    R.id.chip30s -> 30
                    R.id.chip45s -> 45
                    R.id.chip60s -> 60
                    else -> 30
                }
                val questionCount = when (chipGroupQuestions.checkedChipId) {
                    R.id.chip10q -> 10
                    R.id.chip20q -> 20
                    R.id.chip30q -> 30
                    R.id.chip40q -> 40
                    else -> 10
                }
                val difficulty = when (chipGroupDifficulty.checkedChipId) {
                    R.id.chipEasy -> "easy"
                    R.id.chipMedium -> "medium"
                    R.id.chipHard -> "hard"
                    else -> "medium"
                }
                startSoloQuiz(category, timerSeconds, questionCount, difficulty)
            }
            .show()
    }

    private fun startSoloQuiz(category: String, timerSeconds: Int, questionCount: Int, difficulty: String) {
        startActivity(
            Intent(requireContext(), QuizzActivity::class.java).apply {
                putExtra("QUIZ_MODE", "SINGLE_PLAYER")
                putExtra("category", category)
                putExtra("timerSeconds", timerSeconds)
                putExtra("questionCount", questionCount)
                putExtra("difficulty", difficulty)
            }
        )
    }

    private fun uploadPdfAndStartQuiz(uri: Uri) {
        val btnFromPdf = view?.findViewById<MaterialButton>(R.id.btnFromPdf)
        val progress = view?.findViewById<View>(R.id.pdfProgress)
        btnFromPdf?.isEnabled = false
        progress?.visibility = View.VISIBLE

        val vm = androidx.lifecycle.ViewModelProvider(this)[CustomQuizViewModel::class.java]
        vm.uploadPdfAndGetQuiz(requireContext(), uri) { result ->
            btnFromPdf?.isEnabled = true
            progress?.visibility = View.GONE
            result.fold(
                onSuccess = { (quizResponse, timerSeconds) ->
                    PendingQuizHolder.set(quizResponse, timerSeconds)
                    startActivity(
                        Intent(requireContext(), QuizzActivity::class.java).apply {
                            putExtra("QUIZ_MODE", "SINGLE_PLAYER")
                            putExtra("USE_PENDING_QUIZ", true)
                            putExtra("timerSeconds", timerSeconds)
                        }
                    )
                },
                onFailure = {
                    Toast.makeText(requireContext(), it.message ?: "Upload failed", Toast.LENGTH_LONG).show()
                }
            )
        }
    }
}
