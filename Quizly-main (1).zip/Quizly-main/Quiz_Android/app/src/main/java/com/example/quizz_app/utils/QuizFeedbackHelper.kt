package com.example.quizz_app.utils

import android.content.Context
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.view.HapticFeedbackConstants
import android.view.View

/**
 * Sound and haptics for quiz feedback (correct/wrong, tap).
 * Uses ToneGenerator for simple tones (no raw assets) and system haptics.
 */
object QuizFeedbackHelper {

    private const val TONE_DURATION_MS = 120
    private const val VIBRATE_MS_CORRECT = 30L
    private const val VIBRATE_MS_WRONG = 50L

    private var toneGenerator: ToneGenerator? = null

    fun init(context: Context) {
        release()
        try {
            toneGenerator = ToneGenerator(AudioManager.STREAM_MUSIC, 70)
        } catch (e: Exception) {
            toneGenerator = null
        }
    }

    fun release() {
        try {
            toneGenerator?.release()
        } catch (_: Exception) { }
        toneGenerator = null
    }

    /** Light haptic when user taps an option */
    fun tapHaptic(view: View?) {
        view?.performHapticFeedback(
            HapticFeedbackConstants.CLOCK_TICK,
            HapticFeedbackConstants.FLAG_IGNORE_GLOBAL_SETTING
        )
    }

    /** Sound + haptic for correct answer */
    fun playCorrect(view: View?) {
        tapHaptic(view)
        view?.performHapticFeedback(
            HapticFeedbackConstants.CONFIRM,
            HapticFeedbackConstants.FLAG_IGNORE_GLOBAL_SETTING
        )
        try {
            toneGenerator?.startTone(ToneGenerator.TONE_PROP_ACK, TONE_DURATION_MS)
        } catch (_: Exception) { }
        vibrate(view?.context, VIBRATE_MS_CORRECT)
    }

    /** Sound + haptic for wrong answer */
    fun playWrong(view: View?) {
        tapHaptic(view)
        view?.performHapticFeedback(
            HapticFeedbackConstants.REJECT,
            HapticFeedbackConstants.FLAG_IGNORE_GLOBAL_SETTING
        )
        try {
            toneGenerator?.startTone(ToneGenerator.TONE_CDMA_SOFT_ERROR_LITE, TONE_DURATION_MS)
        } catch (_: Exception) { }
        vibrate(view?.context, VIBRATE_MS_WRONG)
    }

    private fun vibrate(context: Context?, durationMs: Long) {
        if (context == null) return
        val vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            (context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager)?.defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
        } ?: return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            vibrator.vibrate(VibrationEffect.createOneShot(durationMs, VibrationEffect.DEFAULT_AMPLITUDE))
        } else {
            @Suppress("DEPRECATION")
            vibrator.vibrate(durationMs)
        }
    }
}
