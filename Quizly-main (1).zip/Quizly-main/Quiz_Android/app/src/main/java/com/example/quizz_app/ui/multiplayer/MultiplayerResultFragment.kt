package com.example.quizz_app.ui.multiplayer

import android.animation.ObjectAnimator
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import com.bumptech.glide.Glide
import com.example.quizz_app.R

/** Multiplayer result fragment - Show winner and final scores with enhanced UI */
class MultiplayerResultFragment : Fragment(R.layout.fragment_multiplayer_result) {

    private val viewModel: MultiplayerViewModel by activityViewModels()

    private lateinit var resultBackground: ConstraintLayout
    private lateinit var tvResultTitle: TextView
    private lateinit var tvMyName: TextView
    private lateinit var tvOpponentName: TextView
    private lateinit var tvMyFinalScore: TextView
    private lateinit var tvOpponentFinalScore: TextView
    private lateinit var btnPlayAgain: Button
    private lateinit var btnExit: Button
    private lateinit var ivTrophy: ImageView
    private lateinit var ivYouLose: ImageView
    private lateinit var confettiView: ImageView

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        resultBackground = view.findViewById(R.id.resultBackground)
        tvResultTitle = view.findViewById(R.id.tvResultTitle)
        tvMyName = view.findViewById(R.id.tvMyName)
        tvOpponentName = view.findViewById(R.id.tvOpponentName)
        tvMyFinalScore = view.findViewById(R.id.tvMyFinalScore)
        tvOpponentFinalScore = view.findViewById(R.id.tvOpponentFinalScore)
        btnPlayAgain = view.findViewById(R.id.btnPlayAgain)
        btnExit = view.findViewById(R.id.btnExit)
        ivTrophy = view.findViewById(R.id.ivTrophy)
        ivYouLose = view.findViewById(R.id.ivYouLose)
        confettiView = view.findViewById(R.id.confettiView)

        setupClickListeners()
        displayResults()
    }

    private fun setupClickListeners() {
        btnPlayAgain.setOnClickListener {
            viewModel.reset()
            // Finish QuizActivity and return to MainActivity2 multiplayer menu
            requireActivity().finish()
        }

        btnExit.setOnClickListener {
            viewModel.reset()
            // Finish QuizActivity and return to MainActivity2 home
            requireActivity().finish()
        }
    }

    private fun displayResults() {
        val gameOverData = viewModel.getGameOver() ?: return
        val myUserId = viewModel.getUserId() ?: return

        val myScore = gameOverData.finalScores[myUserId] ?: 0
        val opponentScore =
                gameOverData.finalScores.filterKeys { it != myUserId }.values.firstOrNull() ?: 0

        tvMyFinalScore.text = myScore.toString()
        tvOpponentFinalScore.text = opponentScore.toString()
        tvMyName.text = viewModel.getMyDisplayName()
        tvOpponentName.text = viewModel.getOpponentDisplayName()

        // Determine result and update UI
        val isWin = when {
            gameOverData.isDraw -> {
                tvResultTitle.text = "🤝 It's a Draw!"
                resultBackground.setBackgroundResource(R.drawable.bg_gradient_purple)
                true
            }
            gameOverData.opponentLeft && gameOverData.winnerId == myUserId -> {
                tvResultTitle.text = "🏆 You Win!\nOpponent left the game."
                resultBackground.setBackgroundResource(R.drawable.bg_gradient_gold)
                true
            }
            gameOverData.winnerId == myUserId -> {
                tvResultTitle.text = "🏆 Victory!"
                resultBackground.setBackgroundResource(R.drawable.bg_gradient_gold)
                true
            }
            else -> {
                tvResultTitle.text = "😔 You Lost"
                resultBackground.setBackgroundResource(R.drawable.bg_gradient_orange)
                false
            }
        }

        if (isWin) {
            ivTrophy.visibility = View.VISIBLE
            ivYouLose.visibility = View.GONE
            Glide.with(requireContext()).asGif().load(R.drawable.trophy).into(ivTrophy)
            loadConfettiAndAnimateFromBottom(confettiView)
        } else {
            ivTrophy.visibility = View.GONE
            ivYouLose.visibility = View.VISIBLE
            confettiView.visibility = View.GONE
            Glide.with(requireContext()).asGif().load(R.drawable.youlose).into(ivYouLose)
        }
    }

    private fun loadConfettiAndAnimateFromBottom(confettiView: ImageView) {
        confettiView.visibility = View.VISIBLE
        Glide.with(requireContext())
            .asGif()
            .load(R.drawable.confetti)
            .into(confettiView)
        confettiView.post {
            val fromY = requireView().height.toFloat()
            confettiView.translationY = fromY
            ObjectAnimator.ofFloat(confettiView, View.TRANSLATION_Y, fromY, 0f).apply {
                duration = 2200
                start()
            }
        }
    }
}
