package com.example.quizz_app.model

enum class QuizSourceType {
    TOPIC,
    DOCUMENT,
    CUSTOM
}
