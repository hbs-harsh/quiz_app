package com.example.quizz_app.ui.multiplayer

import android.app.Application
import android.os.Handler
import android.os.Looper
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.example.quizz_app.model.*
import com.example.quizz_app.repository.MultiplayerRepository
import com.example.quizz_app.utils.Constants
import com.example.quizz_app.utils.SessionManager
import kotlinx.coroutines.launch

/** ViewModel for managing multiplayer quiz state */
class MultiplayerViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = MultiplayerRepository(application)

    // Room state
    private val _roomCode = MutableLiveData<String>()
    val roomCode: LiveData<String> = _roomCode

    private val _roomId = MutableLiveData<Long>()
    val roomId: LiveData<Long> = _roomId

    private val _roomStatus = MutableLiveData<RoomStatus>()
    val roomStatus: LiveData<RoomStatus> = _roomStatus

    // WebSocket connection
    private val _isConnected = MutableLiveData<Boolean>(false)
    val isConnected: LiveData<Boolean> = _isConnected

    // Game state
    private val _currentQuestion = MutableLiveData<NextQuestionPayload>()
    val currentQuestion: LiveData<NextQuestionPayload> = _currentQuestion

    private val _answerResults = MutableLiveData<AnswerResultPayload>()
    val answerResults: LiveData<AnswerResultPayload> = _answerResults

    private val _gameOver = MutableLiveData<GameCompletedPayload>()
    val gameOver: LiveData<GameCompletedPayload> = _gameOver

    // Scores tracking
    private val _myScore = MutableLiveData<Int>(0)
    val myScore: LiveData<Int> = _myScore

    private val _opponentScore = MutableLiveData<Int>(0)
    val opponentScore: LiveData<Int> = _opponentScore

    // User ID (temporary for testing)
    private val _userId = MutableLiveData<String>()
    val userId: LiveData<String> = _userId

    // UI states
    private val _isLoading = MutableLiveData<Boolean>(false)
    val isLoading: LiveData<Boolean> = _isLoading

    private val _errorMessage = MutableLiveData<String?>()
    val errorMessage: LiveData<String?> = _errorMessage

    // Waiting for opponent answer
    private val _waitingForOpponent = MutableLiveData<Boolean>(false)
    val waitingForOpponent: LiveData<Boolean> = _waitingForOpponent
    
    // Track if current user has answered
    private val _hasAnsweredCurrentQuestion = MutableLiveData<Boolean>(false)
    val hasAnsweredCurrentQuestion: LiveData<Boolean> = _hasAnsweredCurrentQuestion
    
    // Track opponent's answer status
    private val _opponentAnswered = MutableLiveData<Boolean>(false)
    val opponentAnswered: LiveData<Boolean> = _opponentAnswered
    
    // Track answer results for current question
    private val _myAnswerResult = MutableLiveData<AnswerResultPayload?>()
    val myAnswerResult: LiveData<AnswerResultPayload?> = _myAnswerResult
    
    private val _opponentAnswerResult = MutableLiveData<AnswerResultPayload?>()
    val opponentAnswerResult: LiveData<AnswerResultPayload?> = _opponentAnswerResult

    init {
        setupWebSocketCallbacks()
    }

    private fun setupWebSocketCallbacks() {
        repository.onConnectionChanged = { connected ->
            _isConnected.postValue(connected)
            Log.d(TAG, "Connection status: $connected")
        }

        repository.onStartQuestion = { payload ->
            Log.d(TAG, "Start question: Q${payload.questionIndex}")
            Log.d(TAG, "Question text: ${payload.question}")
            Log.d(TAG, "Options count: ${payload.options.size}")
            Log.d(TAG, "Options: ${payload.options}")
            // Reset answer states for new question
            _hasAnsweredCurrentQuestion.postValue(false)
            _opponentAnswered.postValue(false)
            _myAnswerResult.postValue(null)
            _opponentAnswerResult.postValue(null)
            _waitingForOpponent.postValue(false)
            _currentQuestion.postValue(payload)
        }

        repository.onNextQuestion = { payload ->
            Log.d(TAG, "Next question: Q${payload.questionIndex}")
            Log.d(TAG, "Question text: ${payload.question}")
            Log.d(TAG, "Options count: ${payload.options.size}")
            Log.d(TAG, "Options: ${payload.options}")
            // Reset answer states for new question
            _hasAnsweredCurrentQuestion.postValue(false)
            _opponentAnswered.postValue(false)
            _myAnswerResult.postValue(null)
            _opponentAnswerResult.postValue(null)
            _waitingForOpponent.postValue(false)
            _currentQuestion.postValue(payload)
        }

        repository.onAnswerResult = { payload ->
            Log.d(TAG, "Answer result: User=${payload.userId}, Question=${payload.questionIndex}, Option=${payload.selectedOption}, Correct=${payload.correct}")
            _answerResults.postValue(payload)

            // Track who answered
            if (payload.userId == _userId.value) {
                // My answer
                _myAnswerResult.postValue(payload)
                _hasAnsweredCurrentQuestion.postValue(true)
                // Check if opponent has also answered
                if (_opponentAnswered.value == true) {
                    // Both answered, waiting for NEXT_QUESTION
                    _waitingForOpponent.postValue(false)
                } else {
                    // Waiting for opponent
                    _waitingForOpponent.postValue(true)
                }
                
                // Update score
                if (payload.correct) {
                    _myScore.postValue((_myScore.value ?: 0) + 1)
                }
            } else {
                // Opponent's answer
                _opponentAnswerResult.postValue(payload)
                _opponentAnswered.postValue(true)
                // Check if I have also answered
                if (_hasAnsweredCurrentQuestion.value == true) {
                    // Both answered, waiting for NEXT_QUESTION
                    _waitingForOpponent.postValue(false)
                } else {
                    // Opponent answered first, but I haven't yet
                    _waitingForOpponent.postValue(false) // Don't show waiting overlay if I haven't answered
                }
                
                // Update score
                if (payload.correct) {
                    _opponentScore.postValue((_opponentScore.value ?: 0) + 1)
                }
            }
        }

        repository.onGameOver = { payload ->
            Log.d(TAG, "Game over received! OpponentLeft: ${payload.opponentLeft}")
            Log.d(TAG, "Final scores: ${payload.finalScores}, Winner: ${payload.winnerId}")
            // Ensure we update LiveData on main thread (WebSocket may call from background thread)
            Handler(Looper.getMainLooper()).post {
                _gameOver.value = payload
                _waitingForOpponent.value = false
                _currentQuestion.value = null
            }
        }

        repository.onError = { error ->
            Log.e(TAG, "WebSocket error: $error")
            _errorMessage.postValue(error)
        }

        repository.onPlayerJoined = { roomStatus ->
            Log.d(TAG, "Player joined! Room status: $roomStatus")
            if (roomStatus == "READY") {
                _roomStatus.postValue(RoomStatus.READY)
            }
        }
    }

    /** Create a new room */
    fun createRoom(
            quizSourceType: QuizSourceType = QuizSourceType.TOPIC,
            topic: String? = "History",
            difficulty: String = "Medium",
            timerPerQuestion: Int = 30
    ) {
        viewModelScope.launch {
            _isLoading.value = true
            _errorMessage.value = null

            val uid = SessionManager(getApplication()).getUserId() ?: Constants.TEMP_USER_ID_1
            val request =
                    RoomCreateRequest(
                            quizSourceType = quizSourceType,
                            topic = topic,
                            difficulty = difficulty,
                            timerPerQuestion = timerPerQuestion,
                            userId = uid
                    )

            val result = repository.createRoom(request)
            _isLoading.value = false

            result
                    .onSuccess { response ->
                        _roomCode.value = response.roomCode
                        _roomStatus.value = response.status
                        _roomId.value = response.roomId
                        // Use assignedUserId from server (may differ from request)
                        _userId.value = response.assignedUserId ?: uid

                        // Connect to WebSocket and subscribe
                        connectAndSubscribe(response.roomCode)
                    }
                    .onFailure { error ->
                        _errorMessage.value = "Failed to create room: ${error.message}"
                    }
        }
    }

    /** Join an existing room */
    fun joinRoom(roomCode: String) {
        viewModelScope.launch {
            _isLoading.value = true
            _errorMessage.value = null

            val uid = SessionManager(getApplication()).getUserId() ?: Constants.TEMP_USER_ID_2
            val result = repository.joinRoom(roomCode, uid)
            _isLoading.value = false

            result
                    .onSuccess { response ->
                        _roomCode.value = response.roomCode
                        _roomStatus.value = response.status
                        _roomId.value = response.roomId
                        // Use assignedUserId from server (may be userId_2 if same user joins twice)
                        _userId.value = response.assignedUserId ?: uid

                        // Connect to WebSocket and subscribe
                        connectAndSubscribe(response.roomCode)
                    }
                    .onFailure { error ->
                        _errorMessage.value = "Failed to join room: ${error.message}"
                    }
        }
    }

    private fun connectAndSubscribe(roomCode: String) {
        repository.connectWebSocket()
        repository.subscribeToRoom(roomCode)
    }
    
    /** Reconnect WebSocket and re-subscribe (for when moving to new Activity) */
    fun reconnectWebSocket(roomCode: String) {
        Log.d(TAG, "Reconnecting WebSocket for room: $roomCode")
        connectAndSubscribe(roomCode)
    }
    
    /** Set room info (for when resuming in new Activity) */
    fun setRoomInfo(roomCode: String, roomId: Long, userId: String? = null) {
        Log.d(TAG, "Setting room info - Code: $roomCode, Id: $roomId, UserId: $userId")
        _roomCode.value = roomCode
        _roomId.value = roomId
        // Set user ID (use provided or default)
        _userId.value = userId ?: Constants.TEMP_USER_ID_1
    }
    
    /** Set question from Intent (backup when transitioning between Activities) */
    fun setQuestionFromIntent(questionIndex: Int, question: String, options: List<String>) {
        Log.d(TAG, "Setting question from Intent - Index: $questionIndex, Question: $question, Options: $options")
        val payload = NextQuestionPayload(questionIndex, question, options)
        _currentQuestion.value = payload
    }

    /** Start the game (host only) */
    fun startGame() {
        val roomId = _roomId.value ?: return
        val roomCode = _roomCode.value ?: return

        Log.d(TAG, "Starting game for room $roomId")
        repository.startGame(roomId, roomCode)
    }

    /** Leave game (quit) - other player will win */
    fun leaveGame() {
        val roomId = _roomId.value ?: return
        val roomCode = _roomCode.value ?: return
        val userId = _userId.value ?: return
        Log.d(TAG, "Leaving game - RoomId: $roomId")
        repository.leaveGame(roomId, roomCode, userId)
    }

    /** Called when per-question timer expires (no answer submitted) */
    fun markAnsweredByTimer() {
        _hasAnsweredCurrentQuestion.postValue(true)
    }

    /** Submit an answer */
    fun submitAnswer(questionIndex: Int, selectedOption: Int) {
        val roomId = _roomId.value ?: return
        val roomCode = _roomCode.value ?: return
        val userId = _userId.value ?: return

        Log.d(TAG, "Submitting answer: Q$questionIndex, Option $selectedOption")
        
        // Mark as answered immediately (UI feedback)
        _hasAnsweredCurrentQuestion.value = true
        
        repository.submitAnswer(roomId, roomCode, userId, questionIndex, selectedOption)

        // Show waiting state if opponent hasn't answered yet
        if (_opponentAnswered.value != true) {
            _waitingForOpponent.value = true
        }
    }

    fun clearCurrentQuestion() {
        _currentQuestion.value = null
    }

    /** Getters for use in fragments (LiveData.value is not accessible from outside ViewModel) */
    fun getRoomCode(): String? = _roomCode.value
    fun getRoomId(): Long? = _roomId.value
    fun getUserId(): String? = _userId.value
    fun getGameOver(): GameCompletedPayload? = _gameOver.value
    fun getCurrentQuestion(): NextQuestionPayload? = _currentQuestion.value

    /** My display name for multiplayer UI (from game-over payload or fallback). */
    fun getMyDisplayName(): String {
        val payload = _gameOver.value ?: return "You"
        val myId = _userId.value ?: return "You"
        return payload.playerDisplayNames?.get(myId)?.takeIf { it.isNotBlank() } ?: "You"
    }

    /** Opponent display name for multiplayer UI (from game-over payload or fallback). */
    fun getOpponentDisplayName(): String {
        val payload = _gameOver.value ?: return "Opponent"
        val myId = _userId.value ?: return "Opponent"
        val opponentId = payload.finalScores.keys.firstOrNull { it != myId } ?: return "Opponent"
        return payload.playerDisplayNames?.get(opponentId)?.takeIf { it.isNotBlank() } ?: "Opponent"
    }

    /** Reset for new game */
    fun reset() {
        repository.disconnectWebSocket()
        _roomCode.value = null
        _roomId.value = null
        _roomStatus.value = null
        _currentQuestion.value = null
        _gameOver.value = null
        _userId.value = null
        _myScore.value = 0
        _opponentScore.value = 0
        _waitingForOpponent.value = false
        _hasAnsweredCurrentQuestion.value = false
        _opponentAnswered.value = false
        _myAnswerResult.value = null
        _opponentAnswerResult.value = null
        _errorMessage.value = null
        _isConnected.value = false
    }

    override fun onCleared() {
        super.onCleared()
        repository.disconnectWebSocket()
    }

    companion object {
        private const val TAG = "MultiplayerViewModel"
    }
}
