package com.example.quizz_app.model

data class RoomJoinRequest(
    val roomCode: String,
    /** Firebase UID of the user joining. */
    val userId: String? = null
)
