package com.example.quizz_app.model

data class StartGameRequest(
    val roomId: Long,
    val roomCode: String
)
