package com.example.quizz_app

import android.os.Bundle
import android.util.Log
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.fragment.NavHostFragment
import com.example.quizz_app.ui.multiplayer.MultiplayerViewModel

class QuizzActivity : AppCompatActivity() {

    private lateinit var multiplayerViewModel: MultiplayerViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_quizz)

        val navHostFragment =
                supportFragmentManager.findFragmentById(R.id.quiz_nav_host) as NavHostFragment
        val navController = navHostFragment.navController

        // Back press handling
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                val currentId = navController.currentDestination?.id
                when (currentId) {
                    R.id.multiplayerQuizFragment -> {
                        showExitGameDialog()
                    }
                    R.id.multiplayerMenuFragment -> {
                        // From multiplayer menu, go back to home (finish activity)
                        finish()
                    }
                    R.id.quizLoadingFragment, R.id.quizFragment -> {
                        // From single player quiz, finish activity
                        finish()
                    }
                    else -> {
                        if (!navController.navigateUp()) {
                            finish()
                        }
                    }
                }
            }
        })

        // Get quiz mode from intent
        val quizMode = intent.getStringExtra("QUIZ_MODE") ?: "SINGLE_PLAYER"

        // Navigate to appropriate start destination based on mode
        when (quizMode) {
            "SINGLE_PLAYER" -> {
                // Already starts at quizLoadingFragment (default)
                // Fragment will read intent extras for topic, difficulty, etc.
            }
            "MULTIPLAYER_MENU" -> {
                // Multiplayer flow: menu -> waiting room -> quiz -> result (all in this activity)
                val navOptions = androidx.navigation.NavOptions.Builder()
                    .setPopUpTo(com.example.quizz_app.R.id.quizLoadingFragment, true)
                    .build()
                navController.navigate(com.example.quizz_app.R.id.multiplayerMenuFragment, null, navOptions)
            }
            "MULTIPLAYER" -> {
                // Get room info from intent
                val roomCode = intent.getStringExtra("ROOM_CODE")
                val roomId = intent.getLongExtra("ROOM_ID", -1L)
                val userId = intent.getStringExtra("USER_ID")
                
                // Get question data from intent (backup in case WebSocket hasn't delivered yet)
                val questionIndex = intent.getIntExtra("QUESTION_INDEX", -1)
                val questionText = intent.getStringExtra("QUESTION_TEXT")
                val questionOptions = intent.getStringArrayExtra("QUESTION_OPTIONS")
                
                Log.d("QuizzActivity", "Multiplayer mode - RoomCode: $roomCode, RoomId: $roomId, UserId: $userId")
                
                // Initialize ViewModel and reconnect WebSocket
                multiplayerViewModel = ViewModelProvider(this)[MultiplayerViewModel::class.java]
                
                // Set room info in ViewModel
                if (roomCode != null && roomId != -1L) {
                    multiplayerViewModel.setRoomInfo(roomCode, roomId, userId)
                    
                    // If question data was passed, set it immediately
                    if (questionIndex != -1 && questionText != null && questionOptions != null) {
                        Log.d("QuizzActivity", "Setting question from Intent - Index: $questionIndex")
                        multiplayerViewModel.setQuestionFromIntent(
                            questionIndex,
                            questionText,
                            questionOptions.toList()
                        )
                    }
                    
                    // Reconnect WebSocket and re-subscribe to room (for future questions)
                    multiplayerViewModel.reconnectWebSocket(roomCode)
                }
                
                // Navigate directly to multiplayer quiz fragment
                navController.navigate(R.id.multiplayerQuizFragment)
            }
        }
    }

    override fun onSupportNavigateUp(): Boolean {
        // Handle up navigation - finish activity to return to home
        finish()
        return true
    }
    
    override fun onDestroy() {
        super.onDestroy()
        if (::multiplayerViewModel.isInitialized) {
            // ViewModel will handle cleanup in onCleared()
        }
    }

    private fun showExitGameDialog() {
        AlertDialog.Builder(this)
            .setTitle("Exit game?")
            .setMessage("If you leave, the other player will win. Are you sure?")
            .setNegativeButton("No") { dialog, _ -> dialog.dismiss() }
            .setPositiveButton("Yes") { _, _ ->
                try {
                    val vm = ViewModelProvider(this)[MultiplayerViewModel::class.java]
                    vm.leaveGame()
                } catch (_: Exception) { }
                finish()
            }
            .setCancelable(true)
            .show()
    }
}
