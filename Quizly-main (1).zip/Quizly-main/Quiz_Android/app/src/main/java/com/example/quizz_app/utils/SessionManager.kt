package com.example.quizz_app.utils

import android.content.Context

class SessionManager(context: Context) {
    private val prefs =
        context.getSharedPreferences("auth_session", Context.MODE_PRIVATE)

    fun setLoggedIn(loggedIn: Boolean) {
        prefs.edit().putBoolean("LOGGED_IN", loggedIn).apply()
    }

    fun isLoggedIn(): Boolean {
        return prefs.getBoolean("LOGGED_IN", false)
    }

    fun saveUserId(uid: String) {
        prefs.edit().putString("USER_ID", uid).apply()
    }

    fun getUserId(): String? {
        return prefs.getString("USER_ID", null)
    }

    fun clearSession() {
        prefs.edit().clear().apply()
    }

    fun saveFirebaseToken(token: String) {
        prefs.edit().putString("FIREBASE_TOKEN", token).apply()
    }

    fun getFirebaseToken(): String? {
        return prefs.getString("FIREBASE_TOKEN", null)
    }

    fun setDarkMode(enabled: Boolean) {
        prefs.edit().putBoolean("DARK_MODE", enabled).apply()
    }

    fun isDarkMode(): Boolean {
        return prefs.getBoolean("DARK_MODE", false)
    }

    fun setOnboardingCompleted(completed: Boolean) {
        prefs.edit().putBoolean("ONBOARDING_COMPLETED", completed).apply()
    }

    fun isOnboardingCompleted(): Boolean {
        return prefs.getBoolean("ONBOARDING_COMPLETED", false)
    }
}