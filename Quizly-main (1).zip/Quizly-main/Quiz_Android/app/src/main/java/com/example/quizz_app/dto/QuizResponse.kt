package com.example.quizz_app.dto

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

@Parcelize
data class QuizResponse(
    val category:String,
    val difficulty:String,
    val questions:List<Question>
): Parcelable
