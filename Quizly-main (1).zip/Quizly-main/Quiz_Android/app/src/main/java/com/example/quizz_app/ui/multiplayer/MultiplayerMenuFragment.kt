package com.example.quizz_app.ui.multiplayer

import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.navigation.fragment.findNavController
import com.example.quizz_app.R
import com.google.android.material.textfield.TextInputEditText

/**
 * Multiplayer menu - Create or Join a room
 */
class MultiplayerMenuFragment : Fragment(R.layout.fragment_multiplayer_menu) {
    
    private val viewModel: MultiplayerViewModel by activityViewModels()
    
    private lateinit var btnCreateRoom: Button
    private lateinit var btnJoinRoom: Button
    private lateinit var etRoomCode: TextInputEditText
    
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        
        // Reset ViewModel state when entering menu (prevents stale roomCode from triggering navigation)
        viewModel.reset()
        
        btnCreateRoom = view.findViewById(R.id.btnCreateRoom)
        btnJoinRoom = view.findViewById(R.id.btnJoinRoom)
        etRoomCode = view.findViewById(R.id.etRoomCode)
        
        setupClickListeners()
        observeViewModel()
    }
    
    private fun setupClickListeners() {
        btnCreateRoom.setOnClickListener {
            findNavController().navigate(R.id.action_multiplayerMenuFragment_to_createRoomOptionsFragment)
        }
        
        btnJoinRoom.setOnClickListener {
            val roomCode = etRoomCode.text?.toString()?.trim()
            if (roomCode.isNullOrEmpty()) {
                Toast.makeText(context, "Please enter a room code", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            viewModel.joinRoom(roomCode)
        }
    }
    
    private var hasNavigated = false

    private fun observeViewModel() {
        viewModel.isLoading.observe(viewLifecycleOwner) { loading ->
            btnCreateRoom.isEnabled = !loading
            btnJoinRoom.isEnabled = !loading
            btnCreateRoom.alpha = if (loading) 0.5f else 1.0f
            btnJoinRoom.alpha = if (loading) 0.5f else 1.0f
        }
        
        viewModel.roomCode.observe(viewLifecycleOwner) { roomCode ->
            if (roomCode != null && !hasNavigated) {
                hasNavigated = true
                // Navigate to waiting room
                findNavController().navigate(R.id.action_multiplayerMenuFragment_to_waitingRoomFragment)
            }
        }
        
        viewModel.errorMessage.observe(viewLifecycleOwner) { error ->
            error?.let {
                Toast.makeText(context, it, Toast.LENGTH_LONG).show()
            }
        }
    }
}
