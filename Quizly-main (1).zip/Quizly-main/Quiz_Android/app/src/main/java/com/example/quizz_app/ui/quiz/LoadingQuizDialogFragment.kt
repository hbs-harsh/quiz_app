package com.example.quizz_app.ui.quiz

import android.app.Dialog
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.ImageView
import androidx.fragment.app.DialogFragment
import com.bumptech.glide.Glide
import com.example.quizz_app.R

/**
 * Aesthetic loading dialog showing the waiting GIF while the quiz is generated.
 * Use the same tag [LOADING_QUIZ_DIALOG_TAG] to show/dismiss (multiplayer and single-player).
 */
class LoadingQuizDialogFragment : DialogFragment() {

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        return super.onCreateDialog(savedInstanceState).apply {
            setCancelable(false)
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.dialog_loading_quiz, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val gifView = view.findViewById<ImageView>(R.id.loadingQuizGif)
        Glide.with(requireContext())
            .asGif()
            .load(R.drawable.waiting)
            .into(gifView)
        val card = view.findViewById<View>(R.id.loading_quiz_card)
        card.alpha = 0f
        card.scaleX = 0.9f
        card.scaleY = 0.9f
        card.animate()
            .alpha(1f)
            .scaleX(1f)
            .scaleY(1f)
            .setDuration(220)
            .start()
    }

    override fun onStart() {
        super.onStart()
        dialog?.window?.apply {
            setLayout(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.WRAP_CONTENT
            )
            setBackgroundDrawable(ColorDrawable(Color.parseColor("#1A000000")))
        }
    }

    companion object {
        const val LOADING_QUIZ_DIALOG_TAG = "LoadingQuizDialog"
    }
}
