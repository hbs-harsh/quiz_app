package com.example.quizz_app.model

data class LeaveGameRequest(
    val roomId: Long,
    val roomCode: String,
    val userId: String
)
