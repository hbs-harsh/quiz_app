package com.example.quizz_app.ui.multiplayer

import android.os.Bundle
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.ProgressBar
import android.widget.Spinner
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.navigation.fragment.findNavController
import com.example.quizz_app.R
import com.example.quizz_app.model.QuizSourceType
import com.google.android.material.button.MaterialButton
import com.google.android.material.chip.Chip
import com.google.android.material.chip.ChipGroup

/** Subject item for spinner (id sent as topic, displayName shown) */
data class SubjectItem(val id: String, val displayName: String)

/**
 * Create room options: subject/topic, per-question timer, and "Upload PDF/Word - Coming soon".
 */
class CreateRoomOptionsFragment : Fragment(R.layout.fragment_create_room_options) {

    private val viewModel: MultiplayerViewModel by activityViewModels()

    private lateinit var spinnerSubject: Spinner
    private lateinit var chipGroupTimer: ChipGroup
    private lateinit var btnCreateRoom: MaterialButton
    private lateinit var progressBar: ProgressBar

    private val subjects = listOf(
        SubjectItem("NEET_UG", "NEET UG"),
        SubjectItem("JEE", "JEE"),
        SubjectItem("JEE_Advanced", "JEE Advanced"),
        SubjectItem("Physics", "Physics"),
        SubjectItem("Chemistry", "Chemistry"),
        SubjectItem("Mathematics", "Mathematics"),
        SubjectItem("Biology", "Biology"),
        SubjectItem("GATE", "GATE"),
        SubjectItem("Computer_Science", "Computer Science (B.Tech)"),
        SubjectItem("General_Knowledge", "General Knowledge"),
        SubjectItem("History", "History"),
        SubjectItem("Geography", "Geography"),
        SubjectItem("Current_Affairs", "Current Affairs")
    )

    private var selectedTopicId: String = "History"

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        spinnerSubject = view.findViewById(R.id.spinnerSubject)
        chipGroupTimer = view.findViewById(R.id.chipGroupTimer)
        btnCreateRoom = view.findViewById(R.id.btnCreateRoom)
        progressBar = view.findViewById(R.id.progressBar)

        val adapter = ArrayAdapter(
            requireContext(),
            android.R.layout.simple_spinner_dropdown_item,
            subjects.map { it.displayName }
        )
        spinnerSubject.adapter = adapter
        spinnerSubject.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, v: View?, position: Int, id: Long) {
                selectedTopicId = subjects[position].id
            }
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }

        chipGroupTimer.check(R.id.chipTimer30)

        btnCreateRoom.setOnClickListener {
            val timerSeconds = getSelectedTimerSeconds()
            viewModel.createRoom(
                quizSourceType = QuizSourceType.TOPIC,
                topic = selectedTopicId,
                difficulty = "Medium",
                timerPerQuestion = timerSeconds
            )
        }

        observeViewModel()
    }

    private fun getSelectedTimerSeconds(): Int {
        val id = chipGroupTimer.checkedChipId
        if (id == View.NO_ID) return 30
        val chip = chipGroupTimer.findViewById<Chip>(id) ?: return 30
        return chip.tag?.toString()?.toIntOrNull() ?: 30
    }

    private var hasNavigated = false

    private fun observeViewModel() {
        viewModel.isLoading.observe(viewLifecycleOwner) { loading ->
            btnCreateRoom.isEnabled = !loading
            btnCreateRoom.alpha = if (loading) 0.5f else 1f
            progressBar.visibility = if (loading) View.VISIBLE else View.GONE
        }
        viewModel.roomCode.observe(viewLifecycleOwner) { roomCode ->
            if (roomCode != null && !hasNavigated) {
                hasNavigated = true
                findNavController().navigate(R.id.action_createRoomOptionsFragment_to_waitingRoomFragment)
            }
        }
        viewModel.errorMessage.observe(viewLifecycleOwner) { error ->
            error?.let { Toast.makeText(context, it, Toast.LENGTH_LONG).show() }
        }
    }
}
