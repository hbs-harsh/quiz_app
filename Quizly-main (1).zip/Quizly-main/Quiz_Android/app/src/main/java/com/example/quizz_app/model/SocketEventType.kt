package com.example.quizz_app.model

enum class SocketEventType {
    COUNTDOWN,
    START_QUESTION,
    ANSWER_RESULT,
    NEXT_QUESTION,
    GAME_OVER,
    PLAYER_JOINED
}
