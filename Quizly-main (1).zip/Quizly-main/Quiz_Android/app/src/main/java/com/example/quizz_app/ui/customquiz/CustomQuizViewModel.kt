package com.example.quizz_app.ui.customquiz

import android.content.Context
import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.quizz_app.dto.QuizResponse
import com.example.quizz_app.remote.RetrofitClient
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.RequestBody.Companion.asRequestBody
import java.io.File
import java.io.FileOutputStream

/**
 * Handles PDF upload and quiz generation for custom quiz (solo).
 */
class CustomQuizViewModel : ViewModel() {

    fun uploadPdfAndGetQuiz(
        context: Context,
        uri: Uri,
        questionCount: Int = 10,
        difficulty: String = "medium",
        timerSeconds: Int = 30,
        callback: (Result<Pair<QuizResponse, Int>>) -> Unit
    ) {
        viewModelScope.launch {
            val result = runCatching {
                withContext(Dispatchers.IO) {
                    val input = context.contentResolver.openInputStream(uri)
                        ?: throw IllegalArgumentException("Could not open file")
                    val tempFile = File(context.cacheDir, "quiz_upload.pdf")
                    FileOutputStream(tempFile).use { out ->
                        input.copyTo(out)
                    }
                    input.close()
                    val body = tempFile.asRequestBody("application/pdf".toMediaTypeOrNull())
                    val part = MultipartBody.Part.createFormData("file", tempFile.name, body)
                    val api = RetrofitClient.create(context)
                    val response = api.uploadPdfForQuiz(part, questionCount, difficulty)
                    tempFile.delete()
                    Pair(response, timerSeconds)
                }
            }
            withContext(Dispatchers.Main) {
                callback(result)
            }
        }
    }
}
