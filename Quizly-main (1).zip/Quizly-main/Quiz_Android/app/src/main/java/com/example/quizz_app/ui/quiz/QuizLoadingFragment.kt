package com.example.quizz_app.ui.quiz

import android.graphics.Color
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.ProgressBar
import android.widget.TextView
import androidx.fragment.app.DialogFragment
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.NavHostFragment
import com.example.quizz_app.R
import com.example.quizz_app.dto.QuizResponse
import com.example.quizz_app.remote.RetrofitClient
import com.example.quizz_app.utils.PendingQuizHolder
import kotlinx.coroutines.launch

class QuizLoadingFragment : Fragment(R.layout.fragment_quiz_loading) {

    private lateinit var progressBar: ProgressBar
    private lateinit var statusText: TextView
    private lateinit var retryButton: Button

    private lateinit var category: String
    private var timerSeconds: Int = 30
    private var questionCount: Int = 10
    private var difficulty: String = "medium"

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        progressBar = view.findViewById(R.id.progressBar)
        statusText = view.findViewById(R.id.tvStatus)
        retryButton = view.findViewById(R.id.btnRetry)

        category = requireActivity().intent.getStringExtra("category") ?: "General Knowledge"
        timerSeconds = requireActivity().intent.getIntExtra("timerSeconds", 30)
        questionCount = requireActivity().intent.getIntExtra("questionCount", 10)
        difficulty = requireActivity().intent.getStringExtra("difficulty") ?: "medium"

        retryButton.setOnClickListener { startLoadingQuiz() }

        if (requireActivity().intent.getBooleanExtra("USE_PENDING_QUIZ", false)) {
            val pending = PendingQuizHolder.consume()
            if (pending != null) {
                val (quizResponse, timerSec) = pending
                openQuizScreen(quizResponse, timerSec)
                return
            }
        }

        startLoadingQuiz()
    }

    private fun showLoadingQuizDialog() {
        LoadingQuizDialogFragment().show(childFragmentManager, LoadingQuizDialogFragment.LOADING_QUIZ_DIALOG_TAG)
    }

    private fun dismissLoadingQuizDialog() {
        (childFragmentManager.findFragmentByTag(LoadingQuizDialogFragment.LOADING_QUIZ_DIALOG_TAG) as? DialogFragment)?.dismiss()
    }

    private fun startLoadingQuiz() {
        showLoadingState()
        showLoadingQuizDialog()

        lifecycleScope.launch {
            try {
                val response = RetrofitClient.create(requireContext())
                    .startQuiz(
                        category = category,
                        questionCount = questionCount,
                        difficulty = difficulty,
                        useAI = true
                    )

                dismissLoadingQuizDialog()
                if (response.questions.isEmpty()) {
                    showErrorState("No questions available")
                    return@launch
                }

                openQuizScreen(response)
            } catch (e: Exception) {
                dismissLoadingQuizDialog()
                showErrorState("Failed to load quiz. Please try again.")
            }
        }
    }

    private fun showLoadingState() {
        // Only the dialog shows as loader; hide fragment's progress and text to avoid two loaders
        progressBar.visibility = View.GONE
        statusText.visibility = View.GONE
        retryButton.visibility = View.GONE
        // Use a light background so no dark full-width area shows behind the dialog (works in any theme)
        requireView().setBackgroundColor(Color.parseColor("#F5F3F7"))
    }

    private fun showErrorState(message: String) {
        progressBar.visibility = View.GONE
        statusText.visibility = View.VISIBLE
        statusText.text = message
        retryButton.visibility = View.VISIBLE
        requireView().setBackgroundColor(requireContext().getColor(R.color.background))
    }

    private fun openQuizScreen(quizResponse: QuizResponse, timerSec: Int = timerSeconds) {
        val bundle = Bundle().apply {
            putParcelable("quizData", quizResponse)
            putInt("timerSeconds", timerSec)
        }

        NavHostFragment.findNavController(this)
                .navigate(R.id.action_quizLoadingFragment_to_quizFragment, bundle)
    }
}
