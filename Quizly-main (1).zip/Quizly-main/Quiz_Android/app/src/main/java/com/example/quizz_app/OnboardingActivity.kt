package com.example.quizz_app

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.quizz_app.ui.onboardingscreen.welcome
import com.example.quizz_app.utils.SessionManager
import com.google.firebase.auth.FirebaseAuth

class OnboardingActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val session = SessionManager(this)
        val currentUser = FirebaseAuth.getInstance().currentUser

        // Already logged in → go straight to main app (skip onboarding and login)
        if (currentUser != null && session.isLoggedIn()) {
            session.saveUserId(currentUser.uid)
            startActivity(Intent(this, MainActivity2::class.java))
            finish()
            return
        }
        // Onboarding already done → go to login
        if (session.isOnboardingCompleted()) {
            startActivity(Intent(this, MainActivity::class.java))
            finish()
            return
        }
        setContentView(R.layout.activity_onboarding)

        if (savedInstanceState == null) {
            supportFragmentManager.beginTransaction()
                .replace(R.id.container, welcome())
                .commit()
        }
    }
}
