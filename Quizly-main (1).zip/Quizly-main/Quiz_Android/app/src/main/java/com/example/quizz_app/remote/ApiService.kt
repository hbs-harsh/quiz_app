package com.example.quizz_app.remote

import com.example.quizz_app.dto.QuizResponse
import com.example.quizz_app.model.RoomCreateRequest
import com.example.quizz_app.model.RoomJoinRequest
import com.example.quizz_app.model.RoomResponse
import okhttp3.MultipartBody
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.PATCH
import retrofit2.http.Multipart
import retrofit2.http.POST
import retrofit2.http.Part
import retrofit2.http.Query

data class AIStatusResponse(
    val aiEnabled: Boolean,
    val serviceHealthy: Boolean,
    val status: String
)

data class LeaderboardEntryResponse(
    val rank: Int,
    val displayName: String,
    val publicUserId: String? = null,
    val wins: Int,
    val points: Long
)

data class LeaderboardResponse(
    val topPlayers: List<LeaderboardEntryResponse>,
    val currentUser: LeaderboardEntryResponse?,
    val currentUserRank: Int
)

data class UpdateProfileRequest(val displayName: String)

interface ApiService {

    @GET("me")
    suspend fun me(): MeResponse

    @PATCH("me")
    suspend fun updateProfile(@Body body: UpdateProfileRequest): MeResponse

    @GET("qizzsection/start")
    suspend fun startQuiz(
        @Query("category") category: String,
        @Query("questionCount") questionCount: Int = 10,
        @Query("difficulty") difficulty: String = "medium",
        @Query("useAI") useAI: Boolean = true
    ): QuizResponse
    
    @GET("qizzsection/ai-status")
    suspend fun getAIStatus(): AIStatusResponse
    
    // Leaderboard
    @GET("leaderboard")
    suspend fun getLeaderboard(
        @Query("userId") userId: String? = null
    ): LeaderboardResponse
    
    // Multiplayer Room Management
    @POST("1v1/room/create")
    suspend fun createRoom(@Body request: RoomCreateRequest): RoomResponse
    
    @POST("1v1/room/join")
    suspend fun joinRoom(@Body request: RoomJoinRequest): RoomResponse

    /** Custom quiz: generate questions from uploaded PDF */
    @Multipart
    @POST("qizzsection/from-pdf")
    suspend fun uploadPdfForQuiz(
        @Part file: MultipartBody.Part,
        @Query("questionCount") questionCount: Int = 10,
        @Query("difficulty") difficulty: String = "medium"
    ): QuizResponse
}

