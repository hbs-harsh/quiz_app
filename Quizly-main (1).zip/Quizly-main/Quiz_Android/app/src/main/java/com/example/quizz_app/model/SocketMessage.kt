package com.example.quizz_app.model

import com.google.gson.annotations.SerializedName

data class SocketMessage(
    @SerializedName("type")
    val type: SocketEventType,
    
    @SerializedName("payload")
    val payload: Any
)
