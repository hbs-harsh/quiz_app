package com.example.quizz_app.ui.auth

import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.View
import android.view.animation.AccelerateDecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.core.view.isVisible
import androidx.credentials.CredentialManager
import androidx.credentials.CredentialManagerCallback
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import androidx.credentials.exceptions.GetCredentialException
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import com.example.quizz_app.MainActivity2
import com.example.quizz_app.R
import com.example.quizz_app.model.AuthState
import com.example.quizz_app.utils.SessionManager
import com.google.android.libraries.identity.googleid.GetGoogleIdOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import com.bumptech.glide.Glide
import com.bumptech.glide.load.resource.gif.GifDrawable
import com.bumptech.glide.request.target.CustomTarget
import com.bumptech.glide.request.transition.Transition
import com.google.android.material.button.MaterialButton
import com.google.android.material.textfield.TextInputLayout
import java.util.concurrent.Executors

class LoginFragment : Fragment(R.layout.fragment_login2) {

    private val viewModel: AuthViewModel by viewModels()

    private lateinit var tvLogo: TextView
    private lateinit var tvSubtitle: TextView
    private lateinit var emailInputLayout: TextInputLayout
    private lateinit var passwordInputLayout: TextInputLayout
    private lateinit var loginBtn: MaterialButton
    private lateinit var btnGoogleSignIn: MaterialButton
    private lateinit var loadingIndicator: ProgressBar
    private lateinit var goToRegisterBtn: TextView

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        initViews(view)
        setupClickListeners()
        observeViewModel()
        playEntryAnimations()
    }


    private fun initViews(view: View) {
        tvLogo = view.findViewById(R.id.tvLogo)
        tvSubtitle = view.findViewById(R.id.tvSubtitle)
        emailInputLayout = view.findViewById(R.id.emailInputLayout)
        passwordInputLayout = view.findViewById(R.id.passwordInputLayout)
        loginBtn = view.findViewById(R.id.loginBtn)
        btnGoogleSignIn = view.findViewById(R.id.btnGoogleSignIn)
        loadingIndicator = view.findViewById(R.id.loadingIndicator)
        goToRegisterBtn = view.findViewById(R.id.goToRegisterBtn)

        loadGoogleLogoGif()

        // Initially hide for animations
        tvLogo.alpha = 0f
        tvSubtitle.alpha = 0f
        emailInputLayout.alpha = 0f
        emailInputLayout.translationY = 50f
        passwordInputLayout.alpha = 0f
        passwordInputLayout.translationY = 50f
        loginBtn.alpha = 0f
        loginBtn.scaleX = 0.8f
        loginBtn.scaleY = 0.8f
    }

    private fun loadGoogleLogoGif() {
        Glide.with(requireContext())
            .asGif()
            .load(R.drawable.googlelogo)
            .into(object : CustomTarget<GifDrawable>() {
                override fun onResourceReady(
                    resource: GifDrawable,
                    transition: Transition<in GifDrawable>?
                ) {
                    resource.setLoopCount(GifDrawable.LOOP_FOREVER)
                    btnGoogleSignIn.icon = resource
                    btnGoogleSignIn.iconSize = (56 * resources.displayMetrics.density).toInt()
                    btnGoogleSignIn.iconGravity = MaterialButton.ICON_GRAVITY_TEXT_START
                    btnGoogleSignIn.iconPadding = (12 * resources.displayMetrics.density).toInt()
                    resource.start()
                }
                override fun onLoadCleared(placeholder: android.graphics.drawable.Drawable?) {}
            })
    }

    private fun setupClickListeners() {
        // Login button with press animation
        loginBtn.setOnClickListener {
            animateButtonPress(it) {
                val email = emailInputLayout.editText?.text.toString().trim()
                val password = passwordInputLayout.editText?.text.toString().trim()

                if (validateInputs(email, password)) {
                    viewModel.login(email, password)
                }
            }
        }

        btnGoogleSignIn.setOnClickListener {
            val webClientId = getString(R.string.default_web_client_id)
            if (webClientId == "REPLACE_WITH_YOUR_WEB_CLIENT_ID" || webClientId.isBlank()) {
                Toast.makeText(requireContext(), "Google Sign-In not configured. Set default_web_client_id in strings.xml", Toast.LENGTH_LONG).show()
                return@setOnClickListener
            }
            val credentialManager = CredentialManager.create(requireContext())
            val googleIdOption = GetGoogleIdOption.Builder()
                .setServerClientId(webClientId)
                .build()
            val request = GetCredentialRequest.Builder()
                .addCredentialOption(googleIdOption)
                .build()
            val executor = Executors.newSingleThreadExecutor()
            credentialManager.getCredentialAsync(
                requireContext(),
                request,
                null,
                executor,
                object : CredentialManagerCallback<androidx.credentials.GetCredentialResponse, GetCredentialException> {
                    override fun onResult(response: androidx.credentials.GetCredentialResponse) {
                        requireActivity().runOnUiThread {
                            val credential = response.credential
                            if (credential is CustomCredential) {
                                when (credential.type) {
                                    GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL,
                                    GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_SIWG_CREDENTIAL -> {
                                        val googleIdTokenCredential = GoogleIdTokenCredential.createFrom(credential.data)
                                        viewModel.signInWithGoogle(googleIdTokenCredential.idToken)
                                    }
                                    else -> Toast.makeText(requireContext(), "Unexpected credential type", Toast.LENGTH_SHORT).show()
                                }
                            } else {
                                Toast.makeText(requireContext(), "Google sign-in failed", Toast.LENGTH_SHORT).show()
                            }
                        }
                    }
                    override fun onError(e: GetCredentialException) {
                        requireActivity().runOnUiThread {
                            Toast.makeText(requireContext(), e.message ?: "Google sign-in failed", Toast.LENGTH_SHORT).show()
                        }
                    }
                }
            )
        }

        // Navigate to register with smooth slide transition
        goToRegisterBtn.setOnClickListener {
            parentFragmentManager
                    .beginTransaction()
                    .setCustomAnimations(
                            R.anim.slide_in_right,
                            R.anim.slide_out_left,
                            R.anim.slide_in_left,
                            R.anim.slide_out_right
                    )
                    .replace(R.id.container, RegisterFragment())
                    .addToBackStack(null)
                    .commit()
        }
    }

    private fun validateInputs(email: String, password: String): Boolean {
        var isValid = true

        if (email.isEmpty()) {
            emailInputLayout.error = "Email required"
            isValid = false
        } else {
            emailInputLayout.error = null
        }

        if (password.isEmpty()) {
            passwordInputLayout.error = "Password required"
            isValid = false
        } else {
            passwordInputLayout.error = null
        }

        return isValid
    }

    private fun playEntryAnimations() {
        // Logo animation (fade + scale)
        ObjectAnimator.ofFloat(tvLogo, "alpha", 0f, 1f).apply {
            duration = 500
            interpolator = AccelerateDecelerateInterpolator()
            start()
        }

        ObjectAnimator.ofFloat(tvLogo, "scaleX", 0.8f, 1.05f, 1f).apply {
            duration = 600
            interpolator = OvershootInterpolator()
            start()
        }

        ObjectAnimator.ofFloat(tvLogo, "scaleY", 0.8f, 1.05f, 1f).apply {
            duration = 600
            interpolator = OvershootInterpolator()
            start()
        }

        // Subtitle
        ObjectAnimator.ofFloat(tvSubtitle, "alpha", 0f, 1f).apply {
            duration = 500
            startDelay = 200
            start()
        }

        // Input fields (stagger)
        animateEntryView(emailInputLayout, 300)
        animateEntryView(passwordInputLayout, 400)

        // Button bounce in
        AnimatorSet().apply {
            playTogether(
                    ObjectAnimator.ofFloat(loginBtn, "alpha", 0f, 1f),
                    ObjectAnimator.ofFloat(loginBtn, "scaleX", 0.8f, 1f),
                    ObjectAnimator.ofFloat(loginBtn, "scaleY", 0.8f, 1f)
            )
            duration = 400
            startDelay = 500
            interpolator = OvershootInterpolator()
            start()
        }
    }

    private fun animateEntryView(view: View, delay: Long) {
        AnimatorSet().apply {
            playTogether(
                    ObjectAnimator.ofFloat(view, "alpha", 0f, 1f),
                    ObjectAnimator.ofFloat(view, "translationY", 50f, 0f)
            )
            duration = 400
            startDelay = delay
            interpolator = AccelerateDecelerateInterpolator()
            start()
        }
    }

    private fun animateButtonPress(view: View, action: () -> Unit) {
        AnimatorSet().apply {
            playSequentially(
                    // Press down
                    AnimatorSet().apply {
                        playTogether(
                                ObjectAnimator.ofFloat(view, "scaleX", 1f, 0.95f),
                                ObjectAnimator.ofFloat(view, "scaleY", 1f, 0.95f)
                        )
                        duration = 100
                    },
                    // Release
                    AnimatorSet().apply {
                        playTogether(
                                ObjectAnimator.ofFloat(view, "scaleX", 0.95f, 1f),
                                ObjectAnimator.ofFloat(view, "scaleY", 0.95f, 1f)
                        )
                        duration = 100
                    }
            )
            start()
        }

        // Execute action after animation delay
        view.postDelayed({ action() }, 150)
    }

    private fun observeViewModel() {
        // Observe Firebase token
        viewModel.firebaseToken.observe(viewLifecycleOwner) { token ->
            if (!token.isNullOrEmpty()) {
                SessionManager(requireContext()).saveFirebaseToken(token)
                Log.d("TOKEN", "Firebase token saved successfully")
            }
        }

        // Observe auth state
        viewModel.authState.observe(viewLifecycleOwner) { state ->
            when (state) {
                is AuthState.Loading -> {
                    loginBtn.isEnabled = false
                    btnGoogleSignIn.isEnabled = false
                    loadingIndicator.isVisible = true
                }
                is AuthState.Success -> {
                    loadingIndicator.isVisible = false
                    loginBtn.isEnabled = true
                    btnGoogleSignIn.isEnabled = true
                    val session = SessionManager(requireContext())
                    session.setLoggedIn(true)
                    com.google.firebase.auth.FirebaseAuth.getInstance().currentUser?.uid?.let { uid ->
                        session.saveUserId(uid)
                    }
                    val intent = Intent(requireContext(), MainActivity2::class.java)
                    startActivity(intent)
                    requireActivity().finish()
                }
                is AuthState.Error -> {
                    loginBtn.isEnabled = true
                    btnGoogleSignIn.isEnabled = true
                    loadingIndicator.isVisible = false
                    Toast.makeText(requireContext(), state.message, Toast.LENGTH_SHORT).show()
                }
                else -> Unit
            }
        }
    }
}
