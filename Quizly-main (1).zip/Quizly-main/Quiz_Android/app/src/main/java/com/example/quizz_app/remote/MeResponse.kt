package com.example.quizz_app.remote

data class MeResponse(
    val email: String,
    val firebaseUid: String,
    val displayName: String? = null
)
