package com.example.quizz_app.utils

object Constants {
    // Base URLs - Using Android Emulator mapping to localhost
    const val BASE_URL = "http://10.0.2.2:8080/"
    const val WS_URL = "ws://10.0.2.2:8080/ws/quiz"
    
    // REST API Endpoints
    const val ROOM_CREATE = "1v1/room/create"
    const val ROOM_JOIN = "1v1/room/join"
    
    // WebSocket Destinations (client sends to these)
    const val WS_SEND_START = "/app/start"
    const val WS_SEND_ANSWER = "/app/answer"
    const val WS_SEND_LEAVE = "/app/leave"
    
    // WebSocket Topics (client subscribes to these)
    fun getWsRoomTopic(roomCode: String) = "/topic/room/$roomCode"
    
    // Temporary User IDs (for testing without full auth integration)
    const val TEMP_USER_ID_1 = "USER_1"
    const val TEMP_USER_ID_2 = "USER_2"
}