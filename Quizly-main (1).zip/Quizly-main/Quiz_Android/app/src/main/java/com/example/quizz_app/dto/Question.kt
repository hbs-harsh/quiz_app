package com.example.quizz_app.dto

import android.os.Parcelable
import com.google.gson.annotations.SerializedName
import kotlinx.android.parcel.Parcelize

@Parcelize
data class Question(
    @SerializedName("correctAnswer") val correct: Int,
    val question: String,
    val options: List<String>
): Parcelable
