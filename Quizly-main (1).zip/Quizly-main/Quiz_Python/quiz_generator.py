"""
Quiz Generator Service using LangChain
Generates quiz questions for both static quizzes and 1v1 multiplayer games.
"""

import os
import json
import re
from typing import List, Optional
from dotenv import load_dotenv
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import JsonOutputParser
from langchain_core.pydantic_v1 import BaseModel, Field


# Load .env from the same folder as this file (Quiz_Python)
_load_env_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), ".env")
load_dotenv(_load_env_path)


class QuizQuestion(BaseModel):
    """Schema for a single quiz question"""
    question: str = Field(description="The question text")
    options: List[str] = Field(description="List of 4 answer options")
    correct: int = Field(description="Index of the correct answer (0-3)")


class QuizResponse(BaseModel):
    """Schema for the complete quiz response"""
    category: str = Field(description="The quiz category/topic")
    difficulty: str = Field(description="Difficulty level")
    questions: List[QuizQuestion] = Field(description="List of quiz questions")


def get_llm():
    """Get the LLM: Gemini only, using gemini-2-flash. API key from .env (GOOGLE_API_KEY)."""
    from langchain_google_genai import ChatGoogleGenerativeAI
    api_key = os.getenv("GOOGLE_API_KEY", "").strip()
    if not api_key:
        raise ValueError(
            "GOOGLE_API_KEY is not set. Add GOOGLE_API_KEY=your_key to Quiz_Python/.env "
            "and set GOOGLE_API_KEY=your_google_api_key (get one at https://aistudio.google.com/apikey)"
        )
    return ChatGoogleGenerativeAI(
        model="gemini-2.5-flash",
        temperature=0.7,
        google_api_key=api_key
    )


QUIZ_PROMPT_TEMPLATE = """You are a quiz master. Generate exactly {num_questions} multiple-choice questions about {topic}.

Requirements:
- Each question must have exactly 4 options
- Only ONE option should be correct
- Questions should be {difficulty} difficulty level
- Questions should be diverse and cover different aspects of the topic
- Options should be plausible but only one correct
- For exam topics like NEET, JEE, GATE - include relevant academic questions

Topic: {topic}
Difficulty: {difficulty}
Number of questions: {num_questions}

Return ONLY a valid JSON array with this exact structure (no markdown, no explanation):
[
  {{
    "question": "Question text here?",
    "options": ["Option A", "Option B", "Option C", "Option D"],
    "correct": 0
  }}
]

The "correct" field should be the index (0-3) of the correct answer in the options array.

Generate the questions now:"""


QUIZ_FROM_TEXT_PROMPT_TEMPLATE = """You are a quiz master. Based on the following text content, generate exactly {num_questions} multiple-choice questions.

Requirements:
- Each question must have exactly 4 options
- Only ONE option should be correct
- Questions must be based ONLY on the provided text
- Questions should be {difficulty} difficulty level
- Options should be plausible but only one correct

Text content:
---
{text_content}
---

Number of questions: {num_questions}
Difficulty: {difficulty}

Return ONLY a valid JSON array with this exact structure (no markdown, no explanation):
[
  {{
    "question": "Question text here?",
    "options": ["Option A", "Option B", "Option C", "Option D"],
    "correct": 0
  }}
]

The "correct" field should be the index (0-3) of the correct answer. Generate the questions now:"""


def clean_json_response(response_text: str) -> str:
    """Clean the LLM response to extract valid JSON"""
    text = response_text.strip()
    
    if text.startswith("```json"):
        text = text[7:]
    elif text.startswith("```"):
        text = text[3:]
    
    if text.endswith("```"):
        text = text[:-3]
    
    text = text.strip()
    
    start_idx = text.find('[')
    end_idx = text.rfind(']')
    
    if start_idx != -1 and end_idx != -1:
        text = text[start_idx:end_idx + 1]
    
    return text


def generate_quiz(
    topic: str,
    num_questions: int = 10,
    difficulty: str = "medium"
) -> QuizResponse:
    """
    Generate a quiz using LangChain and LLM.
    
    Args:
        topic: The quiz topic/category (e.g., "Physics", "NEET_UG", "History")
        num_questions: Number of questions to generate (default: 10)
        difficulty: Difficulty level - "easy", "medium", "hard" (default: "medium")
    
    Returns:
        QuizResponse with generated questions
    """
    llm = get_llm()
    
    topic_display = topic.replace("_", " ")
    if "reasoning" in topic.lower() or "logic" in topic.lower():
        topic_display = (
            "Reasoning and Logic: short puzzles, number/letter sequences, "
            "analogies, pattern completion, and logical deduction (who is lying, "
            "what comes next, odd one out, etc.)"
        )
    
    prompt = ChatPromptTemplate.from_template(QUIZ_PROMPT_TEMPLATE)
    
    chain = prompt | llm
    
    result = chain.invoke({
        "topic": topic_display,
        "num_questions": num_questions,
        "difficulty": difficulty
    })
    
    response_text = result.content if hasattr(result, 'content') else str(result)
    
    cleaned_json = clean_json_response(response_text)
    
    try:
        questions_data = json.loads(cleaned_json)
    except json.JSONDecodeError as e:
        print(f"JSON Parse Error: {e}")
        print(f"Raw response: {response_text}")
        print(f"Cleaned response: {cleaned_json}")
        raise ValueError(f"Failed to parse LLM response as JSON: {e}")
    
    questions = []
    for q in questions_data:
        if len(q.get("options", [])) != 4:
            continue
            
        correct_idx = q.get("correct", 0)
        if not isinstance(correct_idx, int) or correct_idx < 0 or correct_idx > 3:
            correct_idx = 0
            
        questions.append(QuizQuestion(
            question=q["question"],
            options=q["options"],
            correct=correct_idx
        ))
    
    if len(questions) < num_questions:
        print(f"Warning: Only generated {len(questions)} valid questions out of {num_questions} requested")
    
    return QuizResponse(
        category=topic,
        difficulty=difficulty,
        questions=questions[:num_questions]
    )


def generate_quiz_from_text(
    text_content: str,
    num_questions: int = 10,
    difficulty: str = "medium"
) -> QuizResponse:
    """
    Generate a quiz from arbitrary text (e.g. extracted from a PDF).

    Args:
        text_content: The source text to base questions on
        num_questions: Number of questions to generate
        difficulty: "easy", "medium", or "hard"

    Returns:
        QuizResponse with generated questions
    """
    if not text_content or not text_content.strip():
        raise ValueError("Text content is empty")
    # Truncate very long text to avoid token limits (keep first ~12k chars)
    content = text_content.strip()[:12000]
    llm = get_llm()
    prompt = ChatPromptTemplate.from_template(QUIZ_FROM_TEXT_PROMPT_TEMPLATE)
    chain = prompt | llm
    result = chain.invoke({
        "text_content": content,
        "num_questions": num_questions,
        "difficulty": difficulty
    })
    response_text = result.content if hasattr(result, 'content') else str(result)
    cleaned_json = clean_json_response(response_text)
    try:
        questions_data = json.loads(cleaned_json)
    except json.JSONDecodeError as e:
        raise ValueError(f"Failed to parse LLM response as JSON: {e}")
    questions = []
    for q in questions_data:
        if len(q.get("options", [])) != 4:
            continue
        correct_idx = q.get("correct", 0)
        if not isinstance(correct_idx, int) or correct_idx < 0 or correct_idx > 3:
            correct_idx = 0
        questions.append(QuizQuestion(
            question=q["question"],
            options=q["options"],
            correct=correct_idx
        ))
    if len(questions) < min(num_questions, 1):
        raise ValueError(f"Could only generate {len(questions)} valid questions")
    return QuizResponse(
        category="From PDF",
        difficulty=difficulty,
        questions=questions[:num_questions]
    )


if __name__ == "__main__":
    print("Testing Quiz Generator...")
    
    try:
        quiz = generate_quiz(
            topic="General Knowledge",
            num_questions=3,
            difficulty="medium"
        )
        
        print(f"\nGenerated Quiz:")
        print(f"Category: {quiz.category}")
        print(f"Difficulty: {quiz.difficulty}")
        print(f"Questions: {len(quiz.questions)}")
        
        for i, q in enumerate(quiz.questions, 1):
            print(f"\n{i}. {q.question}")
            for j, opt in enumerate(q.options):
                marker = "✓" if j == q.correct else " "
                print(f"   [{marker}] {opt}")
                
    except Exception as e:
        print(f"Error: {e}")
