"""
FastAPI Quiz Generation Service
Serves quiz questions for Quizly app (static quizzes and 1v1 multiplayer)
"""

import os
import traceback
from typing import Optional, List
from fastapi import FastAPI, Query, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from dotenv import load_dotenv

# Load .env from Quiz_Python folder (same directory as main.py)
load_dotenv(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".env"))

from quiz_generator import generate_quiz, generate_quiz_from_text, QuizResponse as GeneratorResponse

app = FastAPI(
    title="Quizly Quiz Generator",
    description="AI-powered quiz generation service using LangChain",
    version="1.0.0"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


class Question(BaseModel):
    """Question model matching Spring Boot backend expectations"""
    question: str
    options: List[str]
    correctAnswer: int


class QuizResponse(BaseModel):
    """Response model matching Spring Boot backend expectations"""
    category: str
    difficulty: str
    questions: List[Question]


class GenerateFromTextRequest(BaseModel):
    """Request body for generate-from-text (e.g. PDF content)"""
    text: str
    num_questions: int = 10
    difficulty: str = "medium"


SUPPORTED_TOPICS = {
    "General Knowledge": "general_knowledge",
    "Science": "science",
    "History": "history",
    "Geography": "geography",
    "Sports": "sports",
    "Entertainment": "entertainment",
    "Technology": "technology",
    "Mathematics": "mathematics",
    "Physics": "physics",
    "Chemistry": "chemistry",
    "Biology": "biology",
    "Computer_Science": "computer_science",
    "NEET_UG": "neet_ug",
    "JEE": "jee",
    "GATE": "gate",
    "UPSC": "upsc",
    "Literature": "literature",
    "Art": "art",
    "Music": "music",
    "Movies": "movies",
    "Current_Affairs": "current_affairs",
    "Reasoning_Logic": "reasoning_logic",
}


@app.get("/")
async def root():
    """Health check endpoint"""
    return {
        "status": "running",
        "service": "Quizly Quiz Generator",
        "version": "1.0.0"
    }


@app.get("/topics")
async def get_topics():
    """Get list of supported quiz topics"""
    return {
        "topics": list(SUPPORTED_TOPICS.keys()),
        "count": len(SUPPORTED_TOPICS)
    }


@app.get("/quiz/generate", response_model=QuizResponse)
async def generate_quiz_endpoint(
    category: str = Query(
        default="General Knowledge",
        description="Quiz topic/category"
    ),
    difficulty: str = Query(
        default="medium",
        description="Difficulty level: easy, medium, hard"
    ),
    country: Optional[str] = Query(
        default=None,
        description="Country context (optional, for region-specific questions)"
    ),
    limit: int = Query(
        default=10,
        ge=1,
        le=50,
        description="Number of questions to generate"
    )
):
    """
    Generate quiz questions using AI.
    
    This endpoint handles all quiz types:
    - Static quizzes (single player)
    - 1v1 Multiplayer quizzes
    
    Parameters are flexible to accommodate both quiz modes.
    Timer is NOT generated here - it's handled by the backend.
    """
    valid_difficulties = ["easy", "medium", "hard"]
    if difficulty.lower() not in valid_difficulties:
        difficulty = "medium"
    
    topic = category
    if country and country.strip():
        topic = f"{category} ({country})"
    
    try:
        result = generate_quiz(
            topic=topic,
            num_questions=limit,
            difficulty=difficulty.lower()
        )
        
        questions = [
            Question(
                question=q.question,
                options=q.options,
                correctAnswer=q.correct
            )
            for q in result.questions
        ]
        
        return QuizResponse(
            category=category,
            difficulty=difficulty,
            questions=questions
        )
        
    except Exception as e:
        print(f"Error generating quiz: {e}")
        traceback.print_exc()
        raise HTTPException(
            status_code=500,
            detail=f"Failed to generate quiz: {str(e)}"
        )


@app.post("/quiz/generate-from-text", response_model=QuizResponse)
async def generate_from_text_endpoint(body: GenerateFromTextRequest):
    """
    Generate quiz questions from arbitrary text (e.g. PDF content).
    Used by backend when user uploads a PDF for custom quiz.
    """
    try:
        result = generate_quiz_from_text(
            text_content=body.text,
            num_questions=body.num_questions,
            difficulty=body.difficulty
        )
        questions = [
            Question(
                question=q.question,
                options=q.options,
                correctAnswer=q.correct
            )
            for q in result.questions
        ]
        return QuizResponse(
            category=result.category,
            difficulty=result.difficulty,
            questions=questions
        )
    except Exception as e:
        print(f"Error generating quiz from text: {e}")
        raise HTTPException(
            status_code=500,
            detail=f"Failed to generate quiz: {str(e)}"
        )


@app.post("/quiz/generate-custom")
async def generate_custom_quiz(
    topic: str = Query(..., description="Custom topic or prompt"),
    num_questions: int = Query(default=10, ge=1, le=50),
    difficulty: str = Query(default="medium")
):
    """
    Generate quiz from a custom topic/prompt.
    Useful for future PDF/document-based quiz generation.
    """
    try:
        result = generate_quiz(
            topic=topic,
            num_questions=num_questions,
            difficulty=difficulty.lower()
        )
        
        questions = [
            Question(
                question=q.question,
                options=q.options,
                correctAnswer=q.correct
            )
            for q in result.questions
        ]
        
        return QuizResponse(
            category=topic,
            difficulty=difficulty,
            questions=questions
        )
        
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Failed to generate custom quiz: {str(e)}"
        )


if __name__ == "__main__":
    import uvicorn
    
    host = os.getenv("HOST", "0.0.0.0")
    port = int(os.getenv("PORT", "8000"))
    
    print(f"Starting Quizly Quiz Generator on {host}:{port}")
    uvicorn.run(app, host=host, port=port)
