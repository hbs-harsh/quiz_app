# Quizly AI Quiz Generator

AI-powered quiz generation service using LangChain. Generates questions for both static quizzes and 1v1 multiplayer games.

## Features

- Generate quiz questions on any topic using AI (Google Gemini 2 Flash only)
- Support for multiple difficulty levels (easy, medium, hard)
- Flexible question count (1-50 questions)
- Supports exam-specific topics (NEET, JEE, GATE, UPSC)
- Automatic fallback to mock questions if AI is unavailable

## Setup

### 1. Install Dependencies

```bash
cd Quiz_Python
pip install -r requirements.txt
```

### 2. Configure Environment

Create a `.env` file in `Quiz_Python` and set your Gemini API key:

```env
GOOGLE_API_KEY=your_google_api_key_here
```

The app uses **gemini-2-flash** only (no GPT or Gemini Pro). Keys are read from the `.env` file in `Quiz_Python`.

### 3. Get API Key

**Google Gemini (free tier available):**
1. Go to https://aistudio.google.com/app/apikey
2. Create a new API key
3. Add it to your `.env` file as `GOOGLE_API_KEY=...`

### 4. Run the Service

```bash
python main.py
```

The service will start on `http://localhost:8000`

## API Endpoints

### Health Check
```
GET /
```

### Get Supported Topics
```
GET /topics
```

### Generate Quiz (Main Endpoint)
```
GET /quiz/generate?category=Physics&difficulty=medium&limit=10
```

Parameters:
- `category` (string): Quiz topic (e.g., "Physics", "NEET_UG", "History")
- `difficulty` (string): "easy", "medium", or "hard"
- `limit` (int): Number of questions (1-50)
- `country` (string, optional): Country context for region-specific questions

Response:
```json
{
  "category": "Physics",
  "difficulty": "medium",
  "questions": [
    {
      "question": "What is the SI unit of force?",
      "options": ["Joule", "Newton", "Watt", "Pascal"],
      "correctAnswer": 1
    }
  ]
}
```

### Generate Custom Quiz
```
POST /quiz/generate-custom?topic=Your+Topic&num_questions=10&difficulty=medium
```

## Supported Topics

- General Knowledge
- Science
- History
- Geography
- Sports
- Entertainment
- Technology
- Mathematics
- Physics
- Chemistry
- Biology
- Computer Science
- NEET_UG
- JEE
- GATE
- UPSC
- Literature
- Art
- Music
- Movies
- Current Affairs

## Integration with Spring Boot Backend

The backend is configured to call this service. Ensure:

1. This Python service is running on `http://127.0.0.1:8000`
2. In `application.properties`:
   ```properties
   quiz.python.enabled=true
   quiz.python.url=http://127.0.0.1:8000
   quiz.python.timeout=60
   ```

## Testing

Test the quiz generator directly:

```bash
python quiz_generator.py
```

Or test the API:

```bash
curl "http://localhost:8000/quiz/generate?category=Physics&limit=5"
```

## Troubleshooting

### "AI quiz service unavailable"
- Ensure the Python service is running
- Check that your API key is valid
- The backend will automatically fall back to mock questions

### "Failed to parse LLM response"
- This can happen occasionally with AI responses
- The system will retry or fall back to mock questions

### Connection refused
- Make sure the Python service is running on the correct port
- Check firewall settings
